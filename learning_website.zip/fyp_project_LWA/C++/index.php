
<?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\navbar.php');
?>
  <title>Let's Learn Programming C++</title>

       


    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>Welcome to C++ Learning</h1>
          <h2>We are always here to serve you 24/7</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="topics/Introduction_of_c++(1).php" class="btn-get-started scrollto">Start Learning</a>
            
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="\fyp_project_LWA\assets\img\logo.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">


     <!-- ======= About Us Section ======= -->
     <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>C++</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
            Here is a detailed explanation of C++, including its basic history, features, and uses:
            </p>
            
            <ul>
            <li><i class=""></i><h3>What is C++?*</h3></li>
              <li><i class="ri-check-double-line"></i> C++ is a high-performance, compiled, general-purpose programming language.</li>
              <li><i class="ri-check-double-line"></i> That was developed by Bjarne Stroustrup as an extension of the C programming language. </li>
              <li><i class="ri-check-double-line"></i> It was first released in 1985 and has since become one of the most popular programming languages in the world.</li>
              <li><i class="ri-check-double-line"></i> Renamed to PHP: Hypertext Preprocessor in 1997 (PHP 3.0)</li>
              
            </ul>

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
          <ul>
              <li><i class=""></i><h3>Features of C++</h3></li>
              <li><i class="ri-check-double-line"></i> <b>Object-oriented programming:</b> C++ supports object-oriented programming (OOP) concepts like encapsulation, inheritance, and polymorphism.</li>
              <li><i class="ri-check-double-line"></i> <b>Template metaprogramming: </b> C++ provides a feature called template metaprogramming, which allows for generic programming and metaprogramming.</li>
              <li><i class="ri-check-double-line"></i> <b>Multi-paradigm programming: </b> C++ supports multiple programming paradigms, including object-oriented, imperative, and functional programming.</li>
              <li><i class="ri-check-double-line"></i> <b>Compiled language: </b> C++ code is compiled into machine code, making it a fast and efficient language.</li>
              <li><i class="ri-check-double-line"></i> <b>Low-level memory management: </b> C++ allows developers to have low-level control over memory management, which can be useful for systems programming and performance-critical applications.</li>
            </ul>
            
<!-- Modal Start -->
<button class="btn-learn-more" data-toggle="modal" data-target="#mymodal">
Read More
</button>
<div class="modal fade modal-lg" id="mymodal" data-backdrop="static">
<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
<div class="modal-content">
    <div class="modal-header">
        <h2 class="modal-title">
            C++
        </h2>
        <button class="close btn btn-white text-danger" data-dismiss="modal">
          X
        </button>
    </div>
    <div class="modal-body">
        <div class="card">
          <!-- <img src="\fyp_project_LWA\assets\img\c++.jpg" class="card-img-top img-fluid" alt=""> -->
          <video src="\fyp_project_LWA\assets\img\videos\c++.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>

          <div class="card-body">
            <h1 class="card-title">
            Uses of C++
            </h1>
            <p class="card-text">
            <h3>Operating systems:</h3>
            C++ is widely used in operating system development, including Windows and Linux.
          </p>

            <p class="card-text">
            <h3>Web browsers: </h3>
            C++ is used in web browser development, including Google Chrome and Mozilla Firefox.
          </p>

            <p class="card-text">
            <h3>Games: </h3>
            C++ is used in game development, including game engines like Unreal Engine and Unity.
          </p>

            <p class="card text">
                <h3>Financial applications</h3>
                C++ is used in financial applications, including trading platforms and financial modeling.
              </p>


              <p class="card text">
                <h3>Scientific simulations</h3>
                C++ is used in scientific simulations, including climate modeling and particle physics.
              </p>

              <h1 class="card-title">
              Libraries and Frameworks
              </h1>

              <p class="card text">
                <h3>Standard Template Library (STL)*: </h3>
                A library of generic containers, algorithms, and iterators.
              </p>

              <p class="card text">
                <h3>Boost:</h3>
                A collection of reusable and portable C++ libraries.
              </p>

              <p class="card text">
                <h3>Qt:</h3>
                A cross-platform application development framework.
              </p>
            <p class="card text">
                <h3>OpenCV: </h3>
                A computer vision library.
              </p>
              

              <h1 class="card-title">
              Best Practices
              </h1>

              <p class="card text">
                <h3>Use modern C++*: : </h3>
                Take advantage of modern C++ features and standards (C++11, C++14, C++17).
              </p>

              <p class="card text">
                <h3>Use smart pointers: </h3>
                Instead of raw pointers, use smart pointers like unique_ptr and shared_ptr.
              </p>

              <p class="card text">
                <h3>Use containers and algorithms: </h3>
                Instead of manual memory management, use STL containers and algorithms.
              </p>

              <p class="card text">
                <h3>Follow coding standards: </h3>
                Adhere to established coding standards and conventions.
              </p>

              <p class="card text">
                <h3>Test code: </h3>
                Write unit tests and integration tests to ensure code quality and reliability.
              </p>

              <p class="card text">
                <h3>Conclusion: </h3>
                I hope this provides a detailed overview of C++! Let me know if you have any specific questions or need further clarification.
              </p>

              

          </div>
        </div>
    
    <div class="modal-footer">
        <button class="btn btn-danger" class="close" data-dismiss="modal">
            close
        </button>
    </div>
</div>

</div>


            <!-- Modal End -->
          </div>
        </div>

      </div>
    </section>
    <!-- End About Us Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
         <p>"Take your programming skills to the next level with our comprehensive C++ topics! Master the art of coding 
          with our in-depth lectures on C++ fundamentals, including C++ Comments, C++ Output, C++ DataTypes, C++ Syntax, and much more. Our topics are designed to help you understand the basics and beyond, so you can create high-performance applications, games, and systems software with ease.
           Whether you're a beginner or looking to refresh your skills, our C++ topics have got you covered!"</p> 
        </div>

        <div class="row">
          <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4><a href="topics/C++_comments(5).php">Comments</a></h4>
              <p>Comments can be used to explain C++ code, and to make it more readable. It can also be used to 
                prevent execution when testing alternative code. Comments can be singled-line or multi-lined</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="topics/C++_output(4).php">C++ OutPut</a></h4>
              <p>The cout object, together with the << operator, is used to output values/print text:</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="topics/C++_data_types(8).php">Data Types</a></h4>
              <p>A data types specifis the type of data that a variable can store such as integer, floating, character etc
There are 4 types of data types in C++ language.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="topics/C++_Syntax(3).php">Syntax</a></h4>
              <p><pre>
#include &lt;iostream>
using namespace std;
int main() 
{
  cout << "Hello World!";
  return 0;
}
              </pre></p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
    <?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\footer.php');
?>