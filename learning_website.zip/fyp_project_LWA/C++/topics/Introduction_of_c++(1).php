<?php
include('c++_header.php');
?>
<title>Introduction of C++</title>
    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">C++ Introduction</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>What is C++?</h3>
            <p style="text-align: justify; margin-right: 20px;">
C++ is a cross-platform language that can be used to create high-performance applications. 
C++ was developed by Bjarne Stroustrup, as an extension to the C language. 
C++ gives programmers a high level of control over system resources and memory. 
The language was updated 4 major times in 2011, 2014, 2017, and 2020 to C++11, C++14, C++17, C++20. 

            </p>
            <h3>Why Use C++</h3>
            <p style="text-align: justify; margin-right: 20px;">
C++ is one of the world's most popular programming languages. 
C++ can be found in today's operating systems, Graphical User Interfaces, and embedded systems. 
C++ is an object-oriented programming language which gives a clear structure to programs and allows code to be reused, lowering development costs. 
C++ is portable and can be used to develop applications that can be adapted to multiple platforms. 
C++ is fun and easy to learn! 
As C++ is close to C, C# and Java, it makes it easy for programmers to switch to C++ or vice versa. 
</p>
            <h3>Difference between C and C++</h3>
            <p style="text-align: justify; margin-right: 20px;">
C++ was developed as an extension of C, and both languages have almost the same syntax. 
The main difference between C and C++ is that C++ support classes and objects, while C does not. 
 </p>
<!--FIRST TOPIC END-->

            <!--SECOND TOPIC START-->
            <h3>Get Started</h3>
            <p style="text-align: justify; margin-right: 20px;">
This tutorial will teach you the basics of C++. 
It is not necessary to have any prior programming experience.
</p>       
      <!--tHIRD TOPIC END-->
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIRST LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="Get_started(2).php"><button id="next">Next&#187;</button></a>
            <!-- <a href="Introduction of c++(1).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "C++ was developed by",
            a: [{ text: "Mark Zaker Berg", isCorrect: false },
            { text: "None of these", isCorrect: false },
            { text: "Bjarne Stroustrup", isCorrect: true },
            { text: "Bill Gates", isCorrect: false }
            ]

        },
        {
            q: "C++ is one of the world's most popular",
            a: [{ text: "Scripting Language", isCorrect: false, isSelected: false },
            { text: "Markup Language", isCorrect: false },
            { text: "Structure Query Language", isCorrect: false },
            { text: "programming languages", isCorrect: true }
            ]

        },
        {
            q: "C++ was developed as an extension of",
            a: [{ text: "Cobol", isCorrect: false },
            { text: "JS", isCorrect: false },
            { text: "C", isCorrect: true },
            { text: "All", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>