<?php
include('c++_header.php');
?>
<title>C++ Variable</title>
    <div class="container"> 
        <br>
        <div class="notes">

            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intr">C++ Variables</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>C++ Variables</h3>
            <p style="text-align: justify; margin-right: 20px;">
                Variables are containers for storing data values. In C++, there are different
                <b>types</b> of variables (defined with different keywords), for example:
                <br>
                <b>int</b> stores integers (whole numbers), without decimals,such as 1234. 
                <br>
                <b>double</b> stores floating point numbers, with decimals, such as 19.99.
                <br>
                <b>Char</b> stores single characters, such as 'A' or 'B'. Char values are surrounded
                by single quotes.
                <br>
                <b>string</b> stores text, such as "Hello World". String values are surrounded by 
                double quotes.
                <br>
                <b>bool</b> stores values with two states: <b>true or false</b>
            </p>
            <!--FIRST TOPIC END-->

            <!-- ///////////////////////// -->
            <!--SECOND TOPIC START-->

            <h3>Syntax</h3>
            <p style="text-align: justify; margin-right: 20px;">
                datatype variableName = value;
                <br>
                Where type is one of C++ DataTypes (such as int), and variableName is 
                the name of the variable (such as <b>x</b>or <b>myName</b>). The <b>equal sign</b>
                is used to assign values to the variable. To create a variable that should store 
                a number, look at the following example
            </p>
            <!-- code part start -->
            <h3>Example</h3>
            <p>Create a variable called <b>myNum</b> of type int and assign it the values <b>15</b>:</p>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
    int myNum=<i>15</i>;
    cout << myNum;
    return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>15</h1>    
        </div>
        </div>
        <!-- code part end -->
        <p>You can also declare a variable without assigning the value, and assign the value later:</p>
        <!-- Second topic end -->


        <!-- ////////////////////////////////////////// -->
        <!-- Third topic start -->
        <h3>Example</h3>
            <p>Create a variable called <b>myNum</b> of type int and assign it the values <b>15</b>:</p>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
    int myNum;
    myNum=<i>15</i>;
    cout << myNum;
    return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>15</h1>    
        </div>
        </div>
        <p><b>Note</b> that if you assign a new value to an existing variable, it will
            overwrite the previous value:
        </p>
      <!--tHIRD TOPIC END-->
      <!-- ///////////////////////////////////// -->

      <!-- fourth topic start -->
            <!-- code part start -->
            <h3>Example</h3>
            <p>Create a variable called <b>myNum</b> of type int and assign it the values <b>15</b>:</p>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
    int myNum = <i>15</i>;
    myNum=<i>10</i>;
    cout << myNum;
    return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>10</h1>    
        </div>
        </div>
        <!-- code part end -->
        <!-- fourth topic end -->


        <!-- //////////////////////////////////////////// -->
        <!-- fifth topic start -->
            <h3>Other Types</h3>
            <p style="text-align: justify; margin-right: 20px;">
                A demonstration of other data types:
            </p>
            <h3>Example</h3>
            <h2>
            int myNum = <i>5</i>; <i style="color: yellow;">//integer (whole number without decimals)</i>
            <br>
            double myFloatNum = <i>5.99</i>; <i style="color: yellow;">//Floating point number (with decimals)</i>
            <br>
            char myLeter = <i>'D'</i>; <i style="color: yellow;">//Character</i>
            <br>
            string myText = <i>'D'</i>; <i style="color: yellow;">//String Text</i>
            <br>
            bool myBoolean = <i>'true'</i>; <i style="color: yellow;">//Boolean (true or false)</i>
        </h2>
        <p>You will learn more about the individual types in the Data Types chapter</p>
            <!-- fifth topic end -->



            <!-- ////////////////////////////////////// -->
            <!-- sixth topic start -->
            <h3>Dispaly Variables</h3>
            <p style="text-align: justify; margin-right: 20px;">
                The cout object is used together with the << operator to display variables.
                To combine both text and a variable, separate them with the << operator:
            </p>
            <!-- code part start -->
            <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
    int myAge=<i>35</i>;
    cout << "I am "&lt;< myAge &lt;<"years old.";
    return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>I am 35 years old.</h1>    
        </div>
        </div>
        <!-- code part end -->
            <!-- sixth topic end -->


            <!-- /////////////////////////////////////////////// -->
            <!-- seventh topic start  -->
            <h3>Add Variables Together</h3>
            <p style="text-align: justify; margin-right: 20px;">
                To add variable to another variable, you can use the + operator:
            </p>
            <!-- code part start -->
            <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
    int x = <i>5</i>;
    int y = <i>6</i>;
    int sum = x+y;
    cout << sum;
    return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>11</h1>    
        </div>
        </div>
            <!-- seventh topic end -->

            <!-- /////////////////////////////////////////////// -->
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SIXTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="C++_variables_rules(7).php"><button id="next">Next&#187;</button></a>
            <a href="C++_comments(5).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "Which is correct syntax of variable?",
            a: [{ text: "int 5;", isCorrect: false },
            { text: "a=5;", isCorrect: false },
            { text: "int a = 5;", isCorrect: true },
            { text: "all", isCorrect: false }
            ]

        },
        {
            q: "The = equal sign is used for",
            a: [{ text: "All", isCorrect: false, isSelected: false },
            { text: "None", isCorrect: false },
            { text: "for comparison", isCorrect: false },
            { text: "assigning value", isCorrect: true }
            ]

        },
        {
            q: "To add variable to another variable, you can use the",
            a: [{ text: "%operator", isCorrect: false },
            { text: "* operator", isCorrect: false },
            { text: "+ operator", isCorrect: true },
            { text: "All", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>
