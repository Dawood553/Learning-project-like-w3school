<?php
include('c++_header.php');
?>
<title>C++ OutPut</title>
    <div class="container"> 
        <br>
        <div class="notes">

            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intr">C++ OutPut</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>C++ Output(Print Text)</h3>
            <p style="text-align: justify; margin-right: 20px;">
The cout object, together with the << operator, is used to output values/print text: 
            </p>
            <!-- Code part start -->
            <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
  cout << "Hello World!";
  return 0;
}
        </pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World!</h1>    
        </div>
        </div>
        <!-- code part end -->
            <p style="text-align: justify; margin-right: 20px;">
You can add as many cout objects as you want. However, note that it does not insert a new line 
at the end of output:
            </p>
            

            <!-- code part start -->
            <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
  cout << "Hello World!";
  cout << "I am learning C++";
  return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World! I am learning C++</h1>    
        </div>
        </div>
        <!-- code part end -->

        <p><b>Tip:</b> Two \n character after each other will create a blank line:</p>
        
        <!-- code part start -->
        <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
  cout << "Hello World!<b>\n\n</b>";
  cout << "I am learning C++";
  return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World!</h1>    
            <h1>I am learning C++</h1>    
        </div>
        </div>
        <!-- code part end -->
        <p>Another way to insert a new line, is with endl manipulator:</p>
        <!-- Second topic end -->


      <!--tHIRD TOPIC END-->

      <!-- code part start -->
      <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
  cout << "Hello World!<b>&lt;&lt;endl</b>";
  cout << "I am learning C++";
  return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World!</h1>    
            <h1>I am learning C++</h1>    
        </div>
        </div>
        <!-- code part end -->
        <p>Both \n and endl are used to break lines. However, \n is most used.</p>
        <!-- Third topic end -->


        <!-- fourth topic start -->
            <h3>But what is \n exactly</h3>
            <p style="text-align: justify; margin-right: 20px;">
The newline character (\n) is called as <b>escape sequence</b>, and it forces the cursor
to change its position to the begining of the next line on the screen. This results in a new line.
            </p>
            <!-- fourth topic end -->


      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FOURTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="C++_comments(5).php"><button id="next">Next&#187;</button></a>
            <a href="C++_Syntax(3).php"><button id="previous">&laquo;Previous</button></a>
            <br>

    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "Why cout object is used?",
            a: [{ text: "none", isCorrect: false },
            { text: "select", isCorrect: false },
            { text: "output", isCorrect: true },
            { text: "input", isCorrect: false }
            ]

        },
        {
            q: "Why endl manipulator used?",
            a: [{ text: "to end the statement", isCorrect: false, isSelected: false },
            { text: "to end the block", isCorrect: false },
            { text: "to end the line", isCorrect: false },
            { text: "to insert new line", isCorrect: true }
            ]

        },
        {
            q: "Can you add many cout object or not;",
            a: [{ text: "i don't know", isCorrect: false },
            { text: "No", isCorrect: false },
            { text: "Yes", isCorrect: true },
            { text: "none", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>
