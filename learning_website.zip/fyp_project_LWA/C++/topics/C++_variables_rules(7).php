<?php
include('c++_header.php');
?>
<title>C++ Variable Rules</title>

    <div class="container"> 
        <br>
        <div class="notes">

            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intr">C++ Variables Rules</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>C++ Variables Rules</h3>
            <p style="text-align: justify; margin-right: 20px;">
                A variable can have alphabets, digits and underscore.<br>
                A variable name can start with alphabet and underscore only. It can't start with digit. <br>
                No white space is allowed within variable name. <br>
                A variable name must not be any reserved word or keyword e.g. <b>char</b><b>flaot</b>etc.
            </p>
            <!--FIRST TOPIC END-->

            <!-- ///////////////////////// -->
            <!--SECOND TOPIC START-->

            
<h4 style="margin-left: 2%;">valid variable names;</h4>
        <div id="out">
            <div class="output">
            <h1>int a;</h1>
            <br>
            <h1>int _ab;</h1>
            <br>
            <h1>int a30;</h1>    
        </div>
        </div>
        <!-- code part end -->
        <h4 style="margin-left: 2%;">invalid variable names;</h4>
        <div id="out">
            <div class="output">
            <h1>int 4;</h1>
            <br>
            <h1>int a b;</h1>
            <br>
            <h1>int double;</h1>    
        </div>
        </div>
            

            <!-- /////////////////////////////////////////////// -->
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SEVENTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="C++_data_types(8).php"><button id="next">Next&#187;</button></a>
            <a href="C++_variables(6).php"><button id="previous">&laquo;Previous</button></a>
            <br>
    <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->
    <br>
    </div>
    </div>
 

<!-- for languages -->
<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>
