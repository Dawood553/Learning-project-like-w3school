<?php
include('c++_header.php');
?>
<title>C++ DataTypes</title>

    
    <div class="container"> 
        <br>
        <div class="notes">
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intr">C++ Data Types</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>C++ Data Types</h3>
            <p style="text-align: justify; margin-right: 20px;">
               A data types specifis the type of data that a variable can store such as integer, floating, character etc
               <br> <b>There are 4 types of data types in C++ language.</b>      
            </p>
            <table border="1" width="100%" style="text-align:center;">
                <tr>
                    <th>Types</th>
                    <th>Data Types</th>
                </tr>
                <td>Basic Data Type</td>
                <td>int, char, float, double, etc</td>
    </tr>
    </tr>
                <td>Derived Data Type</td>
                <td>array, pointer, etc</td>
    </tr>
    </tr>
                <td>Enumeration Data Type</td>
                <td>enum</td>
    </tr>
    </tr>
                <td>User Defined Data Type</td>
                <td>Structure</td>
    </tr>
            </table>
            <h3>Basic Data Types</h3>
            <p style="text-align: justify; margin-right: 20px;">
               The Basic data types are integer-based and floating-point based. C++ language supports both signed and 
               unsigned literal. The memory size of basic data types may change according to 32 or 64 bit operating system.
               
                     
            </p>
            <h3>Let's see the basic data types. It size is given according to 32 bit OS.</h3>
            <table  border="1" width="100%" style="text-align:center;">
                <tr style="background-color:balck;color:white; padding:5px;">
                    <th>Data Types</th>
                    <th>Memory Size</th>
                    <th>Range</th>
                </tr>
                <td>Char</td>
                <td>1 byte</td>
                <td>-128 to 127</td>
    </tr>
    </tr>
                <td>Signed Char</td>
                <td>1 byte</td>
                <td>0 to 127</td>
    </tr>
    </tr>
                <td>Short</td>
                <td>2 byte</td>
                <td>-32,768 to 32,767</td>
    </tr>
    </tr>
                <td>Signed Short</td>
                <td>2 byte</td>
                <td>-32,768 to 32,767</td>
    </tr>
    </tr>
                <td>Unsigned Short</td>
                <td>2 byte</td>
                <td>0to 32,767</td>
    </tr>
    </tr>
                <td>Int</td>
                <td>2 byte</td>
                <td>-32,768 to 32,767</td>
    </tr>
    </tr>
                <td>Signed Int</td>
                <td>2 byte</td>
                <td>-32,768 to 32,767</td>
    </tr>
    </tr>
                <td>Unsigned Int</td>
                <td>2 byte</td>
                <td>0 to 32,767</td>
    </tr>
    </tr>
                <td>Short Int</td>
                <td>2 byte</td>
                <td>-32,768 to 32,767</td>
    </tr>
    </tr>
                <td>Signed Short Int</td>
                <td>2 byte</td>
                <td>-32,768 to 32,767</td>
    </tr>
    </tr>
                <td>Unsigned Short Int</td>
                <td>2 byte</td>
                <td>0 to 32,767</td>
    </tr>
    </tr>
                <td>Long Int</td>
                <td>4 byte</td>
                <td>-</td>
    </tr>
    </tr>
                <td>Signed Long Int</td>
                <td>4 byte</td>
                <td>-</td>
    </tr>
    </tr>
                <td>Unsigned Long Int</td>
                <td>4 byte</td>
                <td>-</td>
    </tr>
    </tr>
                <td>float</td>
                <td>4 byte</td>
                <td>-</td>
    </tr>
    </tr>
                <td>Double</td>
                <td>8 byte</td>
                <td>-</td>
    </tr>
    </tr>
                <td>Long Double</td>
                <td>10 byte</td>
                <td>-</td>
    </tr>
            </table>

            


            <!-- /////////////////////////////////////////////// -->
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END EIGHT LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="C++_key_words(9).php"><button id="next">Next&#187;</button></a>
            <a href="C++_variables_rules(7).php"><button id="previous">&laquo;Previous</button></a>
            <br>
    <br>
    </div>
    </div>
 

<!-- for languages -->
<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>
