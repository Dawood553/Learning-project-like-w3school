<?php
include('c++_header.php');
?>
<title>C++ Key Words</title>
    <div class="container"> 
        <br>
        <div class="notes">

            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intr">C++ Key Words</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>C++ Key Words</h3>
            <p style="text-align: justify; margin-right: 20px;">
               A Key Words is a reserved word. YOu cannot use it as a variable name, constant name etc.      
            </p>
            <p style="text-align: justify; margin-right: 20px;">
            <b>A list of 32 keywords in C++ language which are also available in C language are given below:</b>     
            </p>
            <table border="1" width="100%" style="text-align:center;">
                <tr>
                <td>auto</td>
                <td>break</td>
                <td>case</td>
                <td>char</td>
    </tr>
    <tr>
                <td>const</td>
                <td>continue</td>
                <td>default</td>
                <td>do</td>
    </tr>
    <tr>
                <td>double</td>
                <td>else</td>
                <td>enum</td>
                <td>extern</td>
    </tr>
    <tr>
                <td>float</td>
                <td>for</td>
                <td>goto</td>
                <td>if</td>
    </tr>
    <tr>
                <td>int</td>
                <td>long</td>
                <td>register</td>
                <td>return</td>
    </tr>
    <tr>
                <td>short</td>
                <td>signed</td>
                <td>size of</td>
                <td>static</td>
    </tr>
    <tr>
                <td>struct</td>
                <td>switch</td>
                <td>typedef</td>
                <td>union</td>
    </tr>
    <tr>
                <td>Unsigned</td>
                <td>void</td>
                <td>volatile</td>
                <td>while</td>
    </tr>
            </table>
            <p style="text-align: justify; margin-right: 20px;">
            <b>A list of 32 keywords in C++ language which are not available in C language are given below:</b>     
            </p>
            <table  border="1" width="100%" style="text-align:center;">
                <tr style="background-color:balck;color:white; padding:5px;">
                    <th>Dynamic_cast</th>
                    <th>namespace</th>
                    <th>reinterpret_cast</th>
                </tr>
                <td>explicit</td>
                <td>new</td>
                <td>static cast</td>
    </tr>
    </tr>
                <td>operator</td>
                <td>template</td>
                <td>friend</td>
    </tr>
    </tr>
                <td>this</td>
                <td>inline</td>
                <td>public</td>
    </tr>
    </tr>
                <td>throw</td>
                <td>private</td>
                <td>false</td>
    </tr>
    </tr>
                <td>delete</td>
                <td>mutable</td>
                <td>protected</td>
    </tr>
    </tr>
                <td>typeid</td>
                <td>type name</td>
                <td>using</td>
    </tr>
    </tr>
                <td>wchat_t</td>
                <td>try</td>
                <td>const_cast</td>
    </tr>
    </tr>
                <td>bool</td>
                <td>class</td>
                <td>catch</td>
    </tr>
    </tr>
                <td>asm</td>
                <td>virtual</td>
                <td>true</td>
    </tr>
   
            </table>

            
            <!-- /////////////////////////////////////////////// -->
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END NINETH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="C++_operator(10).php"><button id="next">Next&#187;</button></a>
            <a href="C++_data_types(8).php"><button id="previous">&laquo;Previous</button></a>
            <br>
    <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->
    <br>
    </div>
    </div>
 

<!-- for languages -->
<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>
