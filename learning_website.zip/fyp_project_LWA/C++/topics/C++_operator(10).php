<?php
include('c++_header.php');
?>
<title>C++ Operators</title>
    <div class="container"> 
        <br>
        <div class="notes">

            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intr">C++ Operators</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>C++ Operators</h3>
            <p style="text-align: justify; margin-right: 20px;">
               An operator is a simply assemble that is used to perform operation. There can be many types of operations 
               like arithmatic, logical, bitwise, etc
            </p>
            <p style="text-align: justify; margin-right: 20px;">
            <b>There are following types of operators to perform different types of operations in C language.</b> 
            <br>
            <ol>
                <li>Arithmatic Operators</li>
                <li>Relation Operators</li>
                <li>logical Operators</li>
                <li>Bitwise Operators</li>
                <li>Assignment Operators</li>
                <li>Unary Operators</li>
                <li>Ternary Or Conditional Operators</li>
                <li>Misc operators</li>
            </ol>    
            </p>
            <h3>Precendence of Operators in C++</h3>
            <p style="text-align: justify; margin-right: 20px;">
               The Precendence of Operator species that which operator will be evaluated first and next. The associativity
               specifies the operators direction to be evaluated, it may be left to right or right to left.
            </p>

            <p style="text-align: justify; margin-right: 20px;">
              <b>Let's understand the precendence by the example given below:</b>
            </p>
            <!-- Code part start -->
            <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
    int data = 5+10*10;
  cout << data;
  return 0;
}
        </pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>105</h1>    
        </div>
        </div>
        <!-- code part end -->
        <p style="text-align: justify; margin-right: 20px;">
               The "data" variable will contain 105 because * (multiplicative operator) is evaluated before + (additive operator)
               
            </p>
            <p style="text-align: justify; margin-right: 20px;">
             <b>The precendence and associativity of C++ operators to given below:</b>
            </p>




            <table border="1" width="100%" style="text-align:center;">
            <tr>
                <th>Category</th>
                <th>Operator</th>
                <th>Asoociativity</th>
            </tr>
                <tr>
                <td>Postfix</td>
                <td>() [] -> . ++ --</td>
                <td>Left to Right</td>
    </tr>
    <tr>
                <td>Unary</td>
                <td>+ - ! ~ ++ -- (type) * & sizeof</td>
                <td>Right to Left</td>
    </tr>
    <tr>
                <td>Muliplicative</td>
                <td>* / %</td>
                <td>Left to Right</td>
    </tr>
    <tr>
                <td>Addative</td>
                <td>+,-</td>
                <td>Right to Left</td>
    </tr>
    <tr>
                <td>Shift</td>
                <td><< >></td>
                <td>Left to Right</td>
    </tr>
    <tr>
                <td>Relational</td>
                <td>< <= > >=</td>
                <td>Left to Right</td>
    </tr>
    <tr>
                <td>Equality</td>
                <td>== != /td></td>
                <td>Right to Left</td>
    </tr>
    <tr>
                <td>Bitwise And</td>
                <td>&</td>
                <td>Left to Right</td>
    </tr>
    <tr>
                <td>Bitwise Xor</td>
                <td>^</td>
                <td>Left to Right</td>
    </tr>

    <tr>
                <td>Bitwise Or</td>
                <td>|</td>
                <td>Right to Left</td>
    </tr>
    <tr>
                <td>Logical And</td>
                <td>&&</td>
                <td>Left to Right</td>
    </tr>
    <tr>
                <td>Logical OR</td>
                <td>||</td>
                <td>Left to Right</td>
    </tr>
    <tr>
                <td>Conditional</td>
                <td>?:</td>
                <td>Right to Left</td>
    </tr>
    <tr>
                <td>Assignment</td>
                <td>= += -= *= /= %= >>= <<= &= ^= |=</td>
                <td>Right to Left</td>
    </tr>
    <tr>
                <td>Comma</td>
                <td>,</td>
                <td>Left to Right</td>
    </tr>




            </table>
           

            


            <!-- /////////////////////////////////////////////// -->
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END TENTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="#"><button id="next">End&#187;</button></a>
            <a href="C++_key_words(9).php"><button id="previous">&laquo;Previous</button></a>
            <br>
    <br>
    </div>
    </div>
 

<!-- for languages -->
<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>
