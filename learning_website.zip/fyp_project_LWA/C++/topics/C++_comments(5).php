<?php
include('c++_header.php');
?>
<title>C++ Comments</title>
    <div class="container"> 
        <br>
        <div class="notes">

            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intr">C++ Comments</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>C++ Comments</h3>
            <p style="text-align: justify; margin-right: 20px;">
                Comments can be used to explain C++ code, and to make it more readable. It can also
                be used to prevent execution when testing alternative code. Comments can be singled-line or 
                multi-lined
            </p>
        

            <h3>Single-line Comments</h3>
            <p style="text-align: justify; margin-right: 20px;">
                Single-line Comments start with two forward slashes(//). Any text between
                // and the end of the line is ignored by the compiler (will not be executed).
            </p>
            <!-- code part start -->
            <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
    
  cout << "Hello World!";<i style="color: rgb(249, 252, 56);">//This is a comment</i>
  return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World!</h1>    
        </div>
        </div>
        <p>This Example uses a singled-line comment at the end of a line of code</p>
       

      <!--tHIRD TOPIC END-->
      <h3>C++ Multi-line Comments</h3>
            <p style="text-align: justify; margin-right: 20px;">
                Multi-line comment start with /* and ends with */. Any text between /* and */
                will be ignored by the compiler:
            </p>
            <!-- code part start -->
            <h3>Example</h3>
            <pre id="precode">
<i id="codecolor">#include &lt;iostream></i>
<i id="codecolor">using namespace std;</i>
int main() 
{
    <i style="color: rgb(249, 252, 56);">/* The code below will print the 
    words Hello World!
     to the screen, and it is amazing*/</i> 

  cout << "Hello World!";
  return 0;
}
        </pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World!</h1>    
        </div>
        </div>

            <h3>Single or Multi-line comments?</h3>
            <p style="text-align: justify; margin-right: 20px;">
                It is up to you which you want to use. Normally, we use // for short comments, 
                and /**/ for longer.
            </p>


      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIFTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="C++_variables(6).php"><button id="next">Next&#187;</button></a>
            <a href="C++_output(4).php"><button id="previous">&laquo;Previous</button></a>
            <br>

            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "Comments can be",
            a: [{ text: "All", isCorrect: false },
            { text: "only multiple line", isCorrect: false },
            { text: "only single line", isCorrect: false },
            { text: "singled-line or multi-lined", isCorrect: true }

            ]

        },
        {
            q: "Single-line Comments start with",
            a: [{ text: "\\", isCorrect: false, isSelected: false },
            { text: "//", isCorrect: true },
            { text: "*/", isCorrect: false },
            { text: "/*", isCorrect: false }
            ]

        },
        {
            q: "Multi-line comment start with",
            a: [{ text: "**", isCorrect: false },
            { text: "//", isCorrect: false },
            { text: "/*", isCorrect: true },
            { text: "All", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>
