<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="icon" href="title.jpg">
    <link rel="stylesheet" href="/fyp_project_LWA/config/style2.css">
    <link rel="stylesheet" href="/fyp_project_LWA/config/quiz.css">

<style>


</style>
</head>
<body>
    <!--SIDE MENU BAAR CODING START -->
    <div id="sideNav">
        <br>
        <br>
        <a href="\fyp_project_LWA\C++\index.php">Home</a>
        <a href="#">Online Compiler</a>
        <input id="searchbar" onkeyup="search_subject()" type="text" name="search" placeholder="Search Lecture..">
        <hr> 
        <ol id="list" style="list-style: none;">            
        <h2 style="color: white;text-align: center;">Lectures</h2>    
        <li><a href="Introduction of c++(1).php" class="subject">Introdution of C++</a></li>
        <li><a href="Get_started(2).php" class="subject">Getting Start C++</a></li>
        <li><a href="C++_Syntax(3).php" class="subject">C++ syntax</a></li>
        <li><a href="C++_output(4).php" class="subject">C++ Output</a></li>
        <li><a href="C++_comments(5).php" class="subject">C++ Comments</a></li>
        <li><a href="C++_variables(6).php" class="subject">C++ Variables</a></li>
        <li><a href="C++_variables_rules(7).php" class="subject">C++ Variables Rules</a></li>
        <li><a href="C++_data_types(8).php" class="subject">C++ Data Types</a></li>
        <li><a href="C++_key_words(9).php" class="subject">C++ Key Words</a></li>

<li><a href="C++_operator(10).php" class="subject">C++ Operators</a></li>
    </div>
    <!-- code for search button  -->
    <script>
        function search_subject() { 
            let input = document.getElementById('searchbar').value 
            input=input.toLowerCase(); 
            let x = document.getElementsByClassName('subject'); 
        for (i = 0; i < x.length; i++) {  
                if (!x[i].innerHTML.toLowerCase().includes(input)) { 
                    x[i].style.display="none"; 
          }
                else { 
                    x[i].style.display="list-item";                  
                } 
        }
        }
        </script>

<!-- code for search button end -->
    <div id="manuBtn">
        <!--<img src="menu.png" id="menu">-->
        <p style="color:white;" id="topics">TOPICS</p>            
    </div>

<script>
        var manuBtn = document.getElementById("manuBtn")
        var sideNav = document.getElementById("sideNav")
        var menus = document.getElementById("menu")           
        sideNav.style.right = "-500px";
        manuBtn.onclick = function()
          {
            if(sideNav.style.right == "-500px"){
                sideNav.style.right ="0"
                
                menu.src = "close.jpg";                  
            }
            else{
                sideNav.style.right ="-500px"
                menu.src = "close.jpg";
            }
        }
    </script>
    <!--SIDE MENU BAAR CODING END-->