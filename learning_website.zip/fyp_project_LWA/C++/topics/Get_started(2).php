<?php
include('c++_header.php');
?>
<title>C++ Get Started</title>
    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Get Start C++</h2>
             <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Get Started C++?</h3>
            <p style="text-align: justify; margin-right: 20px;">
To start using C++, you need two things: 
A text editor, like Notepad, to write C++ code 
A compiler, like GCC, to translate the C++ code into a language that the computer will understand 
There are many text editors and compilers to choose from. In this tutorial, we will use an IDE (see below). 

            </p>
            <h3>C++ Install IDE</h3>
            <p style="text-align: justify; margin-right: 20px;">
An IDE (Integrated Development Environment) is used to edit AND compile the code. 
Popular IDE's include Code::Blocks, Eclipse, and Visual Studio. These are all free, and they can be used to both edit and debug C++ code. 
Note: Web-based IDE's can work as well, but functionality is limited. 
We will use Code::Blocks in our tutorial, which we believe is a good place to start. 
You can find the latest version of Codeblocks at http://www.codeblocks.org/. Download the mingw-setup.exe file, which will install the text editor with a compiler. 

</p>
            <h3>C++ Quick-start</h3>
            <p style="text-align: justify; margin-right: 20px;">
Let's create our first C++ file. 
Open Code-blocks and go to File > New > Empty File. 
Write the following C++ code and save the file as  

 </p>
<!--FIRST TOPIC END-->

                 
      <!--tHIRD TOPIC END-->
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SECOND LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="C++_Syntax(3).php"><button id="next">Next&#187;</button></a>
            <a href="Introduction_of_c++(1).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "An IDE is",
            a: [{ text: "Information Development Environment", isCorrect: false },
            { text: "Integrated Development Environment", isCorrect: true },
            { text: "International Development Environment", isCorrect: false },
            { text: "All", isCorrect: false }
            ]

        },
        {
            q: "To Start a C++ what you need?",
            a: [{ text: "none", isCorrect: false, isSelected: false },
            { text: "source code", isCorrect: false },
            { text: "program", isCorrect: false },
            { text: "text editor,", isCorrect: true }
            ]

        },
        {
            q: "What is the Extension of C++?",
            a: [{ text: ".xls", isCorrect: false },
            { text: ".doc", isCorrect: false },
            { text: ".cpp", isCorrect: true },
            { text: ".ppt", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>