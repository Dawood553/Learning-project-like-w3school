<?php
$con=mysqli_connect('localhost','root','','private_db');
?>
<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        #php{
            color:white;
            border:1px solid white; 
            border-radius:5px;
            background-color:red;
            height: 50px;
            font-size:32px;
        }
    </style>
    <link rel="icon" href="">
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="\fyp_project_LWA\config\login_style.css">
</head>
<body>
    <div class="container">
        <a href="http://localhost/fyp_project_LWA/index.php" class="text-center" style="font-size:25px; width:5%;">&laquo;</a>
        <div class="row">
            <div class="col-lg-3 col-md-2"></div>
            <div class="col-lg-6 col-md-8 login-box">
                <div class="col-lg-12">
                </div>
                <div class="col-lg-12 login-title">
                    ADMIN LOGIN
                </div>
                <div class="col-lg-12 login-form">
                    <div class="col-lg-12 login-form">
                        <form method="post" action="#" name="f1" onsubmit="return validation()">
                            <div class="form-group">
                                <label class="form-control-label">EMAIL</label>
                                <input type="email" name="username" class="form-control" pattern="[a-zA-z0-9]+@+gmail.com" title="Abc123@gmail.com">
                            </div>
                            <div class="form-group">
                                <label class="form-control-label">PASSWORD</label>
                                <input type="password" name="password" class="form-control" minlength="8">
                            </div>
                            <div class="col-lg-12 loginbttm">
                                <div class="col-lg-6 login-btm login-text">
                                    <!-- Error Message -->
                                </div>

<!-- login start for admin -->
                                <?php
if(isset($_POST['lgn'])){
    $username=$_POST['username'];
    $password=$_POST['password'];
    $select=mysqli_query($con,"SELECT * FROM `admin_register` WHERE `email`='$username' AND `status`='1';");
    // $select=mysqli_query($con,"SELECT `full_name`, `email` FROM `admin_register` WHERE `email`='$username' AND `password`='$password';");
    $total=mysqli_num_rows($select);
    if($total==1)
    {
        $_SESSION['uname']=$username;
        header('location:http://localhost/fyp_project_LWA/admins/admin.php');
    }
    else
    {
        // echo "<center id='php'><b>Invalid Email & Password Or Status Is Pending</b></center>";
        echo '<div class="col-12">
        <div class="alert alert-danger bg-danger text-white mt-1">
        <div class="row">
        <div class="col-md-11"><p>Invalid Email & Password</p></div>
            
              <div class="col-md-1"><button class="close btn btn-success active" data-dismiss="alert" style="margin-right:auto;">
              X
             </button></div>
        </div></div> ';
        
    }
}
?>
<!-- login end for admin -->
                                <!-- login for super admin -->

                                <?php
if(isset($_POST['lgn'])){
    $username2=$_POST['username'];
    $password2=$_POST['password'];
    $select2=mysqli_query($con,"SELECT * FROM `super_admin` WHERE `super_admin`='$username2' AND `password`='$password2';");
    $total2=mysqli_num_rows($select2);
    if($total2==1)
    {
        $_SESSION['uname2']=$username2;
        header('location:http://localhost/fyp_project_LWA/admins/superadmin/super-admin.php');
    }
    else
    {
        // echo "<center id='php'><b>Invalid Email & Password</b></center>";
        echo '<div class="col-12">
        <div class="alert alert-danger bg-danger text-white mt-1">
        <div class="row">
        <div class="col-md-11"><p>Invalid Email & Password</p></div>
            
              <div class="col-md-1"><button class="close btn btn-success active" data-dismiss="alert" style="margin-right:auto;">
              X
             </button></div>
        </div></div> ';
        
    }
}
?>




                                <!-- login end for super admin -->
<br>
                                <div class="col-lg-7 login-btm login-button">
                                    <input type="submit" name="lgn" class="btn btn-outline-primary" value="LOGIN">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2"></div>
            </div>
        </div>
        <!-- ////////////////////////// -->
        <!-- JAVASCRIPT CODE FOR VALIDATION -->
        <script>
            function validation(){
				let email=document.f1.email.value;
				let pass=document.f1.password.value;
				if(email=="")
				{
					alert("Email Is Empty");
					return false;
				}
				if(pass=="")
				{
					alert("Password Is Empty");
					return false;
				}
			}
        </script>
        <!-- ///////////////////////////////////// -->
        <!-- JAVASCRIPT CODE END -->
</body>
</html>

