<?php
session_start();
    session_unset();
    session_destroy();
    // echo "<script>location.href='http://localhost/fyp_project_LWA/index.php'</script>";
     header("location:http://localhost/fyp_project_LWA/LOGIN/login2.php");


?>