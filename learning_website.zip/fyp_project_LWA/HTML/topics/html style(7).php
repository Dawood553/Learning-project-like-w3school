<?php
include('html_header.php');
?>
    <title>HTML Style</title>

    <div class="container only-print">
    
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML Style</h2>
              <!-- for languages -->
              <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>HTML Style</h3>
            <p style="text-align: justify; margin-right: 20px;">
                HTML Style are used to style HTML elements it also means changing default values.
                For Instance, Styling can change the default values of text color as black, background
                color as white, text alignement as left and text size as 12 pixels.
            </p>
            <!-- Example start -->
<!-- example end -->
            <h3>internal Style Sheet (internal Styling)</h3>
            <p style="text-align: justify; margin-right: 20px;">
                Using an internal style sheet is also called internal styling. An internal Style Sheet
                is also called internal styling. An internal Style Sheet is composed of one or more 
                Cascading Style Sheet (CSS) rule-set. A CSS rule-set consists of a selector and a declaration block surrounded by curly braces
                that contains one or more CSS declarations separated by semicolons. Each declarations
                includes a CSS property name and a vlaue, separated by a colon. They are all enclosed 
                inside the <b>&lt;style></b>element which is included inside the <b>&lt;head></b>element.
            </p>
             <!-- Example start -->
 <h3>Internal Style Sheet Syntax</h3>
<pre id="precode">
<i>&lt;style></i>
<i>&lt;p</i>
{
    <strong>font-size:<strong id="pink">12px;</strong></strong>
}
<i>&lt;/style></i>
</pre>
<p style="background-color: rgb(52, 105, 123);padding: 5px 5px 5px 5px; border-radius: 10px;">There will be a lot of internal Styling examples throughout the entire tutorial so jest keep
    going and enjoy!;
</p>
<!--FIRST TOPIC END-->
 <!--FIRST TOPIC END-->
 
<!--Second TOPIC START-->
<h3>Inline Styling</h3>
            <p style="text-align: justify; margin-right: 20px;">
                 Inline styling is used to style elements using the <b>style</b> attribute with 
                 CSS declarations inside which are similar to internal styling.
            </p>
             <!-- Example start -->
 <h3>Inline Style Sheet Syntax</h3>
<pre id="precode">
<i>&lt;div <strong>style= <strong id="pink">"property:value; property:value;"</strong></i><i>></i>
</pre>
<!--Second TOPIC END-->
<!-- example start -->
<h3>background Color Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body <strong>style=</strong><strong id="pink">"background-color:gold;</strong>></i>
<strong>&lt;!-- content goes here--&gt;</strong>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p style="background-color: gold;color: gold;">.</p>    
        </div>
        </div> 
 <!-- Example end -->

 <!-- example start -->
<h3>Text Color Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;p <strong>style = <strong id="pink">"color:blue"<i>></i></strong></strong></i> <strong id="white">My color is blue.</strong> <i>&lt;/p></i>
<i>&lt;p <strong>style = <strong id="pink">"color:red"<i>></i></strong></strong></i> <strong id="white">My color is red.</strong> <i>&lt;/p></i>
<i>&lt;p <strong>style = <strong id="pink">"color:green"<i>></i></strong></strong></i> <strong id="white">My color is green.</strong> <i>&lt;/p></i>
<i>&lt;p <strong>style = <strong id="pink">"color:yellow"<i>></i></strong></strong></i> <strong id="white">My color is yellow.</strong> <i>&lt;/p></i>
<i>&lt;p <strong>style = <strong id="pink">"color:pink"<i>></i></strong></strong></i> <strong id="white">My color is pink.</strong> <i>&lt;/p></i>

<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p style="color: blue;">My color is blue.</p>
            <p style="color: red;">My color is red.</p>
            <p style="color: green;">My color is green.</p>
            <p style="color: yellow;">My color is yellow.</p>
            <p style="color: pink;">My color is pink.</p>
        </div>
        </div> 
 <!-- Example end -->

 <!-- example start -->
<h3>Text Font-Family Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;h1 <strong>style = <stong id="pink">"font-family: Times New Roman;"</i></stong></strong>></i> <strong id="white">I am a Times New Roman</strong> <i>&lt;/h1>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p style="font-family: 'Times New Roman', Times, serif;">I am a Times New Roman</p>
        </div>
        </div> 
 <!-- Example end -->

 <!-- example start -->
<h3>Text-Sizing Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;p <strong>style = <strong id="pink">"font-size:25px"<i>></i></strong></strong></i> <strong id="white">My size is 25 pixels</strong> <i>&lt;/p></i>
<i>&lt;p <strong>style = <strong id="pink">"font-size:50px"<i>></i></strong></strong></i> <strong id="white">My size is 50 pixels</strong> <i>&lt;/p></i>

<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p style="font-size: 25px;">My size is 25 pixels</p>
            <p style="font-size: 50px;">My size is 50 pixels</p>

        </div>
        </div> 
 <!-- Example end -->

 <!-- example start -->
<h3>Text Font-Family Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;h1 <strong>style = <stong id="pink">"font-family: Times New Roman;"</i></stong></strong>></i> <strong id="white">I am a Times New Roman</strong> <i>&lt;/h1>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p style="font-family: 'Times New Roman', Times, serif;">I am a Times New Roman</p>
        </div>
        </div> 
 <!-- Example end -->

 <!-- example start -->
<h3>Text Aligning Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;p <strong>style = <strong id="pink">"text-align: left;"<i>></i></strong></strong></i> <strong id="white">I am aligned left</strong> <i>&lt;/p></i>
<i>&lt;p <strong>style = <strong id="pink">"text-align: center;"<i>></i></strong></strong></i> <strong id="white">I am alined center</strong> <i>&lt;/p></i>
<i>&lt;p <strong>style = <strong id="pink">"text-align: right;"<i>></i></strong></strong></i> <strong id="white">I am alined right</strong> <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p style="text-align: left;">I am aligned left</p>
            <p style="text-align: center;">I am aligned center</p>
            <p style="text-align: right;">I am aligned right</p>

        </div>
        </div> 
 <!-- Example end -->


    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SIXTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html section(8).php"><button id="next">Next&#187;</button></a>
            <a href="html text formatting(6).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
   

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>