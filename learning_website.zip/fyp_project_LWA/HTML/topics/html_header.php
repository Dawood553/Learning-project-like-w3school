<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="title.jpg">
    <!-- <link rel="stylesheet" href="style2.css"> -->
    <!-- <link rel="stylesheet" href="/fyp_project_LWA/config/style2.css"> -->
    <link rel="stylesheet" href="/fyp_project_LWA/config/style2.css">
    <link rel="stylesheet" href="/fyp_project_LWA/config/quiz.css">
    <!-- <link rel="stylesheet" href="quiz.css"> -->

<style>


</style>
</head>
<body>
    <!--SIDE MENU BAAR CODING START -->
    <div id="sideNav">
        <br>
        <br>
        <a href="\fyp_project_LWA\HTML\index.php">Home</a>
        <a href="Try it yourself.php">Code Area</a>


        <input id="searchbar" onkeyup="search_subject()" type="text" name="search" placeholder="Search Lecture..">
        <hr> 
        <ol id="list" style="list-style: none;">            
        <h2 id="lecture">Lectures</h2>    
        <li><a href="Introduction of html(1).php" class="subject">Introdution of HTML</a></li>
        <li><a href="html editor(2).php" class="subject">HTML Editors</a></li>
        <li><a href="html elements(3).php" class="subject">HTML Elements</a></li>
        <li><a href="html attributes(4).php" class="subject">HTML Attributes</a></li>
        <li><a href="html comments(5).php" class="subject">HTML Comments</a></li>
        <li><a href="html text formatting(6).php" class="subject">HTML Formatting</a></li>
        <li><a href="html style(7).php" class="subject">HTML Style</a></li>
        <li><a href="html section(8).php" class="subject">HTML Section</a></li>
        <li><a href="html description lists(9).php" class="subject">HTML Description Lists</a></li>
        <li><a href="html form(10).php" class="subject">HTML Form</a></li>
    </div>
    <!-- code for search button  -->
    <script>
        function search_subject() { 
            let input = document.getElementById('searchbar').value 
            input=input.toLowerCase(); 
            let x = document.getElementsByClassName('subject'); 
        for (i = 0; i < x.length; i++) {  
                if (!x[i].innerHTML.toLowerCase().includes(input)) { 
                    x[i].style.display="none"; 
          }
                else { 
                    x[i].style.display="list-item";                  
                } 
        }
        }
        </script>

<!-- code for search button end -->
    <div id="manuBtn">
        <!--<img src="menu.png" id="menu">-->
        <p style="color:white;" id="topics">TOPICS</p>            
    </div>

<script>
        var manuBtn = document.getElementById("manuBtn")
        var sideNav = document.getElementById("sideNav")
        var menus = document.getElementById("menu")           
        sideNav.style.right = "-500px";
        manuBtn.onclick = function()
          {
            if(sideNav.style.right == "-500px"){
                sideNav.style.right ="0"
                
                menu.src = "close.jpg";                  
            }
            else{
                sideNav.style.right ="-500px"
                menu.src = "close.jpg";
            }
        }
    </script>
    <!--SIDE MENU BAAR CODING END-->