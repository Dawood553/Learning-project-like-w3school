<?php
include('html_header.php');
?>
    <title>HTML Attributes</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML Attributes</h2>
              <!-- for languages -->
              <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>HTML Attributes</h3>
           
            <p style="text-align: justify; margin-right: 20px;">
                HTML attributes are used to add more information to an HTML Element.
            </p>
            <!-- Example start -->
<!-- <h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p></i>This is an element content. <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>This is an element content.</p>    
        </div>
        </div>  -->
<!-- example end -->
            <h3>Important Things to Remember</h3>
            <p style="text-align: justify; margin-right: 20px;">
                <ul>
                    <li>HTML attributes are found in HTML tags.</li>
                    <li>HTML attributes only appear at start tags. It will nover be on end tags.</li>
                    <li>HTML elements can have multiple attributes</li>
                    <li>HTML attributes are composed of name/value pairs.</li>
                    <li>There are some attributes that can be used on all HTML Elements though they may not have effects on some elements.
                         They are called Global Attributes
                    </li>
                </ul>
            </p>
            <p>
                An HTML attribute is composed of:
                <ul>
                    <li>on attribute name</li>
                    <li>an equla = sign</li>
                    <li>a value surrounded by quotation marks "value"</li>
                </ul>
            </p>
            <p>
                I looks like this: attributename="value" You can also use single quotation marks 
                depending on the situation esp. when the value contains double quotes. We will only 
                use double quotation marks throughout the entire toturial. <b>In this lesson we are going
                    to learn some HTML Attributes with example.
                </b>
            </p>
            
<!--FIRST TOPIC END-->
 <!-- Example start -->
 <h3>Attribute <b>lang</b> Example</h3>
 <pre id="precode">
 <i style="color: yellow;">&lt;!DOCTYPE html></i>
 <i>&lt;html <strong>lang="en-US"</strong>></i>
 &lt;--html document/file content goes here --&gt;

 ...
 <i>&lt;/html></i>
 </pre>
 <!-- example end -->
             <p style="text-align: justify; margin-right: 20px;">
                 We use the lang attribute to define the language of an HTML file. The 
                 language defined above is American English.
             </p>
 <!--FIRST TOPIC END-->
 <!-- Example start -->
<h3>Attribute <b>href</b> Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<strong>&lt;a href="html attributes(4).html"> Go to html attributes(4) &lt;/a></strong>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
 <div class="output">
 <p><a href="html attributes(4).html" style="color: blue;">Go to html attribute(4)</a></p>    
</div>
</div> 
<!-- example end -->
 <p style="text-align: justify; margin-right: 20px;">
     Links are defined using the anchor <b>&lt;a></b> tag element. On the example above we used the <b>href</b>
     attribute to tell the browser where to go. When we clicked the user will be redirected to 
     html attribute(4).
    </p>
    <!-- example start -->
    <h3>Attribute <b>title</b> Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;a</i> <strong>href="#link" title="i serve as a tooltip"</strong>> Link <i>&lt;/a></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
 <div class="output">
 <p><a href="#link" title="i serve as a tooltip" style="color: blue;">Link</a></p>    
</div>
</div> 
<!-- example end -->
 <p style="text-align: justify; margin-right: 20px;">
     The <b>title</b> attribute provides a tooltip for HTML Elements. Unfortunately, it doesn't 
     work on mobile device. If you want to see how it works save the file as <b>"filename.html"</b>
     and open it on a browser using a desktop, laptop etc.
    </p>
    <!-- example start -->
    <h3>Attribute <b>style</b> Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;p></i> <strong>style="font-size:40px; color:gold"</strong>>
i am peragraph with a font-size of 40 pixles and my color is gold.
<i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
 <div class="output">
 <p style="font-size: 40px; color: gold;">
i am peragraph with a font-size of 40 pixles and my color is gold.
</p>   
</div>
</div> 
<!-- example end -->
 <p style="text-align: justify; margin-right: 20px;">
     On the example given above we have created a peragraph using the <b>&lt;p></b> element. We
     also used the <b>style</b> attribute to change its font-size and color.
    </p>
    <!-- example start -->
    <h3>Attribute <b>id</b> and <b>class</b> Example</h3>
<pre id="precode">
<i>&lt;div <strong>class="name"</strong>></i>
&lt;--some content goes here--&gt;
...
<i>&lt;/div></i>

<i>&lt;div <strong>class="name"</strong>></i>
&lt;--some content goes here--&gt;

...
<i>&lt;/div></i>

<i>&lt;div <strong>id="name"</strong>></i>
&lt;--some content goes here--&gt;

...
<i>&lt;/div></i>
</pre>
<!-- example end -->
 <p style="text-align: justify; margin-right: 20px;">
     The <b>id</b>and <b>class</b> attribute give references to elements inside an HTML document.
     Multiple elements can have the same <b>class</b> values/names. The <b>id's</b> values should
     be unique for each element. These helpus select elements in style sheets and scripts.
    </p>

<!--Second TOPIC START-->

<!--Second TOPIC END-->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FOURTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html comments(5).php"><button id="next">Next&#187;</button></a>
            <a href="html elements(3).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "HTML attributes are found in:",
            a: [{ text: "CSS Selector", isCorrect: false },
            { text: "JS Script", isCorrect: false },
            { text: "HTML tags", isCorrect: true },
            { text: "None", isCorrect: false }
            ]

        },
        {
            q: "Where an HTML attribute is appear",
            a: [{ text: "All", isCorrect: false, isSelected: false },
            { text: "between", isCorrect: false },
            { text: "end tag", isCorrect: false },
            { text: "start tag", isCorrect: true }
            ]

        },
        {
            q: "The title attribute provides a _____ for HTML Elements",
            a: [{ text: "None", isCorrect: false },
            { text: "peragraph", isCorrect: false },
            { text: "tooltip", isCorrect: true },
            { text: "heading", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>