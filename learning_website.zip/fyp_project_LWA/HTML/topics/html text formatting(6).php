<?php
include('html_header.php');
?>
    <title>HTML Formatting</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML Text Formatting</h2>
              <!-- for languages -->
              <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>Text Formatting</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Formatting text is very essential for web sites. One of its uses is to help readers know the important parts a web content easily. 
            Elements for Formatting Text Al of the elements listed below are inline elements.
<br>
 &lt;b>: bolds a text
<br>
&lt;i>: italicizes a text
<br>
&lt;u>: underlines a text
<br>
&lt;code>: defines a text as a Code
<br>

&lt;tt>: typewriter text
<br>

&lt;small>: makes a text smaller
<br>

&lt;em>: emphasizes a text, may be italicized depending on the browser
<br>

&lt;strong>: emphasizes a text, may be boldened depending on the browser
<br>

&lt;mark>: marks a text like a highlighting pen
<br>

&lt;q>: enquotes a text
<br>

&lt;S>: strikes through a text
<br>
&lt;b>&lt;i>&lt;u>&lt;mark>&lt;q> I am a mixed format&lt;/mark>&lt;/u>&lt;/i>&lt;/b>

            </p>


           <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<span style="color:red;">&lt;p></span>&lt;b>i am bold text&lt;/b><span style="color:red;">&lt;/p></span>
<span style="color:red;">&lt;p></span>&lt;i>i am italicized text&lt;/i><span style="color:red;">&lt;/p></span>
<span style="color:red;">&lt;p></span>&lt;u>i am underline text&lt;/u><span style="color:red;">&lt;/p></span>

<span style="color:red;">&lt;p></span>&lt;code>i am code text&lt;/code><span style="color:red;">&lt;/p></span>
<span style="color:red;">&lt;p></span>&lt;tt>i am tupeWriter text&lt;/tt><span style="color:red;">&lt;/p></span>
<span style="color:red;">&lt;p></span>&lt;small>i am small text text&lt;/small><span style="color:red;">&lt;/p></span>

<span style="color:red;">&lt;p></span>&lt;em>i am emphasized text&lt;/em><span style="color:red;">&lt;/p></span>
<span style="color:red;">&lt;p></span>&lt;strong>i am strong text&lt;/mark><span style="color:red;">&lt;/p></span>
<span style="color:red;">&lt;p></span>&lt;q>i am quotation text&lt;/q><span style="color:red;">&lt;/p></span>
<span style="color:red;">&lt;p></span>&lt;b>&lt;i>&lt;u>&lt;mark>&lt;q>i am mixed text&lt;q>&lt;/mark>&lt;/u>&lt;/i>&lt;/b><span style="color:red;">&lt;/p></span>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
 <div class="output">
 <p><b style="color:red;">i am bold Text</b></p>    
 <p><i>i am italicized Text</i></p>    
 <p><u>i am underline text</u></p> 
 <p><code>i am code text</code></p>   
 <p><tt>i am tupeWriter text</tt></p>   
 <p><small>i am small text text</small></p>   
 <p><em>i am emphasized text</em></p>   
 <p><strong style="color:red;">i am strong text</mark></p>
 <p><q style="color:red;">i am quotation text</q></p>
 <p><b><i><u><mark><q>i am mixed text<q></mark></u></i></b></p>
</div>
</div> 
<!-- example end -->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SIXTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html style(7).php"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>