<?php
include('html_header.php');
?>
    <title>HTML Comments</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML Comments</h2>
              <!-- for languages -->
              <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>HTML Comments</h3>
            <p style="text-align: justify; margin-right: 20px;">
                HTML Comments are text, phrases or sentences inside an HTML file. They are only
                shown in codes and not rendered by a browser.
            </p>
            <!-- Example start -->
<!-- example end -->
            <h3>Why we use HTML Comments?</h3>
            <p style="text-align: justify; margin-right: 20px;">
                HTML Comments help both beginners and experienced web developers to easily organize
                their codes. They act like sticky notes in HTML files.
            </p>
            <h3>how to write HTML Comments?</h3>
            <p style="text-align: justify; margin-right: 20px;">
                An HTML Comments starts with <b>&lt;!--</b>and ends with <b>--&gt;</b> It looks like this:
            </p>
             <!-- Example start -->
 <pre id="precode">
 &lt;--comments goes here --&gt;
 </pre>
 <!-- example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;p></i>
Sentences shown on browser.
<strong>&lt;-- single-line comment --&gt;</strong>
<i>&lt;/p></i>

<i>&lt;p></i>
Sentences shown on browser.
<strong>&lt;-- this is a multi-line comment <br> some phrases go here <br> some phrases go here --&gt;</strong>
<i>&lt;/p></i>

<i>&lt;div></i><strong>&lt;-- putting comments beside a Start tag --&gt;</strong>
Sentences, HTML elements and imges etc. may appear here.
<i>&lt;/div></i><strong>&lt;-- putting comments beside a End tag --&gt;</strong>
</pre>
<!--FIRST TOPIC END-->
<h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
 <div class="output">
 <p>Sentences shown on browser.</p>    
 <p>Sentences shown on browser.</p>    
 <p>Sentences, HTML elements and images may appear here.</p>    
</div>
</div> 
 <!-- Example start -->

 <!-- example end -->
             <p style="text-align: justify; margin-right: 20px;">
                 On the example given above, you have learned that you can make a single-line and 
                 multi-line of HTML comments. And if you noticed we also put comments beside a start and end
                 tag. That is for us to easily recognize where a specific element start and ends.
             </p>
 <!--FIRST TOPIC END-->
 
<!--Second TOPIC START-->

<!--Second TOPIC END-->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIFTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html text formatting(6).php"><button id="next">Next&#187;</button></a>
            <a href="html attributes(4).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "An HTML Comments starts with __ and ends with __",
            a: [{ text: "All", isCorrect: false },
            { text: "/*", isCorrect: false },
            { text: "<!-- -->", isCorrect: true },
            { text: "//", isCorrect: false }
            ]

        },
        {
            q: "HTML Comments can be",
            a: [{ text: "<p/>", isCorrect: false, isSelected: false },
            { text: "only multiple line", isCorrect: false },
            { text: "only single line", isCorrect: false },
            { text: "singled-line or multi-lined", isCorrect: true }
            ]

        },
        

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>