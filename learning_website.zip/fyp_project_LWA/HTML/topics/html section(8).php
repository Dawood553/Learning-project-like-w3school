<?php
include('html_header.php');
?>
    <title>HTML Section</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML Sections</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>HTML Section</h3>
            <p style="text-align: justify; margin-right: 20px;">
            HTML Sections group different HTML Elements (e.g. text, heading, paragraphs, images etc.) together. Creating sections is essential for organizing and styling web contents. Elements Used for
HTML Sections
&lt;div>: used to group large group of HTML elements like navigation, header, main content, footer, images; it is a block-level element
&lt;span>: used to group smaller group of text in a paragraph and few HTML elements; it is an inline element

            </p>
            <!-- Example start -->
<!-- example end -->
            <h3>HTML Semantic</h3>
            <p style="text-align: justify; margin-right: 20px;">
             Elements Here is a list of HTML5 Semantic Elements that work similarly with the
&lt;div> element:
&lt;nav>: defines a navigation list or bar
&lt;header>: defines a header
&lt;main>: defines the main Content
&lt;footer>: defines a footer
Using these HTML5 semantic elements is not mandatory but it is still a good practice and recommended because it might help in Search Engine Optimization (SEO) plus your code will be more understandable. 
However these elements work the same way with &lt;div> element in terms of rendering in a browser. Element &lt;div>

            </p> 
             <!-- Example start -->
 <h3>Example</h3>
 <p style="text-align: justify; margin-right: 20px;">
let's make div with different styles
</p>
<!-- example start -->
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;div <strong>style=</strong><strong id="pink">"background-color:gold; width:400px; height:400px;"</strong>></i>
<i>&ltp></i> This is a peragraph <i>&lt;/p></i>

<i>&lt;/div></i>

<i>&lt;div <strong>style=</strong><strong id="pink">"background-color:yellow; width:400px; height:400px;"</strong>></i>
<i>&ltp></i> This is a peragraph <i>&lt;/p></i>

<i>&lt;/div></i>

<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p style="background-color:gold; width:400px; height:200px; display:inline-block;">This is a peragraph</p>  
            <p style="background-color:yellow; width:400px; height:200px; display:inline-block;"> This is a peragraph </p> 
        </div>
        </div> 
 <!-- Example end -->
 

<p style="text-align: justify; margin-right: 20px;">
As you can see the two &lt;div> elements are separated from each other they also have different Element &lt;span>
Example:
styles. That's one of the advantages of HTML sections, it lets us style specific parts of an HTML document.
</p>

         <!-- Example start -->
         <h3>Example</h3>
 <p style="text-align: justify; margin-right: 20px;">
let's make div with different styles
</p>
<!-- example start -->
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&ltp></i> 

<i>&ltspan style="font-size:30px;"></i>I<i>&lt;/span></i> <i>&ltspan style="color:blue;"></i>am a peragraph<i>&lt;/span></i> <i>&ltspan style="color:red;"></i>and my words are styled<i>&lt;/span></i> <i>&ltspan style="color:green;"></i>differently using<i>&lt;/span></i> <i>&ltspan style="color:gold;"></i>the Span element<i>&lt;/span></i>

<i>&lt;/p></i>

<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p><span style="font-size:30px;">I</span> <span style="color:blue;">am a peragraph</span> <span style="color:red;">and my words are styled</span> <span style="color:green;">differently using</span> <span style="color:gold;">the Span element</span></p>  
        </div>
        </div> 
 <!-- Example end -->
 <p style="text-align: justify; margin-right: 20px;">
 As you can see the &lt;span> elements did not separate the paragraph into multiple
Lines. Always Remember. The &lt;span> element is good for styling and organizing few
and inline elenments while the &lt;div> element is good for larger elements.
</p>

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END EIGHTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html description lists(9).php"><button id="next">Next&#187;</button></a>
            <a href="html style(7).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>