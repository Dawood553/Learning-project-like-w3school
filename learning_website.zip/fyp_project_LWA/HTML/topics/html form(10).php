<?php
include('html_header.php');
?>
    <title>HTML Form</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML Form</h2>
              <!-- for languages -->
              <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>HTML Form</h3>
            <p style="text-align: justify; margin-right: 20px;">
            HTML Forms can be used to collect user data, make a login form, registration form, a search form, a contact form and the likes. The &lt;form> element defines an HTML Form. HTML Forms Attributes
accept-charset: defines the character set of the form 
<br>
<b>action:</b> specifies the form -handler/page-handler page; usually a .php page in the server-side where the data is processed
<br>
<b>autocomplete:</b> tells the browser to automatically complete Form elements
<br>
<b>enctype:</b> defines the encoding of the data submitted by the form
<br>
<b>method:</b> defines the HTTP method to use when submitting a form e.g. GET or POST; it is explained further below
name, id, class: used for identifying the form; for the purpose of styling and Document Object Manipulation
novalidate: tells the browser not to validate the form
<br>
<b>onSubmit:</b> used to call a JavaScript function e.g. for form validation when the form
is submitted
<br>
<b>target:</b> defines the target of the form e.g, target="_blank", form-handler will be opened in
new tab To submit an HTML Form a user has to click the "Submit" button. The user will be redirected to the form-handler page specified by the action attribute where the input data is processed. The form-handler is typically a Hypertext Processor (PHP) server page that runs scripts to process input data.
Unfortunately, we are not going to teach you today how to handle forms in PHP but you can wait until we release our Learn PHP app. For now, we will only use the "'sample-page-handler.html" page as our form-handler and pretend as if the data submitted are processed in the
server-side.

            </p>
            

<!-- example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;form action="#" method="post"></i>
    <i>&lt;input</i> <strong>type</strong>= "text" placeholder="Name"/>
    <i>&lt;input</i> <strong>type</strong>= "date" placeholder="Age"/>
    <i>&lt;input</i> <strong>type</strong>= "text" placeholder="Hobby"/>
    <i>&lt;input</i> <strong>type</strong>= "submit"/>
    <i>&lt;/form></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
            <form action="#" method="post">
    <input type= "text" placeholder="Name"/>
    <input type= "date" placeholder="Age"/>
    <input type= "text" placeholder="Hobby"/>
    <input type= "submit"/>
    </form>
            </p>    
        </div>
        </div> 
 <!-- Example end -->
 <h3>Attribute method</h3>
 <p style="text-align: justify; margin-right: 20px;">
 The method attribute specifies which HTTP method to use when submitting 
 input data to the form-hand per page. It could either be GET Or POST.
            </p>
<h3>GET Vs. POST HTTP Method</h3>
<p style="text-align: justify; margin-right: 20px;">
Here is a simple table to show the differences between the GET and POST
 </p>
 <table border="1" width="100%">
    <tr>
        <th>Get</th>
        <th>Post</th>
    </tr>
    <tr>
        <td>
Default Value. <br>
Less Secure. <br>
Data is written on the URL address. <br>
More prone to hacking. <br>
Use when submitting personal data. <br>
</td>
        <td>
Not the default value. <br>
More Secure. <br>
Data is not written on the URL address. <br>
Less prone to hacking. <br>
Do not for submitting personal data. <br>
</td>
    </tr>
 </table>

 <h3>HTML Form Elements</h3>
 <p style="text-align: justify; margin-right: 20px;">
 HTML Form Elements should be inside
the &lt;form> element you will learn
various types of HTML Form Elements
including inputs, textboxes, buttons,
checkboxes, dropdown lists and more
in the next lessons.
</p>
<!-- example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;form action="#" method="post"></i>
    <strong>&lt;!--HTML Form Elements Will be here--&gt;</strong>
    <i>&lt;/form></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
            
            </p>    
        </div>
        </div> 
 <!-- Example end -->
 <h3>Input Elements</h3>
 <p style="text-align: justify; margin-right: 20px;">
 Input elements are the input fields inside a form. There are different types 
 of input fields and you will learn each of them in the next lesson. Attribute 
 name Every form element except the "Submit" button must have its own unique name 
 attribute unless the data will not be submitted to the form -handler because it is used 
 as a reference to get the value of each element entered by the user.
</p>





    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END TENTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="#"><button id="next">End&#187;</button></a>
            <a href="html description lists(9).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>