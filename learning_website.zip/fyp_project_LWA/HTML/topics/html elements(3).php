<?php
include('html_header.php');
?>
    <title>HTML Elements</title>

    <div class="container only-print"> 
   
    
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML elements</h2>
             <!-- for languages -->
             <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>HTML Elements</h3>
            
            <p style="text-align: justify; margin-right: 20px;">
                In the first lesson we have studied about tags and things like start tag(opening a tag)
                and end tag (closing a tag). An HTML element is usually composed o a "Start Tag","Element Content" and an "End Tag".
            </p>
            <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p></i>This is an element content. <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>This is an element content.</p>    
        </div>
        </div> 
<!-- example end -->
            <p style="text-align: justify; margin-right: 20px;">
                The example HTML Element above is composed of the following:
                <ul>
                    <li>Start tag: &lt;p></li>
                    <li>Element content: This is an element content.</li>
                    <li>End tag: &lt;/p></li>
                </ul>
            </p>
<!--FIRST TOPIC END-->
 <!-- Example start -->
 <h3>Example</h3>
 <pre id="precode">
 <i style="color: yellow;">&lt;!DOCTYPE html></i>
 <i>&lt;html></i>
 <i>&lt;head></i>
     <i>&lt;title></i> Try <i>&lt;/title></i>
 <i>&lt;/head></i>
 <i>&lt;body></i>
     <i>&lt;h1></i>This is an element content. <i>&lt;/h1></i>
 <i>&lt;/body></i>
 <i>&lt;/html></i>
 </pre>
         <h4 style="margin-left: 2%;">Out Put</h4>
         <div id="out">
             <div class="output">
             <h1>This is an element content.</h1>    
         </div>
         </div> 
 <!-- example end -->
             <p style="text-align: justify; margin-right: 20px;">
                 The example HTML Element above is composed of the following:
                 <ul>
                     <li>Start tag: &lt;h1></li>
                     <li>Element content: This is an element content.</li>
                     <li>End tag: &lt;/h1></li>
                 </ul>
             </p>
 <!--FIRST TOPIC END-->
 <h3>NESTED HTML Elements</h3>
 <p style="text-align: justify; margin-right: 20px;">
     There are some cases that an HTML element can contain one or more HTML elements. For you to 
     better understand it look at the example code below.
 </p>
 <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;p></i>&lt;i>Italicized Text&lt;/i><i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
 <div class="output">
 <p><i>Italicized Text</i></p>    
</div>
</div> 
<!-- example end -->
 <p style="text-align: justify; margin-right: 20px;">
     The example nested HTML Element above is composed of the following:
     <ul>
        <li>Start Tag.&lt;p></li>
        <li>Start Tag.&lt;p></li>
        <li>Element Content. Italicized Text</li>
        <li>End Tag.&lt;/i></li>
        <li>End Tag.&lt;/p></li>
     </ul>
    </p>
     <p>
     On the example above, there are two start tags and two end tags. The second tag i.e &lt;i>
     italizes th text within.
 </p>

<!--Second TOPIC START-->
<h3>Empty Elements</h3>
<p style="text-align: justify; margin-right: 20px;">
    Empty Elements are elements that do not have an element content and an end tag. A list of commonly used Empty Elements.
    <ul>
       <li>&lt;meta /></li>
       <li>&lt;link /></li>
       <li>&lt;imag /></li>
       <li>&lt;br /></li>
       <li>&lt;hr /></li>
       <li>&lt;input /></li>
    </ul>
   </p>
    <p>
    The best practices in HTML Empty Elements is to always put a forward slash / sign before the 
    greater than > sign. In this way are closed at their start tags.
</p>
<!--Second TOPIC END-->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END THIRD LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html attributes(4).php"><button id="next">Next&#187;</button></a>
            <a href="html editor(2).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel no-print">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "Where you can write Element Content?",
            a: [{ text: "Between start tag and end tag", isCorrect: false },
            { text: "before start tag", isCorrect: false },
            { text: "after end tag", isCorrect: true },
            { text: "All", isCorrect: false }
            ]

        },
        {
            q: "Which are the empty tag",
            a: [{ text: "<a>", isCorrect: false, isSelected: false },
            { text: "<p>", isCorrect: false },
            { text: "<h1>", isCorrect: false },
            { text: "<img />", isCorrect: true }
            ]

        },
        {
            q: "Which tag is used to italic the content",
            a: [{ text: "<u> </u>", isCorrect: false },
            { text: "<b></b>", isCorrect: false },
            { text: "<i> </i>", isCorrect: true },
            { text: "All", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>