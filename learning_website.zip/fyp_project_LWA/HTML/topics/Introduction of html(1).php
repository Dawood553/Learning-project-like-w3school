<?php
include('html_header.php');
?>
    <title>Introduction of HTML</title>

    <div class="container"> 
        <br>
        
        <div class="notes">






            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Introduction of HTML5</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>What is HTML5?</h3>
            <p style="text-align: justify; margin-right: 20px;">
                HTML stands for Hyper Text Markup Language, it is easy and fun to learn. HTML describes
                the structure of web pages. HTML5 is the fifth and current major version of the HTML standard.
            </p>
            <h3>Why learn HTML5?</h3>
            <p style="text-align: justify; margin-right: 20px;">
                It is essential to learn HTML if you want to build web sites, you can't build
                one if you don't know HTML because it's one of the prerequisites in learning 
                other languages used for web development.
            </p>
<!--FIRST TOPIC END-->



<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i>Hello World <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;h1></i>This is a heading <i>&lt;/h1></i>
    <i>&lt;p></i>This is a peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>This is a heading</h1>
            <p>This is a peragraph</p>    
        </div>
        </div> 
<!-- example end -->



<!-- example explained -->
<h3>Example Explained?</h3>
            <p style="text-align: justify; margin-right: 20px;">
<b style="color:red;">Line 1:</b> &lt;!DOCTYPE html>: This declares the document type which is HTML5.<br>
<b style="color:red;">Line 2:</b> &lt;html>: This element enclose everything inside of an html document; it 
includes tags, elements, style sheets, scripts, text, multimedia and a lot more.<br>
<b style="color:red;">Line 3:</b>&lt;head>: This element enclose the metadata of a document which will not be displayed on the main
content of a wb page; this could include style seets, scripts, &lt;title>, &lt;meta>, tags and a lot more. <br>
<b style="color:red;">Line 4:</b>&lt;title>: This element define the title of a web page; it appears on the upper-part of a browser.<br>
<b style="color:red;">Line 5:</b>&lt;body>: This element encloses elements like &lt;h1>, &lt;p>, &ltimg>, 
&lt;b>, &lt;i> and a lot more. <br>
<b style="color:red;">Line 6:</b>&lt;h1> This elements define a heading. <br>
<b style="color:red;">Line 6:</b>&lt;p> This elements define a peragraph. <br>
</p>
<!-- example explained end -->



<!--Second TOPIC START-->
<h3>HTML tags</h3>
<p style="text-align: justify; margin-right: 20px;">
    HTML Tags are element names surrounded by angle brackets. In HTML we start and end tags. Look 
    at the example below.
</p>
<h3>Start Tag and End Tag</h3>
<p style="text-align: justify; margin-right: 20px;">
    <ul>
        <li>Start tag- also called "opening a tag" <b> Example </b>: &lt;p></li>
        <li>End tag- also called "ending a tag" <b> Example </b>: &lt;/p></li>
    </ul>
</p>
<!--Second TOPIC END-->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIRST LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html editor(2).php"><button id="next">Next&#187;</button></a>

            <!-- <a href="Introduction of c++(1).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What is Missing < DOCTYPE html>",
            a: [{ text: "{", isCorrect: false },
            { text: ".", isCorrect: false },
            { text: "!", isCorrect: true },
            { text: "]", isCorrect: false }
            ]

        },
        {
            q: "What is the closing tag of <p>",
            a: [{ text: "<p/>", isCorrect: false, isSelected: false },
            { text: "<\p>", isCorrect: false },
            { text: "<//p>", isCorrect: false },
            { text: "</p>", isCorrect: true }
            ]

        },
        {
            q: "What is the attribute of <a attribute> </a>",
            a: [{ text: "hred='#'", isCorrect: false },
            { text: "ref='#'", isCorrect: false },
            { text: "href='#'", isCorrect: true },
            { text: "All", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    
<!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>