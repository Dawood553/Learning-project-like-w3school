<?php
include('html_header.php');
?>
    <title>HTML Editors</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML Editors</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>Where can i edit/create HTML files?</h3>
             
            <p style="text-align: justify; margin-right: 20px;">
                In a text editor!Creating HTML files is free you don't need to download expensive
                aplicaion to do so. <br>
                Look at the list below for some free apps you could use to edit HTML files.
                <ul>
                    <li>Notepad</li>
                    <li>Notepad++</li>
                    <li>TextEdit</li>
                    <li>Sublime Text Editor</li>
                    <li>VIM</li>
                    <li>Visula Studio Code</li>
                    <li>Brackets</li>
                    <li>Quoda(Android app)</li>
                    <li>Quick Edit(Android app)</li>
                    <li>HTML Editor(Android app)</li>
                    <li>Dcoder(Android app)</li>
                    <li>Droid Edit(Android app)</li>
                    <li>Quoda(Android app)</li>
                    <li>ATOM</li>
                    <li><b>This app!</b>We have micro code-editor with syntax highlighting and can 
                    save and open HTML files
                </li>
                </ul>
                </p>
                <p>
                Those are the most commonly used text editors for creating html files. <br>
                you can download any application you want.
            </p>
            <h3>Saving HTML Files</h3>
            <p style="text-align: justify; margin-right: 20px;">
                You need to save your HTML files with .html file extension. For example, mywebpage.html. <br>
                If you don't save your files with the .html file extension, you won't be able to run it on browser. 
            </p>
<!--FIRST TOPIC END-->



<!-- Example start -->
 
<!-- example end -->



<!-- example explained -->

<!-- example explained end -->



<!--Second TOPIC START-->

<!--Second TOPIC END-->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SECOND LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html elements(3).php"><button id="next">Next&#187;</button></a>
            <a href="Introduction of html(1).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "You need to save your HTML files with ",
            a: [{ text: ".htm", isCorrect: false },
            { text: ".cpp", isCorrect: false },
            { text: ".html", isCorrect: true },
            { text: ".js", isCorrect: false }
            ]

        },
        {
            q: "To create an html file what you need",
            a: [{ text: "None", isCorrect: false, isSelected: false },
            { text: "mobile", isCorrect: false },
            { text: "laptop", isCorrect: false },
            { text: "text editor", isCorrect: true }
            ]

        },
        {
            q: "<h1> to <h6> tag used for what?",
            a: [{ text: "links", isCorrect: false },
            { text: "images", isCorrect: false },
            { text: "heading", isCorrect: true },
            { text: "peragraph", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>