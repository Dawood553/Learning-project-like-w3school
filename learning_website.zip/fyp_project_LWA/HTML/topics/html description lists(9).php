<?php
include('html_header.php');
?>
    <title>HTML Lists</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">HTML Description Lists</h2>
              <!-- for languages -->
              <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>HTML Description Lists</h3>
            <p style="text-align: justify; margin-right: 20px;">
            HTML Description Lists
HTML Description Lists are commonly used to implement a glossary or to display metadata (a list of key value pairs). It somehow affects Search Engine Optimization (SEO).
HTML Description Lists Elements
&lt;d>: defines a description list. It encloses a group of terms.
&lt;dt>: enclosed by the &lt;dl>
element it defines a description term.
&lt;dd>: enclosed by the &lt;dl>
element it defines a description details.

            </p>
            

<!-- example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;dl></i>
    <i>&lt;dt></i> Dog <i>&lt;/dt></i>
    <i>&lt;dd></i> Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam, in! <i>&lt;/dd></i>
    <i>&lt;dt></i> Cat <i>&lt;/dt></i>
    <i>&lt;dd></i> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veritatis, laudantium. <i>&lt;/dd></i>
<i>&lt;/dl></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p><dl>
    <dt> Dog </dt>
    <dd> Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam, in! </dd>
    <dt> Cat </dt>
    <dd> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veritatis, laudantium. </dd>
</dl></p>    
        </div>
        </div> 
 <!-- Example end -->

 <p style="text-align: justify; margin-right: 20px;">
 The example below contain internal styling to see the output just click the Styling Description

            </p>

            <!-- example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;style></i>
    dt {
        font-weight: bold;
        }
        
    dd {
        text-decoration: underline;
        }
    dl  {
        font-style : italic ;
    }


<i>&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;dl></i>
    <i>&lt;dt></i> Dog <i>&lt;/dt></i>
    <i>&lt;dd></i> Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam, in! <i>&lt;/dd></i>
    <i>&lt;dt></i> Cat <i>&lt;/dt></i>
    <i>&lt;dd></i> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veritatis, laudantium. <i>&lt;/dd></i>
<i>&lt;/dl></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
            <style>
    dt {
        font-weight: bold;
        }
        
    dd {
        text-decoration: underline;
        }
    dl  {
        font-style : italic ;
    }


</style>
                
            <dl>
    <dt> Dog </dt>
    <dd> Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam, in! </dd>
    <dt> Cat </dt>
    <dd> Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veritatis, laudantium. </dd>
</dl></p>    
        </div>
        </div> 
 <!-- Example end -->









    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END NINETH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="html form(10).php"><button id="next">Next&#187;</button></a>
            <a href="html section(8).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    
    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>