<?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\navbar.php');
?>
  <title>Let's Learn Programming HTML</title>

   
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>Welcome to HTML Learning</h1>
          <h2>We are always here to serve you 24/7</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="topics/Introduction of html(1).php" class="btn-get-started scrollto">Start Learning</a>
            
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="\fyp_project_LWA\assets\img\logo.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <!-- End Cliens Section -->

   <!-- ======= About Us Section ======= -->
   <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>HTML</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
           
            </p>

            <ul>
            <li><i class=""></i><h3>What is HTML?</h3></li>
              <li><i class="ri-check-double-line"></i> HTML (Hypertext Markup Language) is the standard markup language used to create web pages.</li>
              <li><i class="ri-check-double-line"></i> It is the backbone of a website, providing the structure and content that the web browser renders to the user.</li>
            </ul>

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
          <ul>
              <li><i class=""></i><h3>HTML Structure</h3></li>
              <li><i class="ri-check-double-line"></i> <b>DOCTYPE:</b> Declaration of the document type and version of HTML</li>
              <li><i class="ri-check-double-line"></i> <b>HTML: </b> Root element of the document</li>
              <li><i class="ri-check-double-line"></i> <b>HEAD: </b> Container for metadata (title, charset, links, etc.)</li>
              <li><i class="ri-check-double-line"></i> <b>BODY: </b> Container for the visible content of the page</li>
            </ul>
            
<!-- Modal Start -->
<button class="btn-learn-more" data-toggle="modal" data-target="#mymodal">
Read More
</button>
<div class="modal fade modal-lg" id="mymodal" data-backdrop="static">
<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
<div class="modal-content">
    <div class="modal-header">
        <h2 class="modal-title">
            HTML
        </h2>
        <button class="close btn btn-white text-danger" data-dismiss="modal">
          X
        </button>
    </div>
    <div class="modal-body">
        <div class="card">
          <!-- <img src="\fyp_project_LWA\assets\img\html.jpg" class="card-img-top img-fluid" alt=""> -->
          <video src="\fyp_project_LWA\assets\img\videos\html.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>

          <div class="card-body">
            <h1 class="card-title">
            HTML Elements
            </h1>
            <p class="card-text">
            <h3>Tags:</h3>
            HTML elements are represented by tags, which are surrounded by angle brackets (<>)
          </p>

            <p class="card-text">
            <h3>Elements: </h3>
            A pair of tags (opening and closing) that wrap around content
            </p>

            <p class="card-text">
            <h3>Attributes: </h3>
            Additional information added to tags (e.g., src, href, title)
            </p>

          <h1 class="card-title">
          Common HTML Elements:
        </h1>
            <p class="card text">
                <h3>Headings:</h3>
                H1-H6 (heading levels)
              </p>

              <p class="card text">
                <h3>Paragraphs</h3>
                
                P (paragraph text)
              </p>

              <p class="card text">
                <h3>Links</h3>
                A (anchor text)
              </p>

              <p class="card text">
                <h3>Images:</h3>
                IMG (image source)
              </p>

              <p class="card text">
                <h3>Lists:</h3>
                UL (unordered list), OL (ordered list), LI (list item)
              </p>
            <p class="card text">
                <h3>Divisions: </h3>
                DIV (grouping element)
              </p>
              <p class="card text">
                <h3>Span: </h3>
             Sapn inline Element
              </p>

              <h1 class="card-title">HTML Versions</h1>
              <p class="card text">
                <h3>HTML5: </h3>
                The current version of HTML, which includes new features and elements for structuring web pages
              </p>

              <p class="card text">
                <h3>HTML 4.01: </h3>
                The previous version of HTML, which is still widely used
              </p>

              <p class="card text">
                <h3>XHTML: </h3>
                A variant of HTML that uses XML syntax and is stricter than HTML
              </p>

              <h1 class="card-title">HTML Tools</h1>
              <p class="card text">
                <h3>HTML Editors: </h3>
                Software applications that help you write and edit HTML code (e.g., Sublime Text, Atom)
              </p>

              <p class="card text">
                <h3>HTML Validators: </h3>
                Tools that check your HTML code for errors and compliance with HTML standards (e.g., W3C Validator)
              </p>

              <p class="card text">
                <h3>HTML Frameworks: </h3>
                Pre-built HTML structures and templates that help you quickly create web pages (e.g., Bootstrap, Foundation)
              </p>

              <p class="card text">
                <h3>Conclusion: </h3>
                I hope this provides a detailed overview of HTML! Let me know if you have any specific questions or need further clarification.
              </p>

              

          </div>
        </div>
    
    <div class="modal-footer">
        <button class="btn btn-danger" class="close" data-dismiss="modal">
            close
        </button>
    </div>
</div>

</div>


            <!-- Modal End -->
          </div>
        </div>

      </div>
    </section>
    <!-- End About Us Section -->

    <!-- ======= Why Us Section ======= -->
    
    <!-- End Why Us Section -->

    <!-- ======= Skills Section ======= -->
    <!-- End Skills Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <p>
          "Learn the building blocks of web development with our comprehensive 
          programming language topics! Master the art of coding with our in-depth
           lectures on HTML fundamentals, including Introduction Of HTML, HTML editors, HTML Style,
            HTML Form, and much more. Our topics are designed to help you understand the basics and beyond,
             so you can create engaging web pages and applications with ease. Whether you're a beginner or 
             looking to refresh your skills, 
            our programming language topics have got you covered!"
          </p>
        </div>

        <div class="row">
          <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4><a href="topics/introduction of html(1).php">Introduction Of HTML</a></h4>
              <p>HTML stands for Hyper Text Markup Language, it is easy and fun to learn. HTML describes the structure of web pages. 
                HTML5 is the fifth and current major version of the HTML standard.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="topics/html editor(2).php">HTML Editor</a></h4>
              <p>In a text editor!Creating HTML files is free you don't need to download expensive aplicaion to do so.
Look at the list below for some free apps you could use to edit HTML files.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="topics/html style(7).php">HTML Style</a></h4>
              <p>HTML Style are used to style HTML elements it also means changing default values. For Instance, Styling can change the default values of text color as black, background color as white, 
                text alignement as left and text size as 12 pixels.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="topics/html form(10).php">HTML Form</a></h4>
              <p>HTML Forms can be used to collect user data, make a login form, registration form, a search form, a contact form and the likes. The &lt;form> element defines an HTML Form.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
    <?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\footer.php');
?>