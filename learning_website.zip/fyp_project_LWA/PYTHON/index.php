<?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\navbar.php');
?>
  <title>Let's Learn Programming PYTHON</title>


        


    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>Welcome to Python Learning</h1>
          <h2>We are always here to serve you 24/7</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="topics/python 1.php" class="btn-get-started scrollto">Start Learning</a>
            
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="\fyp_project_LWA\assets\img\logo.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <!-- End Cliens Section -->

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Python</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
           
            </p>

            <ul>
            <li><i class=""></i><h3>What is Python?</h3></li>
              <li><i class="ri-check-double-line"></i> Python is a high-level, interpreted programming language 
               that is widely used for various purposes such as web development,</li>
              <li><i class="ri-check-double-line"></i> scientific computing, data analysis, artificial intelligence, and more.</li>
              <li><i class="ri-check-double-line"></i> It was created in the late 1980s by Guido van Rossum and was first released in 1991.</li>
            </ul>

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
          <ul>
              <li><i class=""></i><h3>Features of Python</h3></li>
              <li><i class="ri-check-double-line"></i> <b>Easy to Learn:</b> Python has a simple syntax and is relatively easy to learn, making it a great language for beginners.</li>
              <li><i class="ri-check-double-line"></i> <b>High-Level Language: </b>Python is a high-level language, meaning it abstracts away many low-level details, allowing developers to focus on the logic of their code rather than the implementation details.</li>
            </ul>

<!-- Modal Start -->
<button class="btn-learn-more" data-toggle="modal" data-target="#mymodal">
Read More
</button>
<div class="modal fade modal-lg" id="mymodal" data-backdrop="static">
<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
<div class="modal-content">
    <div class="modal-header">
        <h2 class="modal-title">
            Python
        </h2>
        <button class="close btn btn-white text-danger" data-dismiss="modal">
          X
        </button>
    </div>
    <div class="modal-body">
        <div class="card">
          <!-- <img src="\fyp_project_LWA\assets\img\python.jpg" class="card-img-top img-fluid" alt=""> -->
          <video src="\fyp_project_LWA\assets\img\videos\python.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>

          <div class="card-body">
            <h1 class="card-title">
              Python About Us
            </h1>
            <p class="card-text">
            <h3>Interpreted Language:</h3>
            Python code is interpreted rather than compiled, making it easy to write and test code quickly.
            </p>
            <p class="card-text">
            <h3>Object-Oriented: </h3>
            Python is an object-oriented language, supporting concepts such as classes, objects, inheritance, and polymorphism. </p>
            <p class="card-text">
            <h3>Large Standard Library: </h3>
            Python has a comprehensive and extensive standard library that includes modules for various tasks, such as file I/O, networking, and data analysis </p>
            <p class="card-text">
            <h3>Dynamic Typing:</h3>
            Python is dynamically typed, meaning you don't need to declare the type of a variable before using it.
          </p>
          <p class="card-text">
            <h3>Cross-Platform:</h3>
            Python can run on multiple operating systems, including Windows, macOS, and Linux.
            </p>

          <h1 class="card-title">
          Applications of Python:
        </h1>
            <p class="card text">
                <h3>Web Development:</h3>
                Python is widely used for web development, with popular frameworks such as Django and Flask.
              
              </p>

              <p class="card text">
                <h3>Data Analysis and Science:</h3>
                
                Python is used for data analysis, machine learning, and scientific computing, with libraries such as NumPy, pandas, and scikit-learn.
              </p>

              <p class="card text">
                <h3>Artificial Intelligence and Machine Learning:</h3>
                Python is used for building AI and machine learning models, with libraries such as TensorFlow and Keras.
              </p>

              <p class="card text">
                <h3>Automation:</h3>
                Python is used for automating tasks, such as data scraping, file manipulation, and system administration.
              </p>

              <p class="card text">
                <h3>Education:</h3>
                Python is widely taught in schools and universities due to its simplicity and ease of use.
              </p>
            <p class="card text">
                <h3>Community: </h3>
                Python has a large and active community, with numerous online forums, social media groups, and meetups. The Python community is known for its friendliness and willingness to help newcomers.
              </p>
              <p class="card text">
                <h3>Conclusion: </h3>
                Python is a versatile and powerful programming language that is widely used in various fields. Its simplicity, ease of use, and large community make it a great language for beginners and experienced developers alike.
              </p>

          </div>
        </div>
    
    <div class="modal-footer">
        <button class="btn btn-danger" class="close" data-dismiss="modal">
            close
        </button>
    </div>
</div>

</div>


            <!-- Modal End -->
          </div>
        </div>

      </div>
    </section>
    <!-- End About Us Section -->

    <!-- ======= Why Us Section ======= -->
    
    <!-- End Why Us Section -->

    <!-- ======= Skills Section ======= -->
    <!-- End Skills Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
        <p>"Unlock the power of data-driven development with our comprehensive Python topics! Master the art of coding
           with our in-depth lectures on Python fundamentals, including Introduction Of Python, Python Syntax, Python data types, Python Variables, 
           and much more. Our topics are designed to help you understand the basics and beyond, so you can create efficient scripts, analyze data, and build intelligent applications with ease.
           Whether you're a beginner or looking to refresh your skills, our Python topics have got you covered!"</p>
        </div>

        <div class="row">
          <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4><a href="topics/python 2.php">Introduction Of Python</a></h4>
              <p>Python is a programming language. Python is one of the most popular programming languages.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="topics/python 6.php">Python Syntax</a></h4>
              <p>When coding in Python, we followa syntax. Syntax is the set of rules followed when writing Python programs.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="topics/python 8.php">Python Variables</a></h4>
              <p>Variables are used to store values. To create a variable, use the equal sign (=). In this example, we have a variable named fruit and we assign the "mangos" value to it.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="topics/python 9.php">Python Data Types</a></h4>
              <p>There are two basic types of numbers and they are called integer and floating point numbers. An integer does not have decimals.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
<?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\footer.php');
?>