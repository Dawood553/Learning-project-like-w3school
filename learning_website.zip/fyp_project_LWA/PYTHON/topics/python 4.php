<?php
include('python_header.php');
?>
    <title>Displying OutPut</title>
   
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Python Displaying Output</h2>
            <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Python Displaying Output</h3>
            <p style="text-align: justify; margin-right: 20px;">
            To display an output in Python, use the print() function. Printing Text The print() function can be used to
print a string (text). In this example, the Hello World! Text will be printed. print ("Hello World ! ") Printing Number The print) function can be used to print numbers. In this example, 21 will be printed. print (21) You can also print the addition of two numbers.
print (3 + 21) data You can also use the print() function to print other types.
Tip! You will learn the different data types as you go through the lessons. Printing Two Objects The print) function can also be used to print two objects. In this example, we'll print two text at once. print ("Hello", "World") In this example, we'll print a string and the sum of two numbers.

            </p>
            



<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i> X =</i> 3
<i> y =</i> 21
<i> SUM =</i> X + y
<i>print (<strong>"The Sum Is:",</strong>sum)</i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>The Sum Is: 24</h1>
              
        </div>
        </div> 
<!-- example end -->








    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FOURTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="python 5.php"><button id="next">Next&#187;</button></a>
            <a href="python 3.php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "To display an output in Python, use the",
            a: [{ text: "All", isCorrect: false },
            { text: "alert() function", isCorrect: false },
            { text: "print() function", isCorrect: true },
            { text: "cout() function", isCorrect: false }
            ]

        },
        {
            q: "x=1; y=2; print('The Sum Is: ', x+y)",
            a: [{ text: "The sum is: 3", isCorrect: false, isSelected: false },
            { text: "3", isCorrect: false },
            { text: "The Sum Is: 5", isCorrect: false },
            { text: "The Sum Is: 3", isCorrect: true }
            ]

        },
        {
            q: "The Hello World! Text will be printed as",
            a: [{ text: "console.window(Hello World!)", isCorrect: false },
            { text: "alert(Hello World!)", isCorrect: false },
            { text: "print(Hello World!)", isCorrect: true },
            { text: "cout(Hello World!)", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

     <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>