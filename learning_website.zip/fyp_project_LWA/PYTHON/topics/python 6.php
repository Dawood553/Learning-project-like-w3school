<?php
include('python_header.php');
?>
    <title>Python Syntax</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Python Syntax</h2>
            <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Python Syntax</h3>
            <p style="text-align: justify; margin-right: 20px;">
            When coding in Python, we followa syntax. Syntax is the set of rules followed when writing Python programs. 
         </p>

         <h3>Python indentation</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Python Indentation in Python is very important. In other languages like Java, JavaScript and C, indentation are only for readability purposes and their compilers don't care about indentations. Whereas in Python, indentation indicates a block (group) of statements. <br>
            Tabs or leading whitespaces are used to compute the indentation level of a line. It depends on you whether you want to use tabs or whitespaces, in this example we'll use 2 whitespaces.
         </p>
            



<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i> if </i>5 > 4
<i> X =</i> "Hello World!"
<i>print</i>(x)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World!</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
Note! The number of whitespaces also depends on you, but it has to be at least one.
</p>

<h3>Indentation Error In Python</h3>
            <p style="text-align: justify; margin-right: 20px;">
            a block of statements needs to have the same indentation level. This example will produce an indentation error, because the first line of the block/group does not have the same indentation as the second line.
        </p>
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i> if </i>5 > 4:
  <i> X =</i> "Hello World!"
     <i>print</i>(x)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Indentation Error</h1>
              
        </div>
        </div> 
<!-- example end -->
<h3>Ending a Block of Statements</h3>
            <p style="text-align: justify; margin-right: 20px;">
            A block (group) of statements ends with the next unindented line.
         </p>
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i> if </i>5 > 4:
    <i>X =</i> "Hello World!"
    <i>print</i>(x)
    <i>print</i>(<strong>"The block of statement"</strong>)
<i>print</i>(<strong>"I come after the if block."</strong>)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World! <br> The block of statement <br> I come after the if block.</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
As you may have guessed, if the statement is false, Hello World! Will not be printed. 
In this example, the if statement evaluates to false because 3 is not more than 4.
         </p>
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i> if </i>3 > 4:
    <i> X =</i> "Hello World!"
    <i>print</i>(x)
    <i>print</i>(<strong>"The block of statement"</strong>)
<i>print</i>(<strong>"I come after the if block."</strong>)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>The block of statement <br> I come after the if block.</h1>
              
        </div>
        </div> 
<!-- example end -->

<p style="text-align: justify; margin-right: 20px;">
Notice that in the example above, Hello World! was not printed.
         </p>




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SIXTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="python 7.php"><button id="next">Next&#187;</button></a>
            <a href="python 5.php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    


     <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>