<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="icon" href="title.jpg">
    <!-- <link rel="stylesheet" href="bootstrap.min.css"> -->
    <!-- <link rel="stylesheet" href="\fyp_project_LWA\config\html-topic_style.css"> -->
    <!-- <link rel="stylesheet" href="html-topic_style.css"> -->
    <!-- <link rel="stylesheet" href="style2.css"> -->
    <!-- <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="quiz.css"> -->
    <!-- <link rel="stylesheet" href="quiz_style.css"> -->
    <link rel="stylesheet" href="/fyp_project_LWA/config/style2.css">
    <link rel="stylesheet" href="/fyp_project_LWA/config/quiz.css">

<style>


</style>
</head>
<body>
    <!--SIDE MENU BAAR CODING START -->
    <div id="sideNav">
        <br>
        <br>
        <a href="\fyp_project_LWA\PYTHON\index.php">Home</a>
        <a href="#">Online Compiler</a>


        <input id="searchbar" onkeyup="search_subject()" type="text" name="search" placeholder="Search Lecture..">
        <hr> 
        <ol id="list" style="list-style: none;">            
        <h2 style="color: white;text-align: center;">Lectures</h2>    
        <li><a href="python 1.php" class="subject">Python Overview</a></li>
        <li><a href="python 2.php" class="subject">What is Python?</a></li>
        <li><a href="python 3.php" class="subject">Installing Python</a></li>
        <li><a href="python 4.php" class="subject">Displying OUTPUT</a></li>
        <li><a href="python 5.php" class="subject">Python Statements</a></li>
        <li><a href="python 6.php" class="subject">Python Syntax</a></li>
        <li><a href="python 7.php" class="subject">Python Comments</a></li>
        <li><a href="python 8.php" class="subject">Python Variables</a></li>
        <li><a href="python 9.php" class="subject">Python DataTypes</a></li>
        <li><a href="python 10.php" class="subject">Python Boolean</a></li>
    </div>
    <!-- code for search button  -->
    <script>
        function search_subject() { 
            let input = document.getElementById('searchbar').value 
            input=input.toLowerCase(); 
            let x = document.getElementsByClassName('subject'); 
        for (i = 0; i < x.length; i++) {  
                if (!x[i].innerHTML.toLowerCase().includes(input)) { 
                    x[i].style.display="none"; 
          }
                else { 
                    x[i].style.display="list-item";                  
                } 
        }
        }
        </script>

<!-- code for search button end -->
    <div id="manuBtn">
        <!--<img src="menu.png" id="menu">-->
        <p style="color:white;" id="topics">TOPICS</p>            
    </div>

<script>
        var manuBtn = document.getElementById("manuBtn")
        var sideNav = document.getElementById("sideNav")
        var menus = document.getElementById("menu")           
        sideNav.style.right = "-500px";
        manuBtn.onclick = function()
          {
            if(sideNav.style.right == "-500px"){
                sideNav.style.right ="0"
                
                menu.src = "close.jpg";                  
            }
            else{
                sideNav.style.right ="-500px"
                menu.src = "close.jpg";
            }
        }
    </script>
    <!--SIDE MENU BAAR CODING END-->