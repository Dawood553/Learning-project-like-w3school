<?php
include('python_header.php');
?>
    <title>Python Comments</title>
    
    <div class="container"> 
        <br>
        <div class="notes">


           <!--FIRST TOPIC START-->
           <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Python Comments</h2>
           <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Python Comments</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Comments in Python are commonly used to clarify or explain codes. Comments are not interpreted by Python. Meaning, comments will not be executed.
         </p>
            



<!-- Example start -->
<h3>Example</h3>
<p style="text-align: justify; margin-right: 20px;">
In this example, we have 3 lines of codes. In Python, each line typically contains one statement.
</p>
<pre id="precode">
<strong>#this is comment</strong>
<i> x =</i> 4
<i> y =</i> 3
<i>print (x+y)</i><strong>#add x and y</strong>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>7</h1>
              
        </div>
        </div> 
<!-- example end -->

            <h3>Single Line Comment </h3>
            <p style="text-align: justify; margin-right: 20px;">
            A single line comment starts with the hash character #. 
        </p>

<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<strong># this is a single line comment</strong>
<i>print (<strong>"Hello World!"</strong>)</i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World!</h1>
              
        </div>
        </div> 
<!-- example end -->
<h3>Multiple Lines of Comments  </h3>
            <p style="text-align: justify; margin-right: 20px;">
            To write comments in multiple lines, simply use multiple single line comments. Yes, that's serious.
        </p>

<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<strong># Comments goes here</strong>
<strong># Comments goes here</strong>
<strong># Comments goes here</strong>
<strong># Comments goes here</strong>
<i>print (<strong>"Hello World!"</strong>)</i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello World!</h1>
              
        </div>
        </div> 
<!-- example end -->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SEVENTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="python 8.php"><button id="next">Next&#187;</button></a>
            <a href="python 6.php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     

     <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>