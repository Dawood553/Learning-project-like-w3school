<?php
include('python_header.php');
?>
    <title>Python Boolean</title>
  
    <div class="container"> 
        <br>
        <div class="notes">


           <!--FIRST TOPIC START-->
           <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Python Booleans</h2>
           <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Python Booleans</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The Boolean data type can only be either: True or False 
         </p>

         <h3>Example</h3>
<pre id="precode">
<i>a =</i> true
<i>b =</i> false
<i>print</i>(a)
<i>print</i>(b)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>true false</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
Note! The first letter of a upper Boolean is in case.. 
Booleans are often the result evaluated expressions For example, when you compare two numbers, Python evaluates the expression and returns either True or False.

</p>
<!-- example start -->
<h3>Example</h3>
<pre id="precode">
<i>print</i>(5==5) <strong>#True</strong>
<i>print</i>(10>5) <strong>#True</strong>
<i>print</i>(20>100)<strong>#false</strong>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>true true false</h1>
              
        </div>
        </div> 
<!-- example end -->

<p style="text-align: justify; margin-right: 20px;">
These are often used in if statements.
In this example, if the value of the variable age is more than 18, the program will tell the user that they are allowed to enter

</p>
<!-- example start -->
<h3>Example</h3>
<pre id="precode">
<i>age =</i> 19
<i>if</i>(age>18)
<i>print</i>(You are allowed to enter)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>You are allowed to enter</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
Tip! You will learn more about if statements later in the course.
</p>

<h3>Checking the Type of a Boolean </h3>
            <p style="text-align: justify; margin-right: 20px;">
            We can check the data type of a Boolean variable using the type() method.
         </p>
<!-- example start -->
<h3>Example</h3>
<pre id="precode">
<i>x =</i> true
<i>y =</i> type(x) <strong># returns <class 'bool '></strong>
<i>print</i>(y)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>boolean</h1>
              
        </div>
        </div> 
<!-- example end -->









    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END TENTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="#"><button id="next">End&#187;</button></a>
            <a href="python 9.php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

     <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>