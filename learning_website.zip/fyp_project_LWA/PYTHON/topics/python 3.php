<?php
include('python_header.php');
?>
    <title>Installing Python</title>
    
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Installing Python</h2>
            <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Installing Python</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Note! If you don't have a PC or if you just want to learn on your mobile device, this app has a built-in online interpreter (compiler) where you can practice coding in Python. Before you can run Pyth on in your PC, you need to install it first. To install Python in a PC, go to
https://www.python.org/downloads/
then download the latest version. After that, install it just like how you install other apps. Make sure that you check "Add Python 3.8 to PATH" for easier installation. You can now run Python codes on your PC, you will learn how to do so in the next lesson. Python lInterpreter (Compiler) A Python interpreter (compiler) is a program that executes Python codes.This app has a built-in online interpreter so you can study and practice in one place.

            </p>
<!--FIRST TOPIC END-->












    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END THIRD LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="python 4.php"><button id="next">Next&#187;</button></a>
            <a href="python 2.php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

     <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>