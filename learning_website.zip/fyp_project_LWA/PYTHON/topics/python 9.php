<?php
include('python_header.php');
?>
    <title>Python DataTypes</title>
   
    <div class="container"> 
        <br>
        <div class="notes">


           <!--FIRST TOPIC START-->
           <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Python Data Types</h2>
           <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Python Data Types</h3>
            <p style="text-align: justify; margin-right: 20px;">
            In this tutorial, you wilL learn the most basic data types in Python. 
         </p>

         <h3>Numbers In Python</h3>
            <p style="text-align: justify; margin-right: 20px;">
            There are two basic types of numbers and they are called integer and floating point numbers. An integer does not have decimals. 
         </p>
            



<!-- Example start -->
<h3>Example</h3>
<strong># x is an integer</strong>
<pre id="precode">
<i>x =</i> 21
<i>print</i>(x)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>21</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
A floating point number has decimals.
</p>
            
<h3>Example</h3>
<strong># x is a floating point number</strong>
<pre id="precode">
<i>x =</i> 21.33
<i>print</i>(x)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>21.33</h1>
              
        </div>
        </div> 
<!-- example end -->

<!-- example start -->
<p style="text-align: justify; margin-right: 20px;">
To add numbers, use the plus sign (+).
</p>
            
<h3>Example</h3>
<pre id="precode">
<i>x =</i> 7
<i>y =</i> 3
<i>print</i>(x+y)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>10</h1>
              
        </div>
        </div> 
<!-- example end -->

<!-- example start -->
<p style="text-align: justify; margin-right: 20px;">
<b>Strings are simply text.</b>
A string must be surrounded by single quotes or double quotes.
</p>
            
<h3>Example</h3>
<strong># Using single quotes</strong>
<pre id="precode">
<i>fruit =</i> 'mangos'
<i>y =</i> 3
<i>print</i>(fruit)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>mangos</h1>
              
        </div>
        </div> 
<!-- example end -->

<!-- example start -->
            
<h3>Example</h3>
<strong># Using double quotes</strong>
<pre id="precode">
<i>fruit =</i> "mangos"
<i>y =</i> 3
<i>print</i>(fruit)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>mangos</h1>
              
        </div>
        </div> 
<!-- example end -->

<!-- example start -->
<h3>Single or double quotes?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Use single quotes when your string contains double quotes.
        </p>          
<h3>Example</h3>
<pre id="precode">
<i>x =</i> 'I told you "Python is fun to learn.”’
<i>y =</i> 3
<i>print</i>(fruit)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>I told you "python is fun to learn".</h1>
              
        </div>
        </div> 
<!-- example end -->
<!-- example start -->
            
<h3>Example</h3>
<strong># Using double quotes</strong>
<pre id="precode">
<i>x =</i> "let's learn python"
<i>y =</i> 3
<i>print</i>(x)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>let's learn python</h1>
              
        </div>
        </div> 
<!-- example end -->

<h3>Booleans</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The Boolean data type can only have one of these two values: True or False
        </p>      
        <h3>Example</h3>
<strong># Using double quotes</strong>
<pre id="precode">
<i>bool =</i> true
<i>bool =</i> false
<i>y =</i> 3
<i>print</i>(x)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>true false</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
When comparing two values, Python returns a Boolean. Let's compare some numbers and see whether the expression evaluates to True or False.
        </p> 
        <h3>Example</h3>
<strong># Using double quotes</strong>
<pre id="precode">
<i>print =</i>(10>5) <strong>#</strong>true
<i>print =</i>(6>5) <strong>#</strong>true
<i>print =</i>(3>5) <strong>#</strong>false
<i>print =</i>(10==10) <strong>#</strong>true
<i>print =</i>(10==11) <strong>#</strong>false
<i>y =</i> 3
<i>print</i>(x)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>true true false true false</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
Tip! You will learn more about Boolean data type as Lists you go through the lessons. 
  </p> 

  <h3>Lists</h3>
            <p style="text-align: justify; margin-right: 20px;">
            brackets (0). The values (also called elements) in a list are separated with commas (,).
        </p>   

        <h3>Example</h3>
<pre id="precode">
<i>mylist =</i> ["mangoes", "oranges", "cherry”]
<i>print</i>(mylist)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>mangoes oranges cherry</h1>
              
        </div>
        </div> 
<!-- example end -->

<h3>Another Example</h3>
<pre id="precode">
<i>mylist =</i> [2,4,6,8,10]
<i>print</i>(mylist)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>2 4 6 8 10</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
Tip! You will learn more about lists in our Python Lists lesson.
  </p> 






    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END NINETH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="python 10.php"><button id="next">Next&#187;</button></a>
            <a href="python 8.php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     
     <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>