<?php
include('python_header.php');
?>
<title>Python Overview</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Python Overview</h2>
            <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Python Overview</h3>
            <p style="text-align: justify; margin-right: 20px;">
            This course will teach you the basics and advanced concepts of Python programming. Python Prerequisites.
            </p>
            <h3>What do you need before learning Python?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            1) Computer literacy.
            2) Knowledge of installing asoftware.
            3) A compiler.
            <br>
            Tip! Python is easy and fun to learn. Much Easier with Examples This course contains a lot of examples.
Python is Easy To learn Python, you don't need any prior knowledge or experience on programming. Python is human readable, making it easier to understand. Take a look at this example:


            </p>
<!--FIRST TOPIC END-->



<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i> X =</i> 4
<i> y =</i> 3
<i> SUM =</i> X + y
<i>print (sum)</i>
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>7</h1>
              
        </div>
        </div> 
<!-- example end -->



<!-- example explained -->
<h3>Example Explained?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Although we have not taught you how to code Python yet, you can still easily pick up that:
1) x is 4
2) y is 3
3) sum is the addition of x and
y and
4) sum will be printed on the
Screen
<br>
Tip! Click the right arrow below to proceed to the next lesson.

</p>
<!-- example explained end -->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIRST LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="python 2.php"><button id="next">Next&#187;</button></a>
            <!-- <a href="Introduction of c++(1).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "WHAT DO YOU NEED BEFORE LEARNING PYTHON?",
            a: [{ text: "Computer literacy", isCorrect: false },
            { text: "Knowledge of installing asoftware", isCorrect: false },
            { text: "All", isCorrect: true },
            { text: "A compiler", isCorrect: false }
            ]

        },
        {
            q: "Python is human readable",
            a: [{ text: "None", isCorrect: false, isSelected: false },
            { text: "difficult", isCorrect: false },
            { text: "No", isCorrect: false },
            { text: "Yes", isCorrect: true }
            ]

        },
        {
            q: "x=4; y=3; print(x+y)",
            a: [{ text: "1", isCorrect: false },
            { text: "5", isCorrect: false },
            { text: "7", isCorrect: true },
            { text: "9", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

     <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>