<?php
include('python_header.php');
?>
    <title>Python Variables</title>
  
    <div class="container"> 
        <br>
        <div class="notes">


           <!--FIRST TOPIC START-->
           <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Python Variables</h2>
           <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Python Variables</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Variables are used to store values. To create a variable, use the equal sign (=). In this example, we have a variable named fruit and we assign the "mangos" value to it.
        </p>
            



<!-- Example start -->
<h3>Example</h3>
<p style="text-align: justify; margin-right: 20px;">
Now, we can use our variable:
</p>
<pre id="precode">
<i> fruit =</i> "mangos"
<i>print</i>(fruit)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>mangos</h1>
              
        </div>
        </div> 
<!-- example end -->
<h3>Here is another example:</h3>
<pre id="precode">
<i> name =</i> "Juan"
<i>print</i>(<strong>"Hello"+</strong>name)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello Juan</h1>
              
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
Changing a Variable Value To change the value of a variable, simply assign a new value to it.
</p>
<!-- example end -->
<h3>Example:</h3>
<pre id="precode">
<i> name =</i> "Juan"
<i> name =</i> "Jhonny"
<i>print</i>(<strong>"Hello"+</strong>name)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Hello Jhonny</h1>
              
        </div>
        </div> 
<!-- example end -->
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
You can also assign a variable to a value of another type.
In this example, the variable is originally a string (text) then we'll change its value to a number.

</p>
<!-- example end -->
<h3>Example:</h3>
<pre id="precode">
<i> name =</i> "Juan"
<i> name =</i> 21
<i>print</i>(<strong>"Hello"+</strong>name)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>Juan 21</h1>
              
        </div>
        </div> 
<!-- example end -->
            <h3>Rules for Naming Variables</h3>
            <p style="text-align: justify; margin-right: 20px;">
            •A variable name should start with a letter or underscore (_).
• A variable name cannot start with a number.
•A variable name is case-sensitive.
• A variable name should only contain underscores (_) and alpha-numeric characters.
</p>

            <h3>Here are some examples of legal</h3>
            <p style="text-align: justify; margin-right: 20px;">
            variable names:
$myname = "Juan "
my_name = "Juan "
_myname = "Juan!"
myname1 = "Juan !"

</p>

            <h3>Here are some examples of illegal</h3>
            <p style="text-align: justify; margin-right: 20px;">
            variable names:
myname = "Juan"
my name = " Juan "
1myname = "Juan!"
my -name = " Juan !"


</p>

            <h3>Long Variable Names </h3>
            <p style="text-align: justify; margin-right: 20px;">
            When naming a variable with a long name, use the underscores (_) to separate words.
</p>
<!-- example end -->
<h3>Example:</h3>
<pre id="precode">
<i> my_favorite_fruit  =</i> "mangos"
<i>print</i>(my_favorite_fruit)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>mangos</h1>
              
        </div>
        </div> 
<!-- example end -->
            <h3>Camel Case</h3>
            <p style="text-align: justify; margin-right: 20px;">
            You can also use the camelCase format where every first letter of the words are capitalized.
</p>
<!-- example end -->
<h3>Example:</h3>
<pre id="precode">
<i> my_Favorite_Fruit  =</i> "mangos"
<i>print</i>(my_Favorite_Fruit)
</pre>
        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <h1>mangos</h1>
              
        </div>
        </div> 
<!-- example end -->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END EIGHT LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="python 9.php"><button id="next">Next&#187;</button></a>
            <a href="python 7.php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

     <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>