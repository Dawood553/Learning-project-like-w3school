<?php
include('php_header.php');
?>
<title>PHP Constant</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">PHP Constants</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>PHP Constants</h3>
            <p style="text-align: justify; margin-right: 20px;">
            PHP constants are name or identifier that can't be changed during the execution of the script. PHP constants can be defined by 2 ways:
1.	Using define() function
2.	Using const keyword
PHP constants follow the same PHP variable rules. For example, it can be started with letter or underscore only.
Conventionally, PHP constants should be defined in uppercase letters.

        </p>
        <h3>PHP constant: define()</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Let's see the syntax of define() function in PHP.
        </p>
<pre id="precode">
define(name, value, case-insensitive)  
</pre>
<p style="text-align: justify; margin-right: 20px;">
1.	name: specifies the constant name
2.	value: specifies the constant value
3.	case-insensitive: Default value is false. It means it is case sensitive by default.
Let's see the example to define PHP constant using define().


</p>

            <!-- Example start -->
<h3>File: constant1.php</h3>
<pre id="precode">
&lt;?php
<strong>define</strong>("MESSAGE","Hello Skyapper PHP");     
<strong>echo</strong> MESSAGE;
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>Hello Skyapper PHP</h2></p>    
</div>
</div> 
<!-- example end -->
<h3>File: constant2.php</h3>
<pre id="precode">
&lt;?php
<strong>define</strong>("MESSAGE","Hello Skyapper PHP",true);//not case sensitive     
<strong>echo</strong> MESSAGE;
<strong>echo</strong> message;
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>Hello Skyapper PHPHello Skyapper PHP</h2></p>    
</div>
</div> 
<!-- example end -->

<!-- example end -->
<h3>File: constant3.php</h3>
<pre id="precode">
&lt;?php
<strong>define</strong>("MESSAGE","Hello Skyapper PHP",false);//case sensitive      
<strong>echo</strong> MESSAGE;
<strong>echo</strong> message;
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>Hello Skyapper PHP <br>Notice: Use of undefined constant message - assumed 'message' <br>
in C:\wamp\www\vconstant3.php on line 4 <br>
message
</h2></p>    
</div>
</div> 
<!-- example end -->
<h3>PHP constant: const keyword</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The const keyword defines constants at compile time. It is a language construct not a function.
It is bit faster than define().
It is always case sensitive.
        </p>
<!-- example end -->

<h3>File: constant4.php</h3>
<pre id="precode">
&lt;?php
<strong>const MESSAGE=</strong> "Hello const by Skyapper PHP";      
<strong>echo</strong> MESSAGE;
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>
 Hello const by Skyapper PHP
</h2></p>    
</div>
</div> 
<!-- example end -->


 
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END NINETH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="php_operator(10).php"><button id="next">Next&#187;</button></a>
            <a href="php_variables(8).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>