<?php
include('php_header.php');
?>
<title>PHP Example</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">PHP Example</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>How to install PHP?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            It is very easy to create a simple PHP example. To do so, create a file and write HTML tags + PHP code and save this file with .php extension.
All PHP code goes between php tag. A syntax of PHP tag is given below:
            </p>

            <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
&lt;?php
echo "&lt;h2>Your Code Goes Here... &lt;/h2>";
?>
</pre>
<p style="text-align: justify; margin-right: 20px;">
Let's see a simple PHP example where we are writing some text using PHP echo command.
File: first.php

            </p>
<!-- example end -->
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
&lt;?php
echo "&lt;h2>Hello First PHP&lt;/h2>";
?>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>Hello First PHP</h2></p>    
</div>
</div> 
<!-- example end -->

      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FOURTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="php_echo(5).php"><button id="next">Next&#187;</button></a>
            <a href="install_php(3).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What is the purpose of the echo statement in PHP?",
            a: [{ text: "To declare variables", isCorrect: false },
            { text: "To create arrays", isCorrect: false },
            { text: "To print output to the screen", isCorrect: true },
            { text: "To use PHP functions", isCorrect: false }
            ]

        },
        {
            q: "What is the concatenation operator in PHP?",
            a: [{ text: "+", isCorrect: false, isSelected: false },
            { text: "-", isCorrect: false },
            { text: "*", isCorrect: false },
            { text: ".", isCorrect: true }
            ]

        },
        {
            q: "What is the purpose of the "date" function in PHP?",
            a: [{ text: "To declare variables", isCorrect: false },
            { text: "To create arrays", isCorrect: false },
            { text: "To print the current date and time", isCorrect: true },
            { text: "To use PHP functions", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>