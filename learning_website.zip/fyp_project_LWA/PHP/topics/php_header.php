<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="title.jpg">
    <!-- <link rel="stylesheet" href="php-topic_style.css" /> -->
    <!-- <link rel="stylesheet" href="quiz_style.css"> -->
    <!-- <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="quiz.css"> -->
    <link rel="stylesheet" href="/fyp_project_LWA/config/style2.css">
    <link rel="stylesheet" href="/fyp_project_LWA/config/quiz.css">

<style>


</style>
</head>
<body>
    <!--SIDE MENU BAAR CODING START -->
    <div id="sideNav">
        <br>
        <br>
        <a href="\fyp_project_LWA\PHP\index.php">Home</a>
        <a href="#">Online Compiler</a>
        <input id="searchbar" onkeyup="search_subject()" type="text" name="search" placeholder="Search Lecture..">
        <hr> 
        <ol id="list" style="list-style: none;">            
        <h2 style="color: white;text-align: center;">Lectures</h2>    
        <li><a href="Introduction_of_php(1).php" class="subject">Introdution of PHP toturial</a></li>
        <li><a href="what_is_php(2).php" class="subject">What is PHP?</a></li>
        <li><a href="install_php(3).php" class="subject">Install PHP</a></li>
        <li><a href="php_example(4).php" class="subject">PHP Example</a></li>
        <li><a href="php_echo(5).php" class="subject">PHP Echo</a></li>
        <li><a href="php_print(6).php" class="subject">PHP Print</a></li>
        <li><a href="php_variables(7).php" class="subject">PHP Variables</a></li>
        <li><a href="php_variables(8).php" class="subject">PHP $ and $$</a></li>
        <li><a href="php_constant(9).php" class="subject">PHP Constant</a></li>
        <li><a href="php_operator(10).php" class="subject">PHP Operator</a></li>

    </div>
    <!-- code for search button  -->
    <script>
        function search_subject() { 
            let input = document.getElementById('searchbar').value 
            input=input.toLowerCase(); 
            let x = document.getElementsByClassName('subject'); 
        for (i = 0; i < x.length; i++) {  
                if (!x[i].innerHTML.toLowerCase().includes(input)) { 
                    x[i].style.display="none"; 
          }
                else { 
                    x[i].style.display="list-item";                  
                } 
        }
        }
        </script>

<!-- code for search button end -->
    <div id="manuBtn">
        <!--<img src="menu.png" id="menu">-->
        <p style="color:white;" id="topics">TOPICS</p>            
    </div>

<script>
        var manuBtn = document.getElementById("manuBtn")
        var sideNav = document.getElementById("sideNav")
        var menus = document.getElementById("menu")           
        sideNav.style.right = "-500px";
        manuBtn.onclick = function()
          {
            if(sideNav.style.right == "-500px"){
                sideNav.style.right ="0"
                
                menu.src = "close.jpg";                  
            }
            else{
                sideNav.style.right ="-500px"
                menu.src = "close.jpg";
            }
        }
    </script>
    <!--SIDE MENU BAAR CODING END-->