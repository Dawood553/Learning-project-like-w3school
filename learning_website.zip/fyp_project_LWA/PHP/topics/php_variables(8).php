<?php
include('php_header.php');
?>
<title>PHP $ and $$ Variables</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">PHP $ and $$ Variables</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>PHP $ and $$ Variables</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The $var (single dollar) is a normal variable with the name var that stores any value like string, integer, float, etc.
The $$var (double dollar) is a reference variable that stores the value of the $variable inside it.
To understand the difference better, let's see some examples.

   
        </p>

            <!-- Example start -->
<h3>Example 1</h3>
<pre id="precode">
&lt;?php
<strong>$x=</strong> "abc";    
<strong>$$x=</strong> 200;    
<strong>echo $x.</strong>"&lt;br/>";  
<strong>echo $$x.</strong>"&lt;br/>";   
<strong>echo</strong> $abc";    
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>abc <br> 200 <br>200</h2></p>    
</div>
</div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">     
In the above example, we have assigned a value to the variable x as abc. Value of reference variable $$x is assigned as 200.
Now we have printed the values $x, $$x and $abc.
        </p>

 <!-- simple example -->
 <h3>Example 2</h3>
<pre id="precode">
&lt;?php
<strong>$x=</strong> "U.P";     
<strong>$$x=</strong> "Lucknow";      
<strong>echo $x.</strong>"&lt;br/>";  
<strong>echo $$x.</strong>"&lt;br/>";   
<strong>echo</strong> "Capital of $x is " . <strong>$$x</strong>; 
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>U.P<br> Lucknow<br>Capital of U.P is Lucknow</h2></p>    
</div>
</div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">     
In the above example, we have assigned a value to the variable x as U.P. Value of reference variable $$x is assigned as Lucknow.
Now we have printed the values $x, $$x and a string.
        </p>

        <!-- simple example -->
 <h3>Example 3</h3>
 <pre id="precode">
&lt;?php
<strong>$name=</strong> "Cat";    
<strong>${$name}=</strong> "Dog";     
<strong>${${$name}}=</strong> "Monkey";      
<strong>echo $name.</strong>"&lt;br>";   
<strong>echo ${$name}.</strong>"&lt;br>";    
<strong>echo $cat.</strong>"&lt;br>";    
<strong>echo $cat.</strong>"&lt;br>";
<strong>echo $Dog.</strong>"&lt;br>";
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>Cat<br>Dog<br>Dog <br>Monkey <br>Monkey</h2></p>    
</div>
</div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">     
In the above example, we have assigned a value to the variable name Cat. Value of reference variable ${$name} is assigned as Dog and ${${$name}} as Monkey.
Now we have printed the values as $name, ${$name}, $Cat, ${${$name}} and $Dog.
        </p>

      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END EIGHTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="php_constant(9).php"><button id="next">Next&#187;</button></a>
            <a href="php_variables(7).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>