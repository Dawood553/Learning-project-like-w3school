<?php
include('php_header.php');
?>
<title>PHP Variables</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">PHP VARIABLES</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>PHP Variable</h3>
            <p style="text-align: justify; margin-right: 20px;">
            A variable in PHP is a name of memory location that holds data. A variable is a temporary storage that is used to store data temporarily.
In PHP, a variable is declared using $ sign followed by variable name.
Syntax of declaring a variable in PHP is given below:
   
        </p>

            <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
$variablename=value;     
</pre>
<h3>PHP Variable: Declaring string, integer and float</h3>
<p style="text-align: justify; margin-right: 20px;">
Let's see the example to store string, integer and float values in PHP variables.
File: variable1.php

</p>
<!-- example end -->

            <!-- simple example -->
            

            <pre id="precode">
&lt;?php
<strong>$str=</strong> "hello string";   
<strong>$x=</strong> 200;   
<strong>$y=</strong> 44.6;   
<strong>echo</strong> "string is: $str <br/>";  
<strong>echo</strong> "integer is: $x <br/>";   
<strong>echo</strong> "float is: $y <br/>";    
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>string is: hello string<br>integer is: 200<br>float is: 44.6</h2></p>    
</div>
</div> 
<!-- example end -->

 <!-- simple example -->
 <h3>PHP Variable: Sum of two variables</h3>

<pre id="precode">
<i>&lt;?php</i>
<strong>$x=</strong> 200;   
<strong>$y=</strong> 44.6;   
<strong>$z=</strong> $x+$y;     
<strong>echo</strong> $xz     


<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>11</h2>
</p>    
</div>
</div> 
<!-- example end -->

<!-- simple example -->
<h3>PHP Variable: case sensitive</h3>
<p style="text-align: justify; margin-right: 20px;">
In PHP, variable names are case sensitive. So variable name "color" is different from Color, COLOR, COLor etc.
File: variable3.php
</p>
<pre id="precode">
<i>&lt;?php</i>

<strong>$color=</strong>"red";     
<strong>echo</strong>"My car is " . $color . "<br>";  
<strong>echo</strong>"My house is " . $color . "<br>";  
<strong>echo</strong>"My boat is " . $color . "<br>";  
<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>My car is red</h2>
    <h2>Notice: Undefined variable: COLOR in C:\wamp\www\variable.php on line 4 <br>
My house is
</h2>
<h2>Notice: Undefined variable: coLOR in C:\wamp\www\variable.php on line 5 <br>
My boat is

</h2>

</p>    
</div>
</div> 
<!-- example end -->

<!-- simple example -->
<h3>PHP Variable: Rules</h3>
<p style="text-align: justify; margin-right: 20px;">
PHP variables must start with letter or underscore only.
PHP variable can't be start with numbers and special symbols.
File: variablevalid.php

</p>
<pre id="precode">
<i>&lt;?php</i>

<strong>$a=</strong>"hello";//letter (valid)   
<strong>$_b=</strong>"hello";//underscore (valid)  
<strong>echo</strong>"$a <br/> $_b";   
<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>Hello <br> Hello</h2>

</p>    
</div>
</div> 
<!-- example end -->

<!-- simple example -->
<h3>File: variableinvalid.php</h3>
<pre id="precode">
<i>&lt;?php</i>

<strong>$4c=</strong>"hello";//number (invalid)    
<strong>$*d=</strong>"hello";//special symbol (invalid)   
<strong>echo</strong>"$4c <br/> $*d";  
<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>Parse error: syntax error, unexpected '4' (T_LNUMBER), expecting variable (T_VARIABLE) <br>
 or '$' in C:\wamp\www\variableinvalid.php on line 2
</h2>

</p>    
</div>
</div> 
<!-- example end -->

<h3>PHP: Loosely typed language</h3>
<p style="text-align: justify; margin-right: 20px;">
PHP is a loosely typed language, it means PHP automatically converts the variable to its correct data type.
</p>

      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SEVENTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="php_variables(8).php"><button id="next">Next&#187;</button></a>
            <a href="php_print(6).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>