<?php
include('php_header.php');
?>
<title>PHP Operator</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">PHP Operators</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>PHP Operators</h3>
            <p style="text-align: justify; margin-right: 20px;">
            PHP Operator is a symbol i.e used to perform operations on operands. For example:
 
 $num=10+20;//+ is the operator and 10,20 are operands  
  
 In the above example, + is the binary + operator, 10 and 20 are operands and $num is variable.
 PHP Operators can be categorized in following forms:
 o	Arithmetic Operators
 o	Comparison Operators
 o	Bitwise Operators
 o	Logical Operators
 o	String Operators
 o	Incrementing/Decrementing Operators
 o	Array Operators
 o	Type Operators
 o	Execution Operators
 o	Error Control Operators
 o	Assignment Operators
 We can also categorize operators on behalf of operands. They can be categorized in 3 forms:
 o	Unary Operators: works on single operands such as ++, -- etc.
 o	Binary Operators: works on two operands such as binary +, -, *, / etc.
 o	Ternary Operators: works on three operands such as "?:".
 

        </p>
        <h3>PHP Operators Precedence</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Let's see the precedence of PHP operators with associativity.
        </p>
        <center>
<table border=1 style="background-color:black; color:white; font-size:20px; width:100%; text-align:center;">
    <thead>
        <tr style="background-color:white; color:red; font-size:32px;">
            <th>Operators</th>
            <th>Additional Information</th>
            <th>Associativity</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>clone new</td>
            <td>clone and new</td>
            <td>non-associative</td>
        </tr>
        <tr>
            <td>[</td>
            <td>array()</td>
            <td>left</td>
        </tr>
        <tr>
            <td>**</td>
            <td>arithmatic</td>
            <td>right</td>
        </tr>
        <tr>
            <td>++ -- ~ (int) (float) (string) (array) (object) (bool) @</td>
            <td>increment/decrement and types</td>
            <td>right</td>
        </tr>
        <tr>
            <td>instanceof</td>
            <td>types</td>
            <td>non-associative</td>
        </tr>
        <tr>
            <td>!</td>
            <td>logical (negation)</td>
            <td>right</td>
        </tr>
        <tr>
            <td>* / %</td>
            <td>arithmatic</td>
            <td>left</td>
        </tr>
        <tr>
            <td>+ - .</td>
            <td>arithmetic and string concatenation</td>
            <td>left</td>
        </tr>
        <tr>
            <td><< >></td>
            <td>bitwise (shift)</td>
            <td>left</td>
        </tr>
        <tr>
            <td>< <= > >=</td>
            <td>comparison</td>
            <td>non-associative</td>
        </tr>
        <tr>
            <td>== != === !== <></td>
            <td>comparison</td>
            <td>non-associative</td>
        </tr>
        <tr>
            <td>&</td>
            <td>bitwise AND</td>
            <td>left</td>
        </tr>
        <tr>
            <td>^</td>
            <td>bitwise XOR</td>
            <td>left</td>
        </tr>
        <tr>
            <td>|</td>
            <td>bitwise OR</td>
            <td>left</td>
        </tr>
        <tr>
            <td>&&</td>
            <td>logical AND</td>
            <td>left</td>
        </tr>
        <tr>
            <td>||</td>
            <td>logical OR</td>
            <td>left</td>
        </tr>
        <tr>
            <td>?:</td>
            <td>ternary</td>
            <td>left</td>
        </tr>
        <tr>
            <td>= += -= *= **= /= .= %= &= |= ^= <<= >>= =></td>
            <td>assignment</td>
            <td>right</td>
        </tr>
        <tr>
            <td>and</td>
            <td>logical</td>
            <td>left</td>
        </tr>
        <tr>
            <td>or</td>
            <td>logical</td>
            <td>left</td>
        </tr>
        <tr>
            <td>xor</td>
            <td>logical</td>
            <td>left</td>
        </tr>
        <tr>
            <td>,</td>
            <td>many uses (comma)</td>
            <td>left</td>
        </tr>
    </tbody>
</table>
</center>

 
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIFTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="#"><button id="next">End&#187;</button></a>
            <a href="php_constant(9).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>