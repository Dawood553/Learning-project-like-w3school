<?php
include('php_header.php');
?>
<title>PHP Echo</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">PHP ECHO</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>PHP Echo</h3>
            <p style="text-align: justify; margin-right: 20px;">
            PHP echo is a language construct not a function, so you don't need to use parenthesis with it. But if you want to use more than one parameters, it is required to use parenthesis.
The syntax of PHP echo is given below:
            </p>

            <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
void echo ( string $arg1 [, string $... ] )  
</pre>
<p style="text-align: justify; margin-right: 20px;">
PHP echo statement can be used to print string, multi line strings, escaping characters, variable, array etc.
            </p>
<!-- example end -->

            <!-- simple example -->
<h3>PHP Echo Printing String</h3>

            <pre id="precode">
&lt;?php
echo "&lt;h2>Hello By PHP Echo&lt;/h2>";
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>Hello By PHP Echo</h2></p>    
</div>
</div> 
<!-- example end -->

 <!-- simple example -->
 <h3>PHP echo: printing multi line string</h3>

<pre id="precode">
<i>&lt;?php</i>

<strong>echo</strong> "&lt;h2>"Hello by PHP echo  
this is multi line  
text printed by   
PHP echo statement  
";&lt;/h2>";

<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>Hello by PHP echo this is multi line text printed by PHP echo statement</h2>
</p>    
</div>
</div> 
<!-- example end -->

<!-- simple example -->
<h3>PHP echo: printing escaping characters</h3>

<pre id="precode">
<i>&lt;?php</i>

<strong>echo</strong> ""Hello escape \"sequence\" characters";  

<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>Hello escape "sequence" characters</h2>
</p>    
</div>
</div> 
<!-- example end -->

<!-- simple example -->
<h3>PHP echo: printing variable value</h3>

<pre id="precode">
<i>&lt;?php</i>

<strong>$msg=</strong>"Hello Skyapper PHP";   
<strong>echo</strong>"Message is: $msg";     

<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>Message is: Hello Skyapper PHP</h2>
</p>    
</div>
</div> 
<!-- example end -->



      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIFTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="php_print(6).php"><button id="next">Next&#187;</button></a>
            <a href="php_example(4).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What is the purpose of the `echo` statement in PHP?",
            a: [{ text: "To declare variables", isCorrect: false },
            { text: "To create arrays", isCorrect: false },
            { text: "To print output to the screen", isCorrect: true },
            { text: "To use PHP functions", isCorrect: false }
            ]

        },
        {
            q: "How do you output multiple expressions using `echo`?",
            a: [{ text: "Separated by semicolons (;)", isCorrect: false, isSelected: false },
            { text: "Separated by parentheses (())", isCorrect: false },
            { text: "Separated by dots (.)", isCorrect: false },
            { text: "Separated by commas (,)", isCorrect: true }
            ]

        },
        {
            q: "What happens when you use `echo` with a variable?",
            a: [{ text: "It prints the variable name", isCorrect: false },
            { text: "It prints an error message", isCorrect: false },
            { text: "It prints the variable value as a string", isCorrect: true },
            { text: "It does nothing", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>