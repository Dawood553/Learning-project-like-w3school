<?php
include('php_header.php');
?>
<title>PHP Print</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">PHP PRINT</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>PHP Print</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Like PHP echo, PHP print is a language construct, so you don't need to use parenthesis with the argument list. Unlike echo, it always returns 1.
The syntax of PHP print is given below:
            </p>

            <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
int print(string $arg)   
</pre>
<p style="text-align: justify; margin-right: 20px;">
PHP print statement can be used to print string, multi line strings, escaping characters, variable, array etc.
</p>
<!-- example end -->

            <!-- simple example -->
<h3>PHP print: printing string</h3>

            <pre id="precode">
&lt;?php
print "Hello by PHP print ";
print ("Hello by PHP print()");   
?>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>Hello by PHP print Hello by PHP print()</h2></p>    
</div>
</div> 
<!-- example end -->

 <!-- simple example -->
 <h3>PHP print: printing multi line string
File: print2.php
</h3>

<pre id="precode">
<i>&lt;?php</i>

<strong>print</strong> "Hello by PHP print  
this is multi line  
text printed by   
PHP print statement  
";  


<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>Hello by PHP print this is multi line text printed by PHP print statement</h2>
</p>    
</div>
</div> 
<!-- example end -->

<!-- simple example -->
<h3>PHP print: printing variable value</h3>

<pre id="precode">
<i>&lt;?php</i>

<strong>$msg=</strong>"Hello print() in PHP";    
<strong>echo</strong>"Message is: $msg";     

<i>?></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
<div class="output">
<p>
    <h2>Message is: Hello print() in PHP</h2>
</p>    
</div>
</div> 
<!-- example end -->





      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SIXTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="php_variables(7).php"><button id="next">Next&#187;</button></a>
            <a href="php_echo(5).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    
       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>