<?php
include('php_header.php');
?>
<title>Introduction of PHP</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">PHP Toturial</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <!-- <h3>What is C++?</h3> -->
            <p style="text-align: justify; margin-right: 20px;">
            PHP tutorial for beginners and professionals provides in-depth knowledge of PHP scripting language. Our PHP tutorial will help you to learn PHP scripting language easily.
This PHP tutorial covers all the topics of PHP such as introduction, control statements, functions, array, string, file handling, form handling, regular expression, date and time, object-oriented programming in PHP, math, PHP MySQL, PHP with Ajax, PHP with jQuery and PHP with XML.


            </p>
            <h3>Why is PHP?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            o	PHP stands for Hypertext Preprocessor.
o	PHP is an interpreted language, i.e., there is no need for compilation.
o	PHP is a server-side scripting language.
o	PHP is faster than other scripting languages, for example, ASP and JSP.

</p>
            <h3>PHP Example</h3>
            <p style="text-align: justify; margin-right: 20px;">
            In this tutorial, you will get a lot of PHP examples to understand the topic well. You must save the PHP file with a .php extension. Let's see a simple PHP example.
File: hello.php
 </p>
<!--FIRST TOPIC END-->


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
&lt;?php
echo "&lt;h2>Hello By PHP &lt;/h2>";
?>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h2 style="margin-left: 2%;">Out Put</h2>
<div id="out">
 <div class="output">
 <p><h2>Hello By PHP</h2></p>    
</div>
</div> 
<!-- example end -->



<h3>Web Development?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            PHP is widely used in web development nowadays. PHP can develop dynamic websites easily. But you must have the basic the knowledge of following technologies for web development as well.
o	HTML
o	CSS
o	JavaScript
o	Ajax
o	XML and JSON
o	jQuery

</p>
<h3>Prerequisite</h3>
<p style="text-align: justify; margin-right: 20px;">
Before learning PHP, you must have the basic knowledge of HTML.
</p>
<h3>Audience</h3>
<p style="text-align: justify; margin-right: 20px;">
Our PHP tutorial is designed to help beginners and professionals.
</p>
<h3>Problem</h3>
<p style="text-align: justify; margin-right: 20px;">
We assure that you will not find any problem in this PHP tutorial. But if there is any mistake or error, please post the error in the contact form.
</p>
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIRST LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="what_is_php(2).php"><button id="next">Next&#187;</button></a>
            <!-- <a href="Introduction of c++(1).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What is PHP primarily used for?",
            a: [{ text: "Mobile app development", isCorrect: false },
            { text: "Desktop application development", isCorrect: false },
            { text: "Web development", isCorrect: true },
            { text: "Game development", isCorrect: false }
            ]

        },
        {
            q: "What is a key feature of PHP?",
            a: [{ text: "It's a compiled language", isCorrect: false, isSelected: false },
            { text: "It's a statically typed language", isCorrect: false },
            { text: "It's a client-side scripting language", isCorrect: false },
            { text: "It's an open-source language", isCorrect: true }
            ]

        },
        {
            q: "What is a popular use of PHP?",
            a: [{ text: "Operating systems", isCorrect: false },
            { text: "Database management systems", isCorrect: false },
            { text: "Content management systems (CMS)", isCorrect: true },
            { text: "Graphic design software", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>