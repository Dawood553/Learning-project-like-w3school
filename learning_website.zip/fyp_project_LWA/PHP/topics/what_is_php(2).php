<?php
include('php_header.php');
?>
<title>What is Php</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">What is PHP?</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>What is PHP?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            PHP is a open source, interpreted and object-oriented scripting language i.e. 
            executed at server side. It is used to develop web applications (an application i.e. 
            executed at server side and generates dynamic page).
            o	PHP is a server side scripting language.
o	PHP is an interpreted language, i.e. there is no need for compilation.
o	PHP is an object-oriented language.
o	PHP is an open-source scripting language.
o	PHP is simple and easy to learn language.

            </p>

            <h3>PHP Features</h3>
            <p style="text-align: justify; margin-right: 20px;">
            There are given many features of PHP.
o	Performance: Script written in PHP executes much faster then those scripts written in other languages such as JSP & ASP.
o	Open Source Software: PHP source code is free available on the web, you can developed all the version of PHP according to your requirement without paying any cost.
o	Platform Independent: PHP are available for WINDOWS, MAC, LINUX & UNIX operating system. A PHP application developed in one OS can be easily executed in other OS also.
o	Compatibility: PHP is compatible with almost all local servers used today like Apache, IIS etc.
o	Embedded: PHP code can be easily embedded within HTML tags and script.

</p>
            
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SECOND LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="install_php(3).php"><button id="next">Next&#187;</button></a>
            <a href="Introduction_of_php(1).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What type of scripting language is PHP?",
            a: [{ text: "Static", isCorrect: false },
            { text: "Client-side", isCorrect: false },
            { text: "Server-side", isCorrect: true },
            { text: "Hybrid", isCorrect: false }
            ]

        },
        {
            q: "What is a characteristic of PHP?",
            a: [{ text: "Object-oriented only", isCorrect: false, isSelected: false },
            { text: "Compiled language", isCorrect: false },
            { text: "Statically typed", isCorrect: false },
            { text: "Loosely typed", isCorrect: true }
            ]

        },
        {
            q: "What is PHP commonly used for?",
            a: [{ text: "Desktop application development", isCorrect: false },
            { text: "Mobile app development", isCorrect: false },
            { text: "Web development and server-side scripting", isCorrect: true },
            { text: "Game development", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->


       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>