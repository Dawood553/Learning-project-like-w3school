<?php
include('php_header.php');
?>
<title>PHP Installation</title>

    <div class="container"> 
        <br>
        <div class="notes">
            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Install PHP</h2>
              <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>How to install PHP?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            To install PHP, we will suggest you to install AMP (Apache, MySQL, PHP) software stack. It is available for all operating systems. There are many AMP options available in the market that are given below:
o	WAMP for Windows
o	LAMP for Linux
o	MAMP for Mac
o	SAMP for Solaris
o	FAMP for FreeBSD
o	XAMPP (Cross, Apache, MySQL, PHP, Perl) for Cross Platform: It includes some other components too such as FileZilla, OpenSSL, Webalizer, Mercury Mail etc.
If you are on Windows and don't want Perl and other features of XAMPP, you should go for WAMP. In a similar way, you may use LAMP for Linux and MAMP for Macintosh.

            </p>

            <h3>Download and Install WAMP Server</h3>
            <p style="text-align: justify; margin-right: 20px;">
            <a href="http://www.wampserver.com/en/" style="border-bottom:1px solid white; width:40%;">Click Me to Download WAMP Server</a>
</p>
         
<h3>Download and Install LAMP Server</h3>
            <p style="text-align: justify; margin-right: 20px;">
            <a href="http://csg.sph.umich.edu/abecasis/lamp/download/" style="border-bottom:1px solid white; width:40%;">Click Me to Download LAMP Server</a>
</p>

<h3>Download and Install MAMP Server</h3>
            <p style="text-align: justify; margin-right: 20px;">
            <a href="http://www.mamp.info/en/downloads/" style="border-bottom:1px solid white; width:40%;">Click Me to Download MAMP Server</a>
</p>

<h3>Download and Install XAMPP Server</h3>
            <p style="text-align: justify; margin-right: 20px;">
            <a href="http://www.apachefriends.org/downloads.html" style="border-bottom:1px solid white; width:40%;">Click Me to Download XAMPP Server</a>
</p>
      <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END THIRD LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="php_example(4).php"><button id="next">Next&#187;</button></a>
            <a href="what_is_php(2).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What is Missing < DOCTYPE html>",
            a: [{ text: "{", isCorrect: false },
            { text: ".", isCorrect: false },
            { text: "!", isCorrect: true },
            { text: "]", isCorrect: false }
            ]

        },
        {
            q: "What is the closing tag of <p>",
            a: [{ text: "<p/>", isCorrect: false, isSelected: false },
            { text: "<\p>", isCorrect: false },
            { text: "<//p>", isCorrect: false },
            { text: "</p>", isCorrect: true }
            ]

        },
        {
            q: "What is the attribute of <a attribute> </a>",
            a: [{ text: "hred='#'", isCorrect: false },
            { text: "ref='#'", isCorrect: false },
            { text: "href='#'", isCorrect: true },
            { text: "All", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

       <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>