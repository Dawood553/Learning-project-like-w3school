<?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\navbar.php');
?>
  <title>Let's Learn Programming PHP</title>




       

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>Welcome to PHP Learning</h1>
          <h2>We are always here to serve you 24/7</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="topics/Introduction_of_php(1).php" class="btn-get-started scrollto">Start Learning</a>
            
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="\fyp_project_LWA\assets\img\logo.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <!-- End Cliens Section -->

     <!-- ======= About Us Section ======= -->
   <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>PHP</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
            Here is a detailed explanation of PHP, including its history, features, and uses:
            </p>
            
            <ul>
            <li><i class=""></i><h3>History of PHP</h3></li>
              <li><i class="ri-check-double-line"></i> Created by Rasmus Lerdorf in 1994</li>
              <li><i class="ri-check-double-line"></i> Initially called "Personal Home Page Tools"</li>
              <li><i class="ri-check-double-line"></i> First released in 1995 as PHP/FI (PHP 1.0)</li>
              <li><i class="ri-check-double-line"></i> Renamed to PHP: Hypertext Preprocessor in 1997 (PHP 3.0)</li>
              <li><i class="ri-check-double-line"></i> Now widely used in web development, especially for server-side scripting and web applications</li>
              
            </ul>

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
          <ul>
              <li><i class=""></i><h3>Features of PHP</h3></li>
              <li><i class="ri-check-double-line"></i> <b>Server-side scripting:</b> Runs on the server-side, generating HTML, CSS, and JavaScript for web browsers</li>
              <li><i class="ri-check-double-line"></i> <b>Open source: </b> Free and open-source software</li>
              <li><i class="ri-check-double-line"></i> <b>Cross-platform: </b> Runs on various operating systems (Windows, macOS, Linux, etc.)</li>
              <li><i class="ri-check-double-line"></i> <b>Loose typology: </b> PHP is dynamically typed, meaning variable types are determined at runtime</li>
              <li><i class="ri-check-double-line"></i> <b>Built-in support: </b> Has built-in support for various databases (MySQL, PostgreSQL, etc.), protocols (HTTP, FTP, etc.), and APIs (JSON, XML, etc.)</li>
            </ul>
            
<!-- Modal Start -->
<button class="btn-learn-more" data-toggle="modal" data-target="#mymodal">
Read More
</button>
<div class="modal fade modal-lg" id="mymodal" data-backdrop="static">
<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
<div class="modal-content">
    <div class="modal-header">
        <h2 class="modal-title">
            PHP
        </h2>
        <button class="close btn btn-white text-danger" data-dismiss="modal">
          X
        </button>
    </div>
    <div class="modal-body">
        <div class="card">
          <!-- <img src="\fyp_project_LWA\assets\img\php.jpg" class="card-img-top img-fluid" alt=""> -->
          <video src="\fyp_project_LWA\assets\img\videos\php.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>

          <div class="card-body">
            <h1 class="card-title">
            Uses of PHP
            </h1>
            <p class="card-text">
            <h3>Web development:</h3>
            Used for server-side scripting, creating dynamic web pages, and web applications
          </p>

            <p class="card-text">
            <h3>Content Management Systems (CMS): </h3>
            Used in popular CMS platforms like WordPress, Joomla, and Drupal
          </p>

            <p class="card-text">
            <h3>E-commerce platforms: </h3>
            Used in e-commerce platforms like Magento and OpenCart
          </p>

            <p class="card text">
                <h3>Social networking sites</h3>
                Used in social networking sites like Facebook and Twitter
              </p>


              <p class="card text">
                <h3>Web services</h3>
                Used in web services like APIs and RESTful APIs
              </p>

              <h1 class="card-title">
              PHP Libraries and Frameworks
              </h1>

              <p class="card text">
                <h3>Laravel</h3>
                A popular PHP framework for building robust and scalable web applications
              </p>

              <p class="card text">
                <h3>CodeIgniter:</h3>
                A lightweight PHP framework for building web applications quickly
              </p>

              <p class="card text">
                <h3>Symfony:</h3>
                A comprehensive PHP framework for building complex web applications
              </p>
            <p class="card text">
                <h3>CakePHP: </h3>
                A rapid development PHP framework for building web applications
              </p>
              
              <p class="card text">
                <h3>PHP-FIG: </h3>
                A group of PHP frameworks and libraries promoting standardization and interoperability
              </p>

              <h1 class="card-title">
              PHP Best Practices
              </h1>

              <p class="card text">
                <h3>Use PHP 7.x or higher: </h3>
                Take advantage of improved performance, security, and features
              </p>

              <p class="card text">
                <h3>Use a PHP framework: </h3>
                Leverage frameworks for rapid development, maintainability, and scalability
              </p>

              <p class="card text">
                <h3>Follow coding standards: </h3>
                Adhere to established coding standards and conventions (PSR-12, etc.)
              </p>

              <p class="card text">
                <h3>Use version control: </h3>
                Manage code changes with Git or other version control systems
              </p>

              <p class="card text">
                <h3>Test code: </h3>
                Write unit tests and integration tests to ensure code quality and reliability
              </p>

              <p class="card text">
                <h3>Conclusion: </h3>
                I hope this provides a detailed overview of PHP! Let me know if you have any specific questions or need further clarification.
              </p>

              

          </div>
        </div>
    
    <div class="modal-footer">
        <button class="btn btn-danger" class="close" data-dismiss="modal">
            close
        </button>
    </div>
</div>

</div>


            <!-- Modal End -->
          </div>
        </div>

      </div>
    </section>
    <!-- End About Us Section -->

    <!-- ======= Why Us Section ======= -->
    
    <!-- End Why Us Section -->

    <!-- ======= Skills Section ======= -->
    <!-- End Skills Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
        <p>"Unlock the power of server-side scripting with our comprehensive PHP topics! Master the art of 
          coding with our in-depth lectures on PHP fundamentals, including PHP Constant, PHP Echo, PHP Installation,
           PHP Introduction, and much more. Our topics are designed to help you understand the basics and beyond, so you can create
            dynamic web applications, interact with databases, and build robust Content Management Systems with ease.
           Whether you're a beginner or looking to refresh your skills, our PHP topics have got you covered!"</p>
       </div>

        <div class="row">
          <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4><a href="topics/php_constant(9).php">PHP Constant</a></h4>
              <p>PHP constants are name or identifier that can't be changed during the execution of the script. PHP constants can be defined by 2 ways: 1. Using define() function 2. Using const keyword PHP constants follow the same PHP variable rules.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="topics/php_echo(5).php">PHP Echo</a></h4>
              <p>PHP echo is a language construct not a function, so you don't need to use parenthesis with it. But if you want to use more than one parameters, it is required to use parenthesis. The syntax of PHP echo is given below:</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="topics/install_php(3).php">PHP Installation</a></h4>
              <p>To install PHP, we will suggest you to install AMP (Apache, MySQL, PHP) software stack. It is available for all operating systems. There are many AMP options available in the market that are given below:</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="topics/introduction_of_php(1).php">PHP Intro</a></h4>
              <p>PHP tutorial for beginners and professionals provides in-depth knowledge of PHP scripting language. Our PHP tutorial will help you to learn PHP scripting language easily.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
    <?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\footer.php');
?>