
   <!-- ======= Supervisor Section ======= -->
   <section id="supervisor" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Supervisor</h2>
          <p style="text-align:justify;" id="resize">
          <b> Dr. Burhan Ullah</b> <br>

<b> Acknowledgement:</b>
We would like to express our deepest gratitude to our honorable supervisor, <b>Dr. Burhan Ullah</b>, the Head of Department for BS Computer Science, for his invaluable guidance and support throughout the development of this project.
<br>
<b>Dr. Burhan Ullah's</b> expertise and encouragement played a crucial role in helping us to complete this lengthy but fruitful academic task. 
We are truly grateful for his unwavering commitment and dedication to our project-related and academic growth
 <br>
 <br>

          </p>
        </div>

        <div class="row">
          <div class="col-lg-12" data-aos="zoom-in" data-aos-delay="100">
            <div class="member d-flex align-items-start">
            <a href="\fyp_project_LWA\assets\img\team\supervisor3.jpg" class="logo me-auto pic"><img src="\fyp_project_LWA\assets\img\team\supervisor3.jpg" alt="" class="rounded-circle img-fluid"></a>

              <div class="member-info">
                <h4>Dr. Burhan Ullah</h4>
                <span id="resize">Supervisor</span>
                <p id="resize"> Special thanks to our project supervisor, Dr Burhan Ullah, and coordinator, for their indispensable guidance and support. Their expertise paved the way for the successful completion of our project. </p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          
        </div>

      </div>
    </section>
    <!-- End Supervisor Section -->

    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Team</h2>
          <p style="text-align:justify;" id="resize">
          <b> M.Dawood Khan Programmer</b> <br>

<b> Bio:</b> Dawood is a skilled programmer with a passion for coding. He has extensive experience in web development and is proficient in a range of programming languages. He is dedicated to delivering high-quality code and is always looking for ways to improve his skills.
 <br>
<b> Goals:</b> To continue learning and growing as a programmer, to contribute to innovative projects, and to help others learn programming skills.
<br><span class="text-danger">Fun fact:</span> <br> <b>Dawood</b> is a self-taught programmer and loves solving complex coding challenges in his free time.
 <br>
 <br>
 <b> Yasir Rehman Helper</b> <br>

<b> Bio:</b> Yasir is a helpful and detail-oriented individual who assists Dawood with programming tasks. He has a strong understanding of technical concepts and is skilled at researching and troubleshooting issues.
<br>
<b> Goals:</b> To continue learning and growing in his role, to provide excellent support to Dawood and the team, and to contribute to the success of projects.
<br><span class="text-danger">Fun fact:</span> <br> <b>Yasir</b> is a quick learner and enjoys helping others understand complex technical concepts in simple terms.


          </p>
        </div>

        <div class="row">

          <div class="col-lg-6" data-aos="zoom-in" data-aos-delay="100">
            <div class="member d-flex align-items-start">
              <!-- <div class="pic"><img src="\fyp_project_LWA\assets\img\team\team-201.jpg" class="img-fluid" alt=""></div> -->
              <a href="\fyp_project_LWA\assets\img\team\team-201.jpg" class="logo me-auto pic"><img src="\fyp_project_LWA\assets\img\team\team-201.jpg" alt="" class="rounded-circle img-fluid"></a>

              <div class="member-info">
                <h4>M.Dawood Khan</h4>
                <span id="resize">Programmer</span>
                <p id="resize">My Name is Dawood and i am the programmer of the project</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="member d-flex align-items-start">
              <!-- <div class="pic"><img src="\fyp_project_LWA\assets\img\team\team-226.jpg" class="img-fluid" alt=""></div> -->
              <a href="\fyp_project_LWA\assets\img\team\team-226.jpg" class="logo me-auto pic"><img src="\fyp_project_LWA\assets\img\team\team-226.jpg" alt="" class="rounded-circle img-fluid"></a>

              <div class="member-info">
                <h4>Yasir Rehman</h4>
                <span id="resize">Helper</span>
                <p id="resize">It's Yasir Rehman my helper in the project thanks to Yasir</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          
        </div>

      </div>
    </section>
    <!-- End Team Section -->

    
    </section>
  <!-- ======= Footer ======= -->
  <footer id="footer">

    
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Dawood & Yasir</h3>
            <p>
              Bannu <br>
              Pakistan,<br>
               <br>
              <strong>Phone:</strong> +923325700407<br>
              <strong>Email:</strong> dawood1542@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#contact">Contact</a></li>

              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Team</a></li>
            </ul>
          </div>

          

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
            <p id="resize">Everyone can contact us through Social Network and we are always here to serve you Thanks</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container footer-bottom clearfix">
      <div class="copyright">
        &copy; Copyright <strong><span>Dawood</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
    
        Designed by <a href="#team">DAWOOD & YASIR</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendro JS Files -->
<script src="\fyp_project_LWA/assets/js/jquery.slim.js"></script>
  <script src="\fyp_project_LWA/assets/js/bootstrap.js"></script>
  <script src="\fyp_project_LWA/assets/js/popper.js"></script>
 <script src="\fyp_project_LWA\assets\vendor\aos\aos.js"></script>
  <script src="\fyp_project_LWA\assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
  <script src="\fyp_project_LWA\assets\vendor\glightbox\js\glightbox.min.js"></script>
  <script src="\fyp_project_LWA\assets\vendor\isotope-layout\isotope.pkgd.min.js"></script>
  <script src="\fyp_project_LWA\assets\vendor\swiper\swiper-bundle.min.js"></script>
  <script src="\fyp_project_LWA\assets\vendor\waypoints\noframework.waypoints.js"></script>
  <script src="\fyp_project_LWA\assets\vendor\php-email-form\validate.js"></script>

  <!-- Template Main JS File -->
  <script src="\fyp_project_LWA\assets\js\main.js"></script>

   <!-- for languages -->
   <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>

</html>