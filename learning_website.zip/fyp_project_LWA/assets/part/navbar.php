<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link rel="icon" href="\fyp_project_LWA\assets\img\back.jpg">

  <link rel="apple-touch-icon" href="\fyp_project_LWA\assets\img\apple-touch-icon.jpg">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

   <!-- Vendor CSS Files -->
  <link href="\fyp_project_LWA\assets\vendor\aos\aos.css" rel="stylesheet">
  <link href="\fyp_project_LWA\assets\vendor\bootstrap\css\bootstrap.min.css" rel="stylesheet">
  <link href="\fyp_project_LWA\assets\vendor\bootstrap-icons\bootstrap-icons.css" rel="stylesheet">
  <link href="\fyp_project_LWA\assets\vendor\boxicons\css\boxicons.min.css" rel="stylesheet">
  <link href="\fyp_project_LWA\assets\vendor\glightbox\css\glightbox.min.css" rel="stylesheet">
  <link href="\fyp_project_LWA\assets\vendor\remixicon\remixicon.css" rel="stylesheet">
  <link href="\fyp_project_LWA\assets\vendor\swiper\swiper-bundle.min.css" rel="stylesheet">

   <!-- Template Main CSS File --> 
  <link href="\fyp_project_LWA\assets\css\style.css" rel="stylesheet">
  <style>
    #resize{
      text-align:justify;
      font-size:18px;
    }
  </style>
</head>
<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      
      <a href="\fyp_project_LWA\assets\img\back.jpg" class="logo me-auto"><img src="\fyp_project_LWA\assets\img\back.jpg" alt="" class="rounded-circle img-fluid"></a>


      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="http://localhost/fyp_project_LWA/index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto" href="#supervisor">Supervisor</a></li>

          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          
          <li><a class="getstarted scrollto" href="#about">Explore</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <!-- .navbar -->
       
   <!-- for languages -->

   <div id="google_element" class="mx-1"></div>

<!-- for languages end -->