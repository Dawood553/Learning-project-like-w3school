<?php
$con=mysqli_connect('localhost','root','','private_db');
?>