<?php
$con=mysqli_connect('localhost','root','','private_db');
?>
<!DOCTYPE html> 
<html> 
<head> 
	<title>Feedback_Form</title>
     <!-- Favicons -->
     <link href="/fyp_project_LWA/assets/img/back.jpg" rel="icon">
	<meta charset="utf-8"> 
	<meta name="viewport"content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="\fyp_project_LWA\assets\vendor\bootstrap\css\bootstrap.min.css">
    <script src="/fyp_project_LWA/assets/js/jquery.slim.js"></script>
  <script src="/fyp_project_LWA/assets/js/bootstrap.js"></script>
  <script src="/fyp_project_LWA/assets/js/popper.js"></script>
	<link rel="stylesheet" href= "\fyp_project_LWA\config\feedback_style.css"> 
	<style> 
		form { 
			box-shadow: 10px 10px 40px grey; 
			padding: 50px; 
			margin: 20px; 
		}
    #php2{
            color:white;
            border:1px solid white; 
            border-radius:5px;
            background-color:red;
            height: 50px;
            font-size:32px;
    }
    #php{
            color:white;
            font-weight:250;
            border:2px solid white; 
            border-radius:10px;
            padding:5px 5px 5px 5px;
            background-color:black;
            height: 50px;
            width:100%;
            font-size:32px;
        }
	</style> 
</head> 

<body> 

<?php
if(isset($_POST['submit'])){
    $fullname=$_POST['name'];
    $email=$_POST['email'];
    $message=$_POST['message'];
    $send=mysqli_query($con,"INSERT INTO `feedback`(`full_name`, `email`, `message`) VALUES ('$fullname','$email','$message');");
    if($send)
    {

        echo '<div class="col-12">
        <div class="alert alert-info text-white bg-info mt-1">
        <div class="row">
        <div class="col-md-11"><p>Thanks For Your Feedback</p></div>
              <div class="col-md-1"><button class="close btn btn-success active" data-dismiss="alert" style="margin-right:auto;">
              X
             </button></div>
        </div></div> ';
        
    }
    else
    {

        echo '<div class="col-12">
        <div class="alert alert-danger bg-danger text-white mt-1">
        <div class="row">
        <div class="col-md-11"><p>Failed Please Try Again</p></div>
              <div class="col-md-1"><button class="close btn btn-success active" data-dismiss="alert" style="margin-right:auto;">
              X
             </button></div>
        </div></div> ';
		
    }
}
?>
	<form method="post" action="" enctype="multipart/form-data" class="w-75 mx-auto"> 
		<a href="http://localhost/fyp_project_LWA/index.php"><button type="button" class="btn btn-success"style="font-size:25px; width:5%;">&laquo;</button></a>
		<h1 class="text-success text-center"> 
			FeedBack Form
		</h1> 
		<!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
		<h5 class="text-success text-center"> Sending email with a file attachment </h5> 
		<div class="form-group"> 
			<input type="text" pattern="[A-Za-z ]+" title="Only letters and spaces are allowed" name="name" class="form-control" placeholder="Name" required=""> 
		</div> 
		
		<div class="form-group"> 
			<input type="email" name="email" pattern="[a-zA-z0-9]+@+gmail.com" title="Abc123@gmail.com" class="form-control" placeholder="Email address" required=""> 
		</div> 
		
		<div class="form-group"> 
			<!-- <input type="text" name="subject" class="form-control" placeholder="Subject" required="">  -->
		</div> 
		
		<div class="form-group"> 
			<textarea name="message" class="form-control" placeholder="Write your message here..." required=""></textarea> 
		</div> 
		
		<div class="form-group"> 
			
		</div> 
		
		<div class="submit text-center"> 
			<input type="submit" name="submit" class="btn btn-success " value="SEND MESSAGE"> 
		</div> 
		
	</form> 

	<!-- for languages -->
	<script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body> 

</html> 
