<?php
$con=mysqli_connect('localhost','root','','private_db');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Discussion</title>
     <!-- Favicons -->
    <link href="/fyp_project_LWA/assets/img/back.jpg" rel="icon">

    <link rel="stylesheet" href="\fyp_project_LWA\assets\vendor\bootstrap\css\bootstrap.min.css">
    <script src="/fyp_project_LWA/assets/js/jquery.slim.js"></script>
  <script src="/fyp_project_LWA/assets/js/bootstrap.js"></script>
  <script src="/fyp_project_LWA/assets/js/popper.js"></script>
</head>
<body class="bg-secondary">
    <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->


 <!-- Php Code -->
 <?php
if(isset($_POST['submit'])){
    $fullname=$_POST['fullname'];
    $email=$_POST['email'];
    $language=$_POST['language'];
    $topic=$_POST['topic'];
    // $reason=$_POST['reason'];
    $message=$_POST['msg'];
    $send=mysqli_query($con,"INSERT INTO `complaints`(`full_name`, `email`, `language`, `topic`,  `detail`) VALUES ('$fullname','$email','$language','$topic','$message');");
    if($send)
    {
        echo '<div class="col-12">
        <div class="alert alert-danger bg-info text-white mt-1">
        <div class="row">
        <div class="col-md-11"><p>Complaint SuccessFully Submitted We will Contact You Within 24 hours</p></div>
            
              <div class="col-md-1"><button class="close btn btn-success active" data-dismiss="alert" style="margin-right:auto;">
              X
             </button></div>
        </div></div> ';
    }
    else
    {
        echo '<div class="col-12">
        <div class="alert alert-danger bg-info text-white mt-1">
        <div class="row">
        <div class="col-md-11"><p>Complaint Failed Please Try Again</p></div>
            
              <div class="col-md-1"><button class="close btn btn-success active" data-dismiss="alert" style="margin-right:auto;">
              X
             </button></div>
        </div></div> ';
    }
}
?>

        <!-- Php Code End -->

 <div class="container m-auto">
    
 <form action="" method="post">

    <div class="row p-5 m-5 bg-dark text-light"  style="border:2px solid white; border-radius:10px;">
    <div class="row">
    <div class="col">
    <a href="http://localhost/fyp_project_LWA/index.php" class="btn btn-success p-0 text-center" style="font-size:25px; width:5%;">&laquo;</a>
    </div>
</div>
    <h1 class="mb-5 text-uppercase text-center">Submit Your Discussion</h1>
        <hr style="background-color:red;height:3px; width:50%; margin-left:25%;margin-top:-5%;">
        
        <div class="col-md-6">
            <div class="form-group">
                <label for="">Name</label>
                <input type="text" pattern="[A-Za-z ]+" title="Only letters and spaces are allowed" name="fullname" class="form-control" name="fullname" required>
            </div>
            <br>
            <div class="form-group">
                <label for="">Email</label>
                <input type="email" name="email" class="form-control" pattern="[a-zA-z0-9]+@+gmail.com" title="Abc123@gmail.com" required>
            </div>
            <br>
            <div class="form-group">
                <label for="">Select Language</label>
                <!-- <input type="text" class="form-control" name="language" required> -->
                <select name="language" id="" class="form-control" required>
                    <option value="HTML">HTML</option>
                    <option value="CSS">CSS</option>
                    <option value="JavaScript">JavaScript</option>
                    <option value="PHP">PHP</option>
                    <option value="Python">Python</option>
                </select>
            </div>
        </div>
        <br>

        <div class="col-md-6">
            <div class="form-group">
                <label for="">Topic</label>
                <input type="text" name="topic" class="form-control" required>
            </div>
            
            <div class="form-group mb-3">
                <label for="">Details</label>
                <!-- <input type="text" name="msg" id="" class="form-control" required> -->
                <textarea name="msg" id="" class="form-control" style="height:150px;" placeholder="Please provide some details..."></textarea>
            </div>
        </div>
        <br>

        <div class="col-md-12">
           
            <br>
            <div class="form-group mb-5">
                <input type="submit" name="submit" value="Submit" class="btn btn-success w-100 mt-2">
            </div> 
        </div>
    </div>
    </form>
 </div>

  <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>