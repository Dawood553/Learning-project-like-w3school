<?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\navbar.php');
?>
  <title>Let's Learn Programming CSS</title>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>Welcome to css Learning</h1>
          <h2>We are always here to serve you 24/7</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="topics/Introduction of css(1).php" class="btn-get-started scrollto">Start Learning</a>
            
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="\fyp_project_LWA\assets\img\logo.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <!-- End Cliens Section -->

   <!-- ======= About Us Section ======= -->
   <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>CSS</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
           
            </p>

            <ul>
            <li><i class=""></i><h3>What is CSS?</h3></li>
              <li><i class="ri-check-double-line"></i> CSS stands (for Cascading Stylesheet.) is a styling language used to control the layout and appearance of web pages written in HTML and XHTML.</li>
              <li><i class="ri-check-double-line"></i> CSS defines styles of your web pages including design, layout and variations in display across devices and screen sizes. </li>
            </ul>

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
          <ul>
              <li><i class=""></i><h3>CSS Structure</h3></li>
              <li><i class="ri-check-double-line"></i> <b>SELECTOR:</b> Used to target HTML elements, such as h1, .class, #id</li>
              <li><i class="ri-check-double-line"></i> <b>PROPERTIES: </b> Define the styles to be applied, such as color, background-color, padding.</li>
              <li><i class="ri-check-double-line"></i> <b>VALUES: </b> Assigned to properties, such as blue, gray, 10px.</li>
              <li><i class="ri-check-double-line"></i> <b>RULES: </b> Combine selector, properties, and values, such as h1{color:blue;}</li>
            </ul>
            
<!-- Modal Start -->
<button class="btn-learn-more" data-toggle="modal" data-target="#mymodal">
Read More
</button>
<div class="modal fade modal-lg" id="mymodal" data-backdrop="static">
<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
<div class="modal-content">
    <div class="modal-header">
        <h2 class="modal-title">
            CSS
        </h2>
        <button class="close btn btn-white text-danger" data-dismiss="modal">
          X
        </button>
    </div>
    <div class="modal-body">
        <div class="card">
          <!-- <img src="\fyp_project_LWA\assets\img\css.jpg" class="card-img-top img-fluid" alt=""> -->
          <video src="\fyp_project_LWA\assets\img\videos\css.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>

          <div class="card-body">
            <h1 class="card-title">
            CSS Components
            </h1>
            <p class="card-text">
            <h3>DECLARATION:</h3>
            Individuals styles within a rule, such as color: blue;
          </p>

            <p class="card-text">
            <h3>BLOCKS: </h3>
            Groups of declarations enclosed in curly braces {}, such as h1{...}
            </p>

            <p class="card-text">
            <h3>MEDIA QUERIES: </h3>
            Used to apply different styles based on device screen size, orientation, or other characteristics.
            </p>

            <p class="card text">
                <h3>IMPORTS:</h3>
                Used to include external CSS files, such as `@import "styles.css";.
              </p>

              <p class="card text">
                <h3>VARIABLES:</h3>
                
                Used to define reusable values, such as :root{--primary-color:blue;};
              </p>

              <p class="card text">
                <h3>FUNCTION:</h3>
                Used to perform calculations or transformations, such as calc() or rgba().
              </p>

             

          </div>
        </div>
    
    <div class="modal-footer">
        <button class="btn btn-danger" class="close" data-dismiss="modal">
            close
        </button>
    </div>
</div>

</div>


            <!-- Modal End -->
          </div>
        </div>

      </div>
    </section>
    <!-- End About Us Section -->


    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <p>
          "Learn the building blocks of web development with our comprehensive 
          programming language topics! Master the art of coding with our in-depth
           lectures on CSS fundamentals, including Introduction Of CSS, CSS Syntax, CSS Style,
            CSS Form, and much more. Our topics are designed to help you understand the basics and beyond,
             so you can create engaging web pages and applications with ease. Whether you're a beginner or 
             looking to refresh your skills, 
            our programming language topics have got you covered!"
          </p>
        </div>

        <div class="row">
          <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4><a href="topics/introduction of css(1).php">Introduction Of CSS</a></h4>
              <p>CSS stands for Cascading Stylesheet.
CSS is a stylesheet language
used to describe the
presentation of an HTML
documnent.
</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="topics/css inserting(2).php">CSS INSERTING</a></h4>
              <p>There are three simple ways to insert
CSS into an HTML document.
Internal Style Sheet
External Style Sheet
Inline Styling
</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="topics/css border(3).php">CSS BORDERS</a></h4>
              <p>
              In CSS, we can decorate borders with
lines, make it square or rounded.
Border Style
The border-style CSs property sets the
line style for alL four sides of an
element's border.

              </p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="topics/css text(5).php">CSS TEXT</a></h4>
              <p> 
              CSS provides a lot of ways to
format text including changing color,
indentation, adding text-decoration and
a lot more.

              </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
    <?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\footer.php');
?>