<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="title.jpg">
    <link rel="stylesheet" href="/fyp_project_LWA/config/style3.css">
    <link rel="stylesheet" href="/fyp_project_LWA/config/quiz.css">

<style>


</style>
</head>
<body>
    <!--SIDE MENU BAAR CODING START -->
    <div id="sideNav">
        <br>
        <br>
        <a href="\fyp_project_LWA\CSS\index.php">Home</a>
        <a href="Try it yourself.php">Code Area</a>


        <input id="searchbar" onkeyup="search_subject()" type="text" name="search" placeholder="Search Lecture..">
        <hr> 
        <ol id="list" style="list-style: none;">            
        <h2 id="lecture">Lectures</h2>    
        <li><a href="Introduction of css(1).php" class="subject">Introdution of CSS</a></li>
        <li><a href="css inserting(2).php" class="subject">CSS Inserting</a></li>
        <li><a href="css border(3).php" class="subject">CSS Border</a></li>
        <li><a href="border color(4).php" class="subject">CSS Border Color</a></li>
        <li><a href="css text(5).php" class="subject">CSS Text</a></li>
        <li><a href="css decoration(6).php" class="subject">CSS Decoration</a></li>
        <li><a href="css shadow(7).php" class="subject">CSS Text Shadow</a></li>
        <li><a href="css letter spacing(8).php" class="subject">CSS Lettter Spacing</a></li>
        <li><a href="css white spaces(9).php" class="subject">CSS White Spaces</a></li>
        <li><a href="css fonts(10).php" class="subject">CSS Fonts</a></li>
    </div>
    <!-- code for search button  -->
    <script>
        function search_subject() { 
            let input = document.getElementById('searchbar').value 
            input=input.toLowerCase(); 
            let x = document.getElementsByClassName('subject'); 
        for (i = 0; i < x.length; i++) {  
                if (!x[i].innerHTML.toLowerCase().includes(input)) { 
                    x[i].style.display="none"; 
          }
                else { 
                    x[i].style.display="list-item";                  
                } 
        }
        }
        </script>

<!-- code for search button end -->
    <div id="manuBtn">
        <!--<img src="menu.png" id="menu">-->
        <p style="color:white;" id="topics">TOPICS</p>            
    </div>

<script>
        var manuBtn = document.getElementById("manuBtn")
        var sideNav = document.getElementById("sideNav")
        var menus = document.getElementById("menu")           
        sideNav.style.right = "-500px";
        manuBtn.onclick = function()
          {
            if(sideNav.style.right == "-500px"){
                sideNav.style.right ="0"
                
                menu.src = "close.jpg";                  
            }
            else{
                sideNav.style.right ="-500px"
                menu.src = "close.jpg";
            }
        }
    </script>
    <!--SIDE MENU BAAR CODING END-->