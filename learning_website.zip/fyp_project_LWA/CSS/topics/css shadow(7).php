<?php
include('css_header.php');
?>
    <title>CSS Text Shadow</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">CSS Text Shadow</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->


            <h3>CSS Text Shadow</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The text-shadow CSS property adds
shadows to text. Each shadow is
described by some combination of X
and Y offsets from the element, blur
radius, and color.
Valid Values:
<br>
&lt;color>: optional; sets the color of the shadow; if this is not defined the value is left upto the user-agent
<br>
offset-x offset-y: required value; it specifies the shadow's distance from the text; offset-x is the horizontal distance while offset-y is the vertical distance
<br>
blur-radius: optional; defaults to 0; this is a &lt;length> value, it defines the size of the blur/shadow If the optional values are not present they will be set to their default values.
                </p>
<!--FIRST TOPIC END-->


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        text-shadow: 2px 2px 3px red ;
    }
    <i>#p2</i>
    {
        text-shadow: #173459 1px 0 10px;
    }
    <i>#p3</i>
    {
        text-shadow: 2px 2px rgb(128, 0, 250, 100);
    }
    <i>#p4</i>
    {
        text-shadow : 1px 3px;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i>id=p1</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p4</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="text-shadow: 2px 2px 3px red;"> i am peragraph </p>
    <p style="text-shadow: #173459 1px 0 10px;"> i am peragraph </p>
    <p style="text-shadow: 2px 2px rgb(128, 0, 250, 100);"> i am peragraph </p>
    <p style="text-shadow : 1px 3px;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

 



    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SEVENTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="css letter spacing(8).php"><button id="next">Next&#187;</button></a>
            <a href="css decoration(6).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>