<?php
include('css_header.php');
?>
    <title>CSS Letter Spacing</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">CSS Letter Spacing</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->


            <h3>CSS Letter Spacing</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The letter-spacing CSS property sets
the length and behavior of the space
between letters.
Valid Values:
<ul>
                    <li>normal: sets the normal letter spacing for the current font &lt;length></li>
                   
                </ul>
</p>
<!--FIRST TOPIC END-->


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        letter-spacing: normal;
    }
    <i>#p2</i>
    {
        letter-spacing: 3px;
    }
    <!-- <i>#p3</i>
    {
        text-shadow: 2px 2px rgb(128, 0, 250, 100);
    }
    <i>#p4</i>
    {
        text-shadow : 1px 3px;
    } -->
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i>id=p1</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="letter-spacing: normal;"> i am peragraph </p>
    <p style="letter-spacing: 3px;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

<h3>CSS Word Spacing</h3>
            <p style="text-align: justify; margin-right: 20px;">
            CSS Word Spacing
The word-spacing CSS property sets
the length of the space between words.
Valid Values:

<ul>
                    <li>normal: sets the normal word
spacing as defined by the
browser
&lt;length>
&lt;percentage>
</li>
                   
                </ul>
</p>
<!--FIRST TOPIC END-->


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        word-spacing: normal;
    }
    <i>#p2</i>
    {
        word-spacing: 14px;
    }
    <i>#p3</i>
    {
        word-spacing: 20%;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i>id=p1</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="word-spacing: normal;"> i am peragraph </p>
    <p style="word-spacing: 14px;"> i am peragraph </p>
    <p style="word-spacing: 20%;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

<h3>CSS Line Height</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The line-height property specifies the
Amount of space used in lines such as
In text.
Valid Values:


<ul>
                    <li>Normal: depends on the user Agent</li>
                    <li> &lt;number>: the value is Multiplied by the element’s Current font size; this is the Preferred way to set Line-height &lt;length> &lt;percentage></li>
                   
                </ul>
</p>
<!--FIRST TOPIC END-->


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>div</i>
    {
        line-height:20px;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;div></i>
    <i>&lt;p></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;/div></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

        <p>i am peragraph</p>
        <br>
        <p>i am peragraph</p>
        <br>
        <p>i am peragraph</p>
    

</p>
        </div>
        </div> 
<!-- example end -->

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END EIGHT LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="css white spaces(9).php"><button id="next">Next&#187;</button></a>
            <a href="css shadow(7).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    
    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>