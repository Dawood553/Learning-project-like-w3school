<?php
include('css_header.php');
?>
    <title>CSS Fonts</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">CSS Fonts</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->


            <h3>CSS Fonts</h3>
            <p style="text-align: justify; margin-right: 20px;">
            CSS Fonts define the font family, size, style, weight or boldness and variant of a text.
CSS Font Family There are two types of font family names in CSS:
&lt;generic-name>: a group of font families which have similar looks e.g. SanS-serif, Monospace
&lt;family-name>: a specific font family name e.g. Lucida Console, Verdana
Here is a table of the most common generic font names with some of their specific font family names.
</p>
<center>
<table border="1" style="padding:5px;">
    <thead style="color:white; background:black; font-size:32px;">
        <tr>
            <th>&lt;generic-name></th>
            <th>&lt;family-name></th>
        </tr>
    </thead>
    <tbody style="color:white; background:red; font-size:20px;">
        <tr>
            <td>serif</td>
            <td>"Times New Roman", Georgia, Lucida Bright, Lucida Fax, Palatino Linotype", Palladio, "URW Palladio"</td>
        </tr>

        <tr>
            <td>sans-serif</td>
            <td>Arial, Verdana, "Open Sans", "Fira Sans","Lucida Sans Unicode", "Trebuchet MS", "Liberation Sans", "Nimbus Sans L"</td>
        </tr>

        <tr>
            <td>monospace</td>
            <td>"Courier New", "Fira Mono", "DejaVu Sans Mono", Menlo, Consolas, "Liberation Mono", Monaco, "Lucida Console"</td>
        </tr>

        <tr>
            <td>cursive</td>
            <td>"Brush Script MT", "Brush Script Std", "Lucida  Calligraphy", "Lucida Handwriting", "Apple Chancery"</td>
        </tr>
        <tr>
            <td>fantasy</td>
            <td>Papyrus, Herculanum, Party LET, Curlz MT, Harrigton</td>
        </tr>
    </tbody>
</table>
</center>
<br>
<p style="text-align: justify; margin-right: 20px;">
Note! It is recommended to enquote font family nameswith multiple words e.g. "Lucida Console" (doublequotes), 'Liberation Mono' (single quotes) The font-family CSS property specifies  a list of prioritized font families. Each font family namne or generic names should be separated by a comma (,).
Having multiple font family names specified lets the browser select an acceptable fallback font when  necessary.
The browser will then pick a font to use from the specified list starting from first to last specified. If the browser does not support the first font, it will try the second font and so on.

</p>
<!--FIRST TOPIC END-->


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>p</i>
    {
        font-family: 'Times New Roman', Times, serif;
    }
    <!-- <i>#p2</i>
    {
        white-space:nowrap;
    }
    <i>#p3</i>
    {
        white-space:pre;
    }
    <i>#p4</i>
    {
        white-space : pre-wrap;
    } -->
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i></i>></i>i am peragraph <i>&lt;/p></i>
    <!-- <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p4</i>></i>i am peragraph <i>&lt;/p></i> -->
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="font-family:'Times New Roman', Times, serif;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

<h3>CSS Font Size</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The font-size CSS property sets the size of a font. Valid Values: XX-small, x-small, small, medium, large, x-large, XX-large: absolute-size keywords smaller, larger: relative-size keywords the font would either
be smaller or larger than its parent element &lt;length>: px and em are the most Common and recommended &lt;percentage>: relative to the font size of the parent element

</p>
<!--FIRST TOPIC END-->

<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>p</i>
    {
        font-size: medium;
    }
    <!-- <i>#p2</i>
    {
        white-space:nowrap;
    }
    <i>#p3</i>
    {
        white-space:pre;
    }
    <i>#p4</i>
    {
        white-space : pre-wrap;
    } -->
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p<i></i>></i>i am peragraph <i>&lt;/p></i>
    <!-- <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p4</i>></i>i am peragraph <i>&lt;/p></i> -->
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="font-size:medium;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->
<p style="text-align: justify; margin-right: 20px;">
Setting Font Size in Pixels A px value is a good choice and recommended esp. if we need pixels accuracy. A px value is static.
</p>
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>p</i>
    {
        font-size: 32px;
    }
    <!-- <i>#p2</i>
    {
        white-space:nowrap;
    }
    <i>#p3</i>
    {
        white-space:pre;
    }
    <i>#p4</i>
    {
        white-space : pre-wrap;
    } -->
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p<i></i>></i>i am peragraph <i>&lt;/p></i>
    <!-- <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p4</i>></i>i am peragraph <i>&lt;/p></i> -->
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="font-size:32px;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

<p style="text-align: justify; margin-right: 20px;">
Setting Font Size in Ems Setting font size with the em value is highly recommended. It allows the user to resize text in the browser's settings. An em value is dynamic. It uses the browser's default font size which is
16px so 1em = 16px. To convert px to em, use this formula: em = pixels/16

</p>
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        font-size: 2em;
    }
    <i>#p2</i>
    {
        font-size: 3em;
    }
    <i>#p3</i>
    {
        font-size: 4em;
    }
    <!-- <i>#p4</i>
    {
        white-space : pre-wrap;
    } -->
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i></i>id=p1></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
    <!-- <i>&lt;p <i>id=p4</i>></i>i am peragraph <i>&lt;/p></i> -->
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="font-size:2em;"> i am peragraph </p>
    <p style="font-size:3em;"> i am peragraph </p>
    <p style="font-size:4em;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->


<h3>CSS Font Style</h3>
<p style="text-align: justify; margin-right: 20px;">
The fornt-style CSS property sets how
a font should be styled.
Valid Values:
 <ul>
    <li>normal: sets the font to its normal style</li>
    <li>italic: italicizes a font</li>
    <li>oblique : selects the font style classified as oblique</li>
 </ul>
</p>
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        font-style : normal ;
    }
    <i>#p2</i>
    {
        font-style : italic ;
    }
    <i>#p3</i>
    {
        font-style : oblique ;
    }
    <!-- <i>#p4</i>
    {
        white-space : pre-wrap;
    } -->
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i></i>id=p1></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
    <!-- <i>&lt;p <i>id=p4</i>></i>i am peragraph <i>&lt;/p></i> -->
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="font-style : normal ;"> i am peragraph </p>
    <p style="font-style : italic ;"> i am peragraph </p>
    <p style="font-style : oblique ;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

<h3>CSS Font Weight</h3>
<p style="text-align: justify; margin-right: 20px;">
The font-weight CSS property sets the
weight or boldness of a font.
Valid Values:
&lt;number>: a number from 1 to
1000

 <ul>
    <li>normal: sets a font to its normal weight; same as 400</li>
    <li>bold: emboldens a font; same as 700</li>
    <li>lighter: sets the font weight to be lighter than its parent element's available font weights</li>
    <li>bolder: sets the font weight to be heavier than its parent element's available font weights</li>
 </ul>
</p>
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        font-weight: normal;
    }
    <i>#p2</i>
    {
        font-weight: bold;
    }
    <i>#p3</i>
    {
        font-weight: lighter;
    }
    <i>#p4</i>
    {
        font-weight: bolder;
    }
    <i>#p5</i>
    {
        font-weight: 1000;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i></i>id=p1></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p4</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p5</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="font-weight:normal;"> i am peragraph </p>
    <p style="font-weight:bold;"> i am peragraph </p>
    <p style="font-weight:lighter;"> i am peragraph </p>
    <p style="font-weight:bolder;"> i am peragraph </p>
    <p style="font-weight:1000;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

<h3>CSS Font Varient</h3>
<p style="text-align: justify; margin-right: 20px;">
The font-variant CSS property sets
whether a text should be displayed
normally or in small-caps.
Valid Values:


 <ul>
    <li>normal: specifies a normal font face</li>
    <li>small-caps: lowercase letters are converted to uppercase; Converted uppercase letters appears in a smaller font size</li>

 </ul>
</p>
<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        font-variant: normal;
    }
    <i>#p2</i>
    {
        font-variant: small-caps;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i></i>id=p1></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="font-variant:normal;"> i am peragraph </p>
    <p style="font-variant: small-caps;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->


















    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END TENTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <!-- <a href="css fonts(10).php"><button id="next">Next&#187;</button></a> -->
            <a href="css white spaces(9).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    
    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>