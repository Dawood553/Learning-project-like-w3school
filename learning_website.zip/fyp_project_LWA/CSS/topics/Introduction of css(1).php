<?php
include('css_header.php');
?>
    <title>Introduction of CSS</title>

    <div class="container"> 
        <br>
        
        <div class="notes">






            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">What is CSS?</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>What is CSS?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            CSS stands for Cascading Stylesheet.
CSS is a stylesheet language
used to describe the
presentation of an HTML
documnent.
CSS describes how elements
should be rendered on screen.
CSS Prerequisites
Basic knowledge of working with files or
file management.
Basic understanding of HTML. In order
to start learning CSs you have to have
a basic understanding of HTML first.

            </p>
            <h3>Why Use CSS</h3>
            <p style="text-align: justify; margin-right: 20px;">
            CSS defines styles of your web pages
including design, layout and variations in
display across devices and screen sizes.
CSS can save you a lot of work. An
external stylesheet saved as .css can
be used to style multiple web pages all
at once!

            </p>
<!--FIRST TOPIC END-->



<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i id="yellow">&lt;style></i>
    <i>p</i>
    {
        font-size:20px;
        color:gold;
        background-color:black;

    }
      <!-- <i>body</i>
    {
        background-color:black;
    } -->
    <i id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p></i>I am peragraph<i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
    <p style="color:gold; background-color:black; font-size:20px;">I am peragraph</p>
        </div>
        </div> 
<!-- example end -->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIRST LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="css inserting(2).php"><button id="next">Next&#187;</button></a>

            <!-- <a href="Introduction of c++(1).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "CSS stands for?",
            a: [{ text: "Cascade Style", isCorrect: false },
            { text: "Casing Stylesheet", isCorrect: false },
            { text: "Cascading Stylesheet", isCorrect: true },
            { text: "None", isCorrect: false }
            ]

        },
        {
            q: "An external stylesheet saved as",
            a: [{ text: ".CSS", isCorrect: false, isSelected: false },
            { text: ".see_ss", isCorrect: false },
            { text: ".cs", isCorrect: false },
            { text: ".css", isCorrect: true }
            ]

        },
        {
            q: "In order to start learning CSs you have to have a basic understanding of",
            a: [{ text: "JavaScript", isCorrect: false },
            { text: "PHP", isCorrect: false },
            { text: "HTML", isCorrect: true },
            { text: "All", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    
<!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>