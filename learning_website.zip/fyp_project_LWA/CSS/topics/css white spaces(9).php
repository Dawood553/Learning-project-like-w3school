<?php
include('css_header.php');
?>
    <title>CSS White Spaces</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">CSS White Spaces</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->


            <h3>CSS White Spaces</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The white-space CsS property sets
how the white space is handled inside
an element.
Valid Values:

<ul>
                    <li> normal: Sequences of white space are collapsed. Newline characters in the source are handled the same as other white space. Lines are broken as necessary to fill line boxes.</li>
                    <li> nowrap: Collapses white space as for normal, but suppresses Line breaks (text wrapping) within the source. </li>
                    <li> pre: Sequences of white space are preserved. Lines are only broken at newline characters in the source and at &lt;br></li>
                   <li>pre-wrap: Sequences of white space are preserved. Lines are broken at newline characters, at &lt;br>, and as necessary to fill line boxes.</li>
                   <li>pre-line: Sequences of white space are collapsed. Lines are broken at newline characters, at &lt;br>, and as necessary to fill line boxes.</li>
                </ul>
</p>
<!--FIRST TOPIC END-->


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        white-space: normal;
    }
    <i>#p2</i>
    {
        white-space:nowrap;
    }
    <i>#p3</i>
    {
        white-space:pre;
    }
    <i>#p4</i>
    {
        white-space : pre-wrap;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i>id=p1</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p3</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p4</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="white-space: normal;"> i am peragraph </p>
    <p style="white-space: nowrap;"> i am peragraph </p>
    <p style="white-space: pre;">          i am peragraph </p>
    <p style="white-space: pre-wrap;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

<h3>CSS Text Direction</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The direction CSS property sets the
direction of a text (and more).
Valid Values:


<ul>
                    <li>ltr: sets text and other elements go from left to right</li>
                    <li>rtl: sets text and other elements go from right to left</li>
                   
                </ul>
</p>
<!--FIRST TOPIC END-->


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#rtl</i>
    {
        direction:rtl;
    }
    <i>#ltr</i>
    {
        direction:ltr;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i>id=rtl</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=ltr</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="direction:rtl;"> i am peragraph and my direction is from right to left </p>
    <p style="direction:ltr;"> i am peragraph and my direction is from left to right</p>

</p>
        </div>
        </div> 
<!-- example end -->

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END NINETH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="css fonts(10).php"><button id="next">Next&#187;</button></a>
            <a href="css letter spacing(8).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>