<?php
include('css_header.php');
?>
    <title>CSS Borders</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">CSS Borders</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>CSS Borders</h3>
             
            <p style="text-align: justify; margin-right: 20px;">
            In CSS, we can decorate borders with
lines, make it square or rounded.
Border Style
The border-style CSs property sets the
line style for alL four sides of an
element's border.
Valid Values:





                <ul>
                    <li>none: displays no border</li>
                    <li>hidden : displays no border</li>
                    <li>dotted: displays a series of rounded dots</li>

                    <li>dashed: displays a series of short square-ended dashes or Line segments</li>
                    <li>solid: displays a single, straight, solid line</li>
                    <li>double: displays two straight Lines</li>
                    <li>groove: displays a border with a carved appearance</li>
                    <li>ridge: displays a border with an extruded appearance</li>
                    <li>inset: displays a border that makes the element appear embedded</li>
                    <li>outset: displays a border that makes the element appear embossed</li>
                </ul>
                </p>
<!--FIRST TOPIC END-->



<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
    
    <i>p</i><i id="yellow">.none</i>{borde-style : none}
    <i>p</i><i id="yellow">.hidden</i>{borde-style : hidden}
    <i>p</i><i id="yellow">.dotted</i>{borde-style : dotted}
    <i>p</i><i id="yellow">.dashed</i>{borde-style : dashed}
    <i>p</i><i id="yellow">.solid</i>{borde-style : solid }
    <i>p</i><i id="yellow">.double</i>{borde-style : double}
    <i>p</i><i id="yellow">.groove</i>{borde-style : groove}
    <i>p</i><i id="yellow">.inset</i>{borde-style : inset}
    <i>p</i><i id="yellow">.outset</i>{borde-style : outset}
      <!-- <i>body</i>
    {
        background-color:black;
    } -->

</pre>

<h3>Border Width</h3>
             
             <p style="text-align: justify; margin-right: 20px;">
             We can specify the widths of an
element's borders using the
border-width CSS property.
Valid Values:
                 <ul>
                     <li>thin: displays a thin border</li>
                     <li>medium: displays a medium border</li>
                     <li>thick: displays a thick border</li>
                 </ul>
                 </p>
 <!--FIRST TOPIC END-->
 



    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END THIRD LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="border color(4).php"><button id="next">Next&#187;</button></a>
            <a href="css inserting(2).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "Displays a series of rounded dots border what will be used",
            a: [{ text: "hidden", isCorrect: false },
            { text: ".dashed", isCorrect: false },
            { text: "dotted", isCorrect: true },
            { text: "groove", isCorrect: false }
            ]

        },
        {
            q: "Displays a single, straight, solid line of Border",
            a: [{ text: "dotted", isCorrect: false, isSelected: false },
            { text: "dashed", isCorrect: false },
            { text: "rounded", isCorrect: false },
            { text: "solid", isCorrect: true }
            ]

        },
        {
            q: "Displays a thin border",
            a: [{ text: "thines", isCorrect: false },
            { text: "thikness", isCorrect: false },
            { text: "thin", isCorrect: true },
            { text: "hard", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>