<?php
include('css_header.php');
?>
    <title>CSS Text Decoration</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">CSS Text Decoration</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->


            <h3>CSS Text Decoration</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The text-decoration CSS property sets
the text decoration line, color and style.
The text-decoration Css property is
actually a shorthand for
text-decoration-line,
text-decoration-style and
text-decoration-color properties.
<br>
<b>Note!</b> The
text-decoration-line
property is required.
text-decoration-line Valid Values:

                <ul>
                    <li>none: provides no decorative Line</li>
                    <li>underline: provides a decorative line beneath a text</li>
                    <li>Overline: provides a decorative line above a text</li>
                    <li>line-through: provides a decorative line going through the middle of a text</li>
                </ul>
                </p>
<!--FIRST TOPIC END-->
<h3>text-decoration-style Valid Values:</h3>
            <p style="text-align: justify; margin-right: 20px;">

                <ul>
                    <li>solid: draws a solid line</li>
                    <li>dotted : draws a dotted line</li>
                    <li>dashed: draws a dashed line</li>
                    <li>double: draws a double line</li>
                    <li>wavy: draws a wavy line</li>
                </ul>
                </p>


<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        text-decoration: overline;
    }
    <i>#p2</i>
    {
        text-decoration: line-through;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i>id=p1</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="text-decoration: overline;"> i am peragraph </p>
    <p style="text-decoration: line-through;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

 



    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SIXTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="css shadow(7).php"><button id="next">Next&#187;</button></a>
            <a href="css text(5).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    
    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>