<?php
include('css_header.php');
?>
    <title>CSS Text</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">CSS Text</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->


            <h3>CSS Text</h3>
            <p style="text-align: justify; margin-right: 20px;">
            CSS provides a lot of ways to
format text including changing color,
indentation, adding text-decoration and
a lot more.
CSS Text Color
The color CSS property sets the color
of a text.
Valid Values:
&lt;color>
                <ul>
                    <li>#p1 { color: red; }</li>
                    <li>#p2 { color: rgb (23, 52, 89); }</li>
                </ul>
                </p>
<!--FIRST TOPIC END-->
<h3>CSS Text Align</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The text-align CSS property sets the
horizontal alignment of a text.
Valid Values:

                <ul>
                    <li>left: aligns text to the left edge</li>
                    <li>center: aligns text to the center</li>
                    <li>right: aligns text to the right edge</li>
                    <li>justify: aligns text its left and right edges to the left and right edges of the line box except for the last line</li>
                </ul>
                </p>


                <h3>CSS Text Transform</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The text-transform CSS property sets
the capitalization of the text.
Valid Values:

                <ul>
                    <li>none: prevents the case of the text from being changed letter of each word to</li>
                    <li>capitalize: converts the first uppercase; other characters are unchanged</li>
                    <li>uppercase: converts a text to uppercase</li>
                    <li>lowercase: converts a text to lowercase</li>
                </ul>
                </p>

                <h3>Example</h3>
<pre id="precode">
    
    <i>#p1</i>
    {
        text-transform : none;
    }
    <i>#p2</i>
    {
        text-transform : capitalize;
    }
</pre>


<h3>CSS Text Indent</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The text-indent CSS property sets the
length of the indentation of a text.
Valid Values:
&lt;length>
&lt;percentage>
                </p>

<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>#p1</i>
    {
        text-indent: 15px;
    }
    <i>#p2</i>
    {
        text-indent: 25%;
    }
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i>id=p1</i>></i>i am peragraph <i>&lt;/p></i>
    <i>&lt;p <i>id=p2</i>></i>i am peragraph <i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>

    <p style="text-indent:15px;"> i am peragraph </p>
    <p style="text-indent:25%;"> i am peragraph </p>

</p>
        </div>
        </div> 
<!-- example end -->

 



    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIFTH LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="css decoration(6).php"><button id="next">Next&#187;</button></a>
            <a href="border color(4).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "The color CSS property sets the color of a",
            a: [{ text: "image", isCorrect: false },
            { text: "background", isCorrect: false },
            { text: "text", isCorrect: true },
            { text: "None", isCorrect: false }
            ]

        },
        {
            q: "The text-align CSS property sets the horizontal alignment of a",
            a: [{ text: "background", isCorrect: false, isSelected: false },
            { text: "div", isCorrect: false },
            { text: "image", isCorrect: false },
            { text: "text", isCorrect: true }
            ]

        },
        {
            q: "The text-transform CSS property sets the capitalization of the",
            a: [{ text: "links", isCorrect: false },
            { text: "images", isCorrect: false },
            { text: "text", isCorrect: true },
            { text: "peragraph", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>