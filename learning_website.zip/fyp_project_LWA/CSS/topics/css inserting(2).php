<?php
include('css_header.php');
?>
    <title>Inserting CSS</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">CSS Inserting</h2>
            <!-- for languages -->
            <div id="google_element" class="mx-1"></div>
            <!-- for languages end -->
            <h3>CSS Inserting</h3>
             
            <p style="text-align: justify; margin-right: 20px;">
            There are three simple ways to insert CSS into an HTML document.

                <ul>
                    <li>Internal Style Sheet</li>
                    <li>External Style Sheet</li>
                    <li>Inline Styling</li>
                </ul>
                </p>

            <h3>Internal Style Sheet</h3>
            <p style="text-align: justify; margin-right: 20px;">
            An internal style sheet is useful when
a single HTML document has its unique
styles.
With this, CSS rulesets/rules should be
included in the &lt;style> element.
The &lt;style> element should only be
enclosed inside the &lt;head> element.
For following best practices we can use
the type attribute to define the MIME
type of the &lt;style> tag.
The text/css value indicates that the
Content is CSS.
 
            </p>
<!--FIRST TOPIC END-->



<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>p</i>
    {
        color:red;

    }
      <!-- <i>body</i>
    {
        background-color:black;
    } -->
    <i style="color:yellow;" id="yellow">&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p></i>I am peragraph<i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
    <p style="color:red;">I am peragraph</p>
        </div>
        </div> 
<!-- example end -->


<h3>External Style Sheet</h3>
            <p style="text-align: justify; margin-right: 20px;">
            An external style sheet can be very
useful when multiple HTML pages have
the same styles.
This can be achieved by having an
external style sheet file.
An external style sheet file must be
saved with a .css extension e.g.
filename.css.
Then we need to use the &lt;link>
element to include the file in our HTML
page.
There should be no &lt;style> element
inside a CSS file!

Content is CSS.
 
            </p>
<!--FIRST TOPIC END-->



<!-- Example start -->
<h3>Example</h3>
<p>The style.css file contains the following codes.
</p>
<pre id="precode">
    <i style="color:yellow" id="yellow">&lt;style></i>
    <i>p</i>
    {
        color:white;
        background-color:brown;

    }
      <!-- <i>body</i>
    {
        background-color:black;
    } -->
    <i style="color:yellow;" id="yellow">&lt;/style></i>

</pre>
<!-- example end -->
<p>Now that we have our external style
sheet file. The next step is to include it
in our HTML page.
We can simply do it by defining its file
path using the &lt;link> element with its
href attribute.
Learn more about HTML File Paths on
Our Learn HTML Toturial.
&lt;/p>

<!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
    <i>&lt;link <strong>rel = <i>"stylesheet"</i></strong> <strong>href = <i>"style.css"</i></strong>></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p></i>I am peragraph<i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
    <p style="color:white; background-color:brown;">I am peragraph</p>
        </div>
        </div> 
<!-- example end -->
 <p>In the example shown above, the
style.css file and the HTML file are
saved in the app's directory.
You can try it in your storage as well.
Just follow these steps.
<br>
1) Create a folder in your root
directory.
<br>
2) Save the HTML file in that
folder.
<br>
3) Save the style. css file in that
folder.
<br>
4) Run/Open the HTML file using
any browser.
</p>


<h3>Inline Styling</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Inline styling is useful for styling a
single element.
It is done by using the style attribute.
Its value contains CSS declarations.
 
            </p>

            <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i style="color: yellow;">&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> title <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <i>style = <i id="yellow">color:red; font-size:25px; background-color:yellow;"</i></i>></i>I am peragraph<i>&lt;/p></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>


        <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
    <p style="color:red; font-size:25px; background-color:yellow;">I am peragraph</p>
        </div>
        </div> 
<!-- example end -->
<!--Second TOPIC START-->

<!--Second TOPIC END-->




    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SECOND LECTURE</h4>
        <br>
        <div class="next/previous">
            <a href="css border(3).php"><button id="next">Next&#187;</button></a>
            <a href="Introduction of css(1).php"><button id="previous">&laquo;Previous</button></a>
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
     <!-- Quiz Section -->
    
     <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "How many ways to insert CSS into an HTML document",
            a: [{ text: "2", isCorrect: false },
            { text: "1", isCorrect: false },
            { text: "3", isCorrect: true },
            { text: "4", isCorrect: false }
            ]

        },
        {
            q: "In Internal Stylesheet where <style> element should only be enclosed",
            a: [{ text: "<body>", isCorrect: false, isSelected: false },
            { text: "<script>", isCorrect: false },
            { text: "All", isCorrect: false },
            { text: "<head>", isCorrect: true }
            ]

        },
        {
            q: "What element will be used to include external stylesheet in html document.",
            a: [{ text: "<style>", isCorrect: false },
            { text: "<script>", isCorrect: false },
            { text: "<link>", isCorrect: true },
            { text: "None", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>