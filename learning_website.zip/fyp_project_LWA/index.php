<?php
include('config/connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Let's Learn Programming</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/back.jpg" rel="icon">
  <link href="assets/img/apple-touch-icon.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link rel="stylesheet" href="assets/css/style.css">

  <style>
    #php2{
            color:white;
            border:1px solid white; 
            border-radius:5px;
            background-color:red;
            height: 50px;
            font-size:32px;
    }
    #php{
            color:white;
            font-weight:250;
            border:2px solid white; 
            border-radius:10px;
            padding:5px 5px 5px 5px;
            background-color:black;
            height: 50px;
            font-size:32px;
        }
        #resize
        {
          text-align:justify;
          font-size:18px;
        }
  </style>
</head>

<body>



  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">
      

      <!-- <h1 class="logo me-auto"><a href="index.html">D&Y</a></h1> -->

      <!-- Uncomment below if you prefer to use an image logo -->
      <a href="\fyp_project_LWA\assets\img\back.jpg" class="logo me-auto"><img src="\fyp_project_LWA\assets\img\back.jpg" alt="" class="rounded-circle img-fluid"></a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto" href="#supervisor">Supervisor</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          <li><a class="nav-link scrollto" href="http://localhost/fyp_project_LWA/USERS/discussion_form.php">Discussion Form</a></li>
          <li><a class="nav-link scrollto" href="http://localhost/Fyp_project_LWA/PDF_BOOKS/pdf_material2.php">Pdf Materials</a></li>
          <li><a class="nav-link scrollto" href="http://localhost/fyp_project_LWA/USERS/feedback_form.php">Feedback</a></li>
          
            <!-- for multiple languages -->

    

<!-- end -->
          <!--Drop Down start-->


          <li class="dropdown"><a href="#"><span>Languages</span> <i class="bi bi-chevron-down"></i></a>
          <ul>
           
            </li>
            <li><a href="HTML/index.php">HTML</a></li>
            <li><a href="CSS/index.php">CSS</a></li>
            <li><a href="C++/index.php">C++</a></li>
            <li><a href="JAVASCRIPT/index.php">JavaScript</a></li>
            <li><a href="PYTHON/index.php">PYTHON</a></li>
            <li><a href="PHP/index.php">PHP</a></li>
          </ul>
        </li>

          <!--Drop Down End-->
          <li><a class="getstarted scrollto" href="http://localhost/fyp_project_LWA/LOGIN/login2.php">Login</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->
      
      <!-- for languages -->

      <div id="google_element" class="mx-1"></div>

      <!-- for languages end -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>Better Solutions For Your Learning Experiences</h1>
          <h2>We are always here to serve you 24/7</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="http://localhost/fyp_project_LWA/HTML/index.php" class="btn-get-started scrollto">Get Started</a>
            
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="\fyp_project_LWA\assets\img\logo.png" class="img-fluid animated" alt="">
          <!-- its own pic is hero-img -->
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

  

     <!-- ======= About Us Section ======= -->
     <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>LLP (Let's Learn Programming)</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
            Here is a detailed explanation of the website, Let's Learn Programming:
            </p>
            
            <ul>
            <li><i class=""></i><h3>Introuduction</h3></li>
              <li><i class="ri-check-double-line"></i> Let's Learn Programming is an online learning platform that provides comprehensive resources and materials for learning various programming languages. Our mission is to help individuals learn programming concepts and skills, and become proficient in their chosen programming language.</li>
              <li><i class="ri-check-double-line"></i> Many people, in the current era, are experiencing poverty. They do not have enough money to enroll in a software house or academy for learning computer languages.  </li>
              <li><i class="ri-check-double-line"></i> Our goal is to create a web application where people will easily learn any computer languages.</li>
              <li><i class="ri-check-double-line"></i> Users will easily download and learn from these materials offline, even if they don't have an internet connection. </li>
              <li><i class="ri-check-double-line"></i> There are some backward areas where the facility of software house is not available our LLP system will resolve this problem by bringing the facility at the doorsteps of such deprived areas. </li>
              
            </ul>

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
            <p>
            We offer resources and materials for the following programming languages:
            </p>
          <ul>
              <li><i class=""></i><h3>Programming Languages</h3></li>
              <li><i class="ri-check-double-line"></i> <b>HTML: </b> HTML (Hypertext Markup Language) is the standard markup language used to create web pages. It is the backbone of a website, providing the structure and content that the web browser renders to the user.</li>
              <li><i class="ri-check-double-line"></i> <b>CSS: </b> Cascading style sheet used to design HTML pages. </li>
              <li><i class="ri-check-double-line"></i> <b>JavaScript: </b> Created by Brendan Eich in 1995 while working at Netscape Communications </li>
              <li><i class="ri-check-double-line"></i> <b>PHP: </b> Created by Rasmus Lerdorf in 1994
                                                                    Initially called "Personal Home Page Tools"
                                                                  </li>
              <li><i class="ri-check-double-line"></i> <b>Python: </b> Python is a high-level, interpreted programming language that is widely used for various purposes such as web development, scientific computing, data analysis, artificial intelligence, and more.  </li>
              <li><i class="ri-check-double-line"></i> <b>C++: </b> C++ is a high-performance, compiled, general-purpose programming language.
 That was developed by Bjarne Stroustrup as an extension of the C programming language. 
</li>
            </ul>
            <p>
            Each language has its own dedicated section, where you'll find:
            </p>
<!-- Modal Start -->
<button class="btn-learn-more btn-sm" data-toggle="modal" data-target="#mymodal">
Read More
</button>
<div class="modal fade modal-lg" id="mymodal" data-backdrop="static">
<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
<div class="modal-content">
    <div class="modal-header">
        <h2 class="modal-title">
            LLP (Let's Learn Programming)
        </h2>
        <button class="close btn btn-white text-danger" data-dismiss="modal">
          X
        </button>
    </div>
    <div class="modal-body">
        <div class="card">
          <img src="\fyp_project_LWA\assets\img\back.jpg" class="card-img-top img-fluid" alt="">
          <div class="card-body">
            <h1 class="card-title">
            Tutorials and Examples
            </h1>
            <p class="card-text">
            Tutorials and examples to help you get started
          </p>

          <p class="card-text">
          Reference materials and documentation
          </p>

          <p class="card-text">
          Quizzes and assessments to test your knowledge
          </p>

          <p class="card-text">
          PDF materials for offline learning
          </p>

          <p class="card-text">
          Search functionality to find specific topics and concepts
          </p>

          <p class="card-text">
          Our tutorials and examples are designed to help you learn by doing. We'll guide you through the process of building real-world projects, from simple web pages to complex applications.
          Our examples are fully annotated, so you can understand the code and how it works.
          </p>

            <p class="card-text">
            <h3>Reference Materials and Documentation: </h3>
            Our reference materials and documentation are designed to be a comprehensive resource for developers. We've gathered together the most useful information and resources, so you can quickly find what you need.
          </p>

            <p class="card-text">
            <h3>Quizzes and Assessments: </h3>
            Our quizzes and assessments are designed to test your knowledge and understanding of programming concepts. We'll help you identify areas where you need to focus your learning, and provide feedback and guidance to help you improve.
          </p>

            <p class="card text">
                <h3>PDF Materials</h3>
                We offer PDF materials for offline learning, so you can take your learning with you wherever you go. Our PDF materials are designed to be comprehensive and easy to follow, and include examples, tutorials, and reference materials.
              </p>


              <p class="card text">
                <h3>Search Functionality</h3>
                Our search functionality allows you to quickly find specific topics and concepts, so you can get the help you need when you need it. We've indexed our entire library of resources, so you can search by keyword, topic, or concept.
              </p>

              <p class="card text">
                <h3>Community and Support: </h3>
                At Let's Learn Programming, we believe that learning is a community effort. That's why we've created a range of resources to help you connect with other developers and get the support you need. Join our forums, chat with other developers, and get help when you need it.
              </p>

              <p class="card text">
                <h3>What You Can Expect:</h3>
                By using Let's Learn Programming, you can expect to:
                <ul>
                  <li><i class="ri-check-double-line"></i>Learn new programming skills and technologies</li>
                  <li><i class="ri-check-double-line"></i>Improve your coding abilities and knowledge</li>
                  <li><i class="ri-check-double-line"></i>Connect with other developers and get support</li>
                  <li><i class="ri-check-double-line"></i>Find reference materials and documentation</li>
                  <li><i class="ri-check-double-line"></i>Build real-world projects and applications</li>
                  <li><i class="ri-check-double-line"></i>Get feedback and guidance to help you improve</li>
                </ul>
              </p>

              
              <p class="card text">
                <h3>Conclusion: </h3>
                I hope this detailed explanation helps! Let me know if you have any further questions or need more information.
              </p>

              

          </div>
        </div>
    
    <div class="modal-footer">
        <button class="btn btn-danger" class="close" data-dismiss="modal">
            close
        </button>
    </div>
</div>

</div>


            <!-- Modal End -->
          </div>
        </div>

      </div>
    </section>
    <!-- End About Us Section -->


    <!-- ======= Skills Section ======= -->
    <section id="skills" class="skills">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Languages</h2>
        </div>
        <div class="row">
          <div class="col-lg-6 d-flex align-items-center" data-aos="fade-right" data-aos-delay="100">
            <img src="assets/img/skills.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 pt-4 pt-lg-0 content" data-aos="fade-left" data-aos-delay="100">
            <h3>We provide many programming language in one platform</h3>
            <p class="fst-italic">
              You can learn many computer language correct
            </p>

            <div class="skills-content">

              <div class="progress">
                <span class="skill">HTML <i class="val"></i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill">CSS <i class="val"></i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill">JavaScript <i class="val"></i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill">PHP <i class="val"></i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill">PYTHON <i class="val"></i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

              <div class="progress">
                <span class="skill">C++ <i class="val"></i></span>
                <div class="progress-bar-wrap">
                  <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
              </div>

            </div>

          </div>
        </div>

      </div>
    </section><!-- End Skills Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
          <p class="lead">We are providing many computer programming languages like C++, JavaScript, Python, PHP, HTML, CSS and include other languages with the pessage of time.</p>
        </div>

        <div class="row">
          <div class="col-xl-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4><a href="C++/index.php">C++</a></h4>
              <p id="resize">C++ is a popular programming language.
C++ is used to create computer programs, and is one of the most used language in game development.</p>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="JAVASCRIPT/index.php">JS</a></h4>
              <p id="resize">JavaScript is the world's most popular programming language. JavaScript is the programming language of the web.
                JavaScript is easy to learn.
              </p>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="PHP/index.php">PHP</a></h4>
              <p id="resize">PHP is a server side scripting language.
PHP is an interpreted language, i.e. there is no need for compilation.
PHP is an object-oriented language.
PHP is an open-source scripting language.
PHP is simple and easy to learn language.</p>
            </div>
          </div>
<br>
<br>
          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4 mt-xl-4" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="PYTHON/index.php">PYTHON</a></h4>
              <p id="resize">Python is a programming language. Python is one of the most popular programming language.</p>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4 mt-xl-4" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="HTML/index.php">HTML</a></h4>
              <p id="resize">HTML stands for Hyper Text Markup Language, it is easy and fun to learn. HTML describes the structure of web pages.
                 HTML5 is the fifth and current major version of the HTML standard.</p>
            </div>
          </div>

          <div class="col-xl-4 col-md-6 d-flex align-items-stretch mt-4 mt-xl-4" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="CSS/index.php">CSS</a></h4>
              <p id="resize">CSS is a Cascading Style Programming Language CSS is a Cascading Style Programming Language</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

 

  <!-- ======= Supervisor Section ======= -->
  <section id="supervisor" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Supervisor</h2>
          <p style="text-align:justify;" id="resize">
          <b> Dr. Burhan Ullah</b> <br>

<b> Acknowledgement:</b>
We would like to express our deepest gratitude to our honorable supervisor, <b>Dr. Burhan Ullah</b>, the Head of Department for BS Computer Science, for his invaluable guidance and support throughout the development of this project.
<br>
<b>Dr. Burhan Ullah's</b> expertise and encouragement played a crucial role in helping us to complete this lengthy but fruitful academic task. 
We are truly grateful for his unwavering commitment and dedication to our project-related and academic growth
 <br>
 <br>

          </p>
        </div>

        <div class="row">
          <div class="col-lg-12" data-aos="zoom-in" data-aos-delay="100">
            <div class="member d-flex align-items-start">
              <a href="assets/img/team/supervisor3.jpg" class="logo me-auto pic"><img src="assets/img/team/supervisor3.jpg" alt="" class="rounded-circle img-fluid"></a>

              <div class="member-info">
                <h4>Dr. Burhan Ullah</h4>
                <span id="resize">Supervisor</span>
                <p id="resize"> Special thanks to our project supervisor, Dr Burhan Ullah, and coordinator, for their indispensable guidance and support. Their expertise paved the way for the successful completion of our project. </p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          
        </div>

      </div>
    </section>
    <!-- End Supervisor Section -->


    <!-- ======= Team Section ======= -->
    <section id="team" class="team section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Team</h2>
          <p style="text-align:justify;">
          <b> M.Dawood Khan Programmer</b> <br>

<b> Bio:</b> Dawood is a skilled programmer with a passion for coding. He has extensive experience in web development and is proficient in a range of programming languages. He is dedicated to delivering high-quality code and is always looking for ways to improve his skills.
 <br>
<b> Goals:</b> To continue learning and growing as a programmer, to contribute to innovative projects, and to help others learn programming skills.
 <br><span class="text-danger">Fun fact:</span> <br> <b>Dawood</b> is a self-taught programmer and loves solving complex coding challenges in his free time.
 <br>
 <br>
 <b> Yasir Rehman Helper</b> <br>

<b> Bio:</b> Yasir is a helpful and detail-oriented individual who assists Dawood with programming tasks. He has a strong understanding of technical concepts and is skilled at researching and troubleshooting issues.
<br>
<b> Goals:</b> To continue learning and growing in his role, to provide excellent support to Dawood and the team, and to contribute to the success of projects.
 <br><span class="text-danger">Fun fact:</span> <br> <b>Yasir</b> is a quick learner and enjoys helping others understand complex technical concepts in simple terms.


          </p>
        </div>

        <div class="row">

          <div class="col-lg-6" data-aos="zoom-in" data-aos-delay="100">
            <div class="member d-flex align-items-start">
              <!-- <div class="pic"><img src="assets/img/team/team-201.jpg" class="img-fluid" alt=""></div> -->
              <a href="assets/img/team/team-201.jpg" class="logo me-auto pic"><img src="assets/img/team/team-201.jpg" alt="" class="rounded-circle img-fluid"></a>

              <div class="member-info">
                <h4>M.Dawood Khan</h4>
                <span id="resize">Programmer</span>
                <p id="resize">My Name is Dawood and i am the programmer of the project</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 mt-md-3 mt-xl-0" data-aos="zoom-in" data-aos-delay="100">
            <div class="member d-flex align-items-start">
              <!-- <div class="pic"><img src="assets/img/team/team-201.jpg" class="img-fluid" alt=""></div> -->
              <a href="assets/img/team/team-226.jpg" class="logo me-auto pic"><img src="assets/img/team/team-226.jpg" alt="" class="rounded-circle img-fluid"></a>

              <div class="member-info">
                <h4>Yasir Rehman</h4>
                <span id="resize">Helper</span>
                <p id="resize">It's Yasir Rehman my helper in the project thanks to Yasir</p>
                <div class="social">
                  <a href=""><i class="ri-twitter-fill"></i></a>
                  <a href=""><i class="ri-facebook-fill"></i></a>
                  <a href=""><i class="ri-instagram-fill"></i></a>
                  <a href=""> <i class="ri-linkedin-box-fill"></i> </a>
                </div>
              </div>
            </div>
          </div>


          
        </div>

      </div>
    </section><!-- End Team Section -->
    
    </section>

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contact</h2>
          <p id="resize" class="text-center">Every can contact us through the contact page just fill the form and contact with us we are always to serve you Thanks</p>
        </div>

        <div class="row">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Location:</h4>
                <p>Bannu, Pakistan</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>dawood1542@gmail.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Call:</h4>
                <p>+923325700407</p>
              </div>

            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form action="#contact" method="POST" >  
              <!-- class="php-email-form" -->
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Your Name</label>
                  <input type="text" pattern="[A-Za-z ]+" title="Only letters and spaces are allowed" name="name" class="form-control" id="name" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Your Email</label>
                  <input type="email" class="form-control" pattern="[a-zA-z0-9]+@+gmail.com" title="Abc123@gmail.com" name="email" id="email" required>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" name="subject" id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="message" rows="10" required></textarea>
              </div>
              <div class="my-3">
                <!-- <div class="loading">Loading</div> -->
                <!-- <div class="error-message"></div> -->
                <div class="sent-message"> 
                  
      <!-- php start-->
              <?php
if(isset($_POST['submit'])){
    $fullname=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];
    $send=mysqli_query($con,"INSERT INTO `contact`(`full_name`, `email`, `subject`, `message`) VALUES ('$fullname','$email','$subject','$message');");
    if($send)
    {
       echo '<div class="col-12">
       <div class="alert alert-danger bg-success text-white">
           <p>Contact SuccessFully Done</p>
           <button class="close btn btn-success active" data-dismiss="alert"  style="margin-right:auto;">
               X
           </button>
       </div>';
    }
    else
    {
        echo '<div class="col-12">
       <div class="alert alert-danger bg-danger text-white">
           <p>Failed Please Try Again</p>
           <button class="close btn btn-danger active" data-dismiss="alert"  style="margin-right:auto;">
               X
           </button>
       </div>';
    }
}
?>
              <!-- php end -->
            </div> 
              </div>
              <div class="text-center"><button type="submit" class="btn btn-warning" name="submit">Send Message</button></div>
             



            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <hr>
    </div>

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Dawood & Yasir</h3>
            <p>
              Bannu <br>
              Pakistan,<br>
               <br>
              <strong>Phone:</strong> +923325700407<br>
              <strong>Email:</strong> dawood1542@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#contact">Contact</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#supervisor">Supervisor</a></li>

              <li><i class="bx bx-chevron-right"></i> <a href="#about">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#team">Team</a></li>
            </ul>
          </div>

          

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Social Networks</h4>
            <p>Everyone can contact us through Social Network and we are always here to serve you Thanks</p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

    <div class="container footer-bottom clearfix">
      <div class="copyright">
        &copy; Copyright <strong><span>D&Y</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        
        Designed by <a href="#team">DAWOOD & YASIR</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/js/jquery.slim.js"></script>
  <script src="assets/js/bootstrap.js"></script>
  <script src="assets/js/popper.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

<!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>

</html>