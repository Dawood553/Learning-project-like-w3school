<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Download PDF</title>
     <!-- Favicons -->
     <link href="/fyp_project_LWA/assets/img/back.jpg" rel="icon">
  <link rel="stylesheet" href="/fyp_project_LWA/assets/css/style.css">
  <link href="/fyp_project_LWA/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.css">
    <link rel="stylesheet" href="bootstrap.css">
</head>
<body>
    <div class="container-fluid bg-light">
        
        <h1 class="text-center text-secondary text-uppercase" style="text-shadow:12px 10px 15px; font-weight:1000;">You Can Download Pdf Notes From Here</h1>
        <a href="http://localhost/fyp_project_LWA/index.php" class="btn btn-success" style="font-size:25px; width:5%;">&laquo;</a>
        <div class="row mt-5">
       
            <div class="col-md-4 mb-5">
                <div class="card shadow-lg">
                    <!-- <img src="\fyp_project_LWA\assets\img\php.jpg" class="img-fluid card-img-top" style="height: 200px;" alt=""> -->
                     <video src="\fyp_project_LWA\assets\img\videos\php.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>
                    <div class="card-body">
                        <h2 class="card-title">PHP</h2>
                        <p class="card-text">
                        PHP is a server side scripting language.
PHP is an interpreted language, i.e. there is no need for compilation.
PHP is an object-oriented language.
PHP is an open-source scripting language.
PHP is simple and easy to learn language.
                        </p>
                        <a href="Php.pdf" class="btn btn-primary btn-lg" style="float: right;"><i class="fa fa-download"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-5">
                <div class="card shadow-lg">
                    <!-- <img src="\fyp_project_LWA\assets\img\html.jpg" class="img-fluid card-img-top" style="height: 200px;" alt=""> -->
                    <video src="\fyp_project_LWA\assets\img\videos\html.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>


                    <div class="card-body">
                        <h2 class="card-title">HTML</h2>
                        <p class="card-text">
                        HTML stands for Hyper Text Markup Language, it is easy and fun to learn. HTML describes the structure of web pages.
                        HTML5 is the fifth and current major version of the HTML standard.
                        <br>
                         <br>
                        </p>
                        <a href="html complete.pdf" class="btn btn-primary btn-lg" style="float: right;"><i class="fa fa-download"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-5">
                <div class="card shadow-lg">
                    <!-- <img src="\fyp_project_LWA\assets\img\python.jpg" class="img-fluid card-img-top" style="height: 200px;" alt=""> -->
                    <video src="\fyp_project_LWA\assets\img\videos\python.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>


                    <div class="card-body">
                        <h2 class="card-title">Python</h2>
                        <p class="card-text">
                        Python is a programming language. Python is one of the most popular programming language.
                        <br>
                        <br>
                        <br>
                        <br>
                        </p>
                        <a href="python complete.pdf" class="btn btn-primary btn-lg" style="float: right;"><i class="fa fa-download"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-5">
                <div class="card shadow-lg">
                    <!-- <img src="\fyp_project_LWA\assets\img\c++.jpg" class="img-fluid card-img-top" style="height: 200px;" alt=""> -->
                    <video src="\fyp_project_LWA\assets\img\videos\c++.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>


                    <div class="card-body">
                        <h2 class="card-title">C++</h2>
                        <p class="card-text">
                        C++ is a popular programming language.
                        C++ is used to create computer programs, and is one of the most used language in game development.
                        </p>
                        <a href="C++ complete.pdf" class="btn btn-primary btn-lg" style="float: right;"><i class="fa fa-download"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-5">
                <div class="card shadow-lg">
                    <!-- <img src="\fyp_project_LWA\assets\img\js.jpg" class="img-fluid card-img-top" style="height: 200px;" alt=""> -->
                    <video src="\fyp_project_LWA\assets\img\videos\js.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>


                    <div class="card-body">
                        <h2 class="card-title">JavaScript</h2>
                        <p class="card-text">
                        JavaScript is the world's most popular programming language. JavaScript is the programming language of the web.
                        JavaScript is easy to learn.
                        </p>
                        <a href="js complete.pdf" class="btn btn-primary btn-lg" style="float: right;"><i class="fa fa-download"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-5">
                <div class="card shadow-lg">
                    <!-- <img src="\fyp_project_LWA\assets\img\css.jpg" class="img-fluid card-img-top" style="height: 200px;" alt=""> -->
                    <video src="\fyp_project_LWA\assets\img\videos\css.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>


                    <div class="card-body">
                        <h2 class="card-title">CSS</h2>
                        <p class="card-text">
                        CSS is a Cascading Style Programming Language CSS is a Cascading Style Programming Language
                        <br>
                        <br>
                        </p>
                        <a href="css notes.pdf" class="btn btn-primary btn-lg" style="float: right;"><i class="fa fa-download"></i></a>
                    </div>
                </div>
            </div>

            


        </div>
    </div>
    <!-- ======= Footer ======= -->
  <footer id="footer">

<hr>
</div>

<div class="footer-top">
  <div class="container">
    <div class="row">

      <div class="col-lg-3 col-md-6 footer-contact">
        <h3>Dawood & Yasir</h3>
        <p>
          Bannu <br>
          Pakistan,<br>
           <br>
          <strong>Phone:</strong> +923325700407<br>
          <strong>Email:</strong> dawood1542@gmail.com<br>
        </p>
      </div>

      <div class="col-lg-6 col-md-6 footer-links">
        <h4>Our Social Networks</h4>
        <p>Everyone can contact us through Social Network and we are always here to serve you Thanks</p>
        <div class="social-links mt-3">
          <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
          <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
          <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
          <a href="#" class="google-plus"><i class="fa fa-skype"></i></a>
          <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
        </div>
      </div>

    </div>
  </div>
</div>

<div class="container footer-bottom clearfix">
  <div class="copyright">
    &copy; Copyright <strong><span>D&Y</span></strong>. All Rights Reserved
  </div>
  <div class="credits">
    <!-- All the links in the footer should remain intact. -->
    <!-- You can delete the links only if you purchased the pro version. -->
    <!-- Licensing information: https://bootstrapmade.com/license/ -->
    <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/arsha-free-bootstrap-html-template-corporate/ -->
    Designed by <a href="#team" class="text-reset">DAWOOD & YASIR</a>
  </div>
</div>
</footer><!-- End Footer -->
</body>
</html>