<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="title.jpg">
    <!-- <link rel="stylesheet" href="bootstrap.min.css"> -->
    <!-- <link rel="stylesheet" href="\fyp_project_LWA\config\JS-topic_style.css"> -->
    <!-- <link rel="stylesheet" href="JS-topic_style.css"> -->
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="quiz.css">
<style>


</style>
</head>
<body>
    <!--SIDE MENU BAAR CODING START -->
    <div id="sideNav">
        <br>
        <br>
        <a href="http://localhost/fyp_project_LWA/JAVASCRIPT/index.php">Home</a>
        <a href="Try it yourself.php">Code Area</a>
        <input id="searchbar" onkeyup="search_subject()" type="text" name="search" placeholder="Search Lecture..">
        <hr> 
        <ol id="list" style="list-style: none;">            
        <h2 style="color: white;text-align: center;">Lectures</h2>    
        <li><a href="introduction of js (1).php" class="subject">Introdution of JS</a></li>
        <li><a href="js display output (2).php" class="subject">JavaScript Output</a></li>
        <li><a href="js statements (3).php" class="subject">JavaScript Statements</a></li>
        <li><a href="js syntax (4).php" class="subject">JavaScript Syntax</a></li>
        <li><a href="js comments (5).php" class="subject">JavaScript Comments</a></li>
        <li><a href="js variable (6).php" class="subject">JavaScript Variables</a></li>
        <li><a href="js datatypes (7).php" class="subject">JavaScript Data Types</a></li>
        <li><a href="js number (8).php" class="subject">JavaScript Number</a></li>
        <li><a href="js boolean (9).php" class="subject">JavaScript Boolean</a></li>
        <li><a href="js object (10).php" class="subject">JavaScript object</a></li>
        
    </div>
    <!-- code for search button  -->
    <script>
        function search_subject() { 
            let input = document.getElementById('searchbar').value 
            input=input.toLowerCase(); 
            let x = document.getElementsByClassName('subject'); 
        for (i = 0; i < x.length; i++) {  
                if (!x[i].innerHTML.toLowerCase().includes(input)) { 
                    x[i].style.display="none"; 
          }
                else { 
                    x[i].style.display="list-item";                  
                } 
        }
        }
        </script>

<!-- code for search button end -->
    <div id="manuBtn">
        <!--<img src="menu.png" id="menu">-->
        <p style="color:white;" id="topics">TOPICS</p>            
    </div>

<script>
        var manuBtn = document.getElementById("manuBtn")
        var sideNav = document.getElementById("sideNav")
        var menus = document.getElementById("menu")           
        sideNav.style.right = "-500px";
        manuBtn.onclick = function()
          {
            if(sideNav.style.right == "-500px"){
                sideNav.style.right ="0"
                
                menu.src = "close.jpg";                  
            }
            else{
                sideNav.style.right ="-500px"
                menu.src = "close.jpg";
            }
        }
    </script>
    <!--SIDE MENU BAAR CODING END-->