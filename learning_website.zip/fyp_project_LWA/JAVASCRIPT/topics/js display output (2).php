<?php
include('js_header.php');
?>
<title>JS OutPut</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">JS Displaying Output</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>JavaScript Displaying Output</h3>
            <p style="text-align: justify; margin-right: 20px;">
                Displaying or generating output in JavaScript is very important especially when 
                learning the language. For example, if you want to see if your JavaScript statements
                or code blocks are correct, you can output data to check. In JavaScript, there are 
                <b>3 ways</b> of display output:
                
            </p>

            <h3>Using Dialog Boxes</h3>
            <p style="text-align: justify; margin-right: 20px;">
                By using the <b>alert()</b> function, we can output data on dialog box.
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"sum()" <i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong></strong></i><i>></i><strong id="white">Sum</strong></strong></i><i>&lt;/button></i>
<i>&lt;script></i> 
{
<i>function</i> <strong>sum()</strong>
<i>var</i> x = <i>5</i>;
<i>var</i> y = <i>5</i>;
<i>var</i> sum = <i>x+y</i>; <strong id="pink">//adds x and y</strong>
alert(sum); <strong id="pink">//prints 10</strong>
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <button type="button" onclick="sum()" class="justbutton">sum</button>
                <script>
                    function sum(){
                        var x=5;
                        var y=5;
                        var sum=x+y;
                        alert(sum);
                    }
                </script>
            </p>    
        </div>
        </div> 
<!-- example end  -->
<!--FIRST TOPIC END-->


<!-- Second topic start -->
<h3>Writing to HTML Elements</h3>
            <p style="text-align: justify; margin-right: 20px;">
                By using the <b>innerHTML</b> property, we can change the content or text of the 
                selected element. We can use the <b>document.getElementById()</b> function to 
                select an element.
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>id = </i> <strong>"sum2"</strong>></i> <i>&lt;/p></i>
<i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"sum2()" <i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong></strong></i><i>></i><strong id="white">Write</strong></strong></i><i>&lt;/button></i>
<i>&lt;script></i> 
{
<i>function</i> <strong>sum2()</strong>
<i>var</i> x = <i>5</i>;
<i>var</i> y = <i>5</i>;
<i>var</i> sum = <i>x+y</i>; <strong id="pink">//adds x and y</strong>
<strong>document</strong>.getElementById("<strong>"sum2"</strong>").innerHTML = sum;
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <p id="sum2"></p>
                <button type="button" onclick="sum2()" class="justbutton">Write</button>
                <script>
                    function sum2(){
                        var x=5;
                        var y=5;
                        var sum=x+y;
                        document.getElementById("sum2").innerHTML = sum;
                    }
                </script>
            </p>    
        </div>
        </div> 
<!-- example end  -->
<!--second TOPIC END-->

<!-- Third Topic -->
<h3>Writing to the Browser Window</h3>
            <p style="text-align: justify; margin-right: 20px;">
                By using the <b>document.write()</b> function, we can write to the content of the
                document. <b>Note!</b> This should only be used for testing purpose as it will delete
                all existing HTML in the current page.
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>id = </i> <strong>"sum3"</strong>></i> <i>&lt;/p></i>
<i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"sum3()" <i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong></strong></i><i>></i><strong id="white">Write</strong></strong></i><i>&lt;/button></i>
<i>&lt;script></i> 
{
<i>function</i> <strong>sum3()</strong>
<i>var</i> x = <i>5</i>;
<i>var</i> y = <i>5</i>;
<i>var</i> sum = <i>x+y</i>; <strong id="pink">//adds x and y</strong>
<strong>document</strong>.write(sum);
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <p id="sum3"></p>
                <button type="button" onclick="sum3()" class="justbutton">Write</button>
                <script>
                    function sum3(){
                        var x=5;
                        var y=5;
                        var sum=x+y;
                        document.write(sum);
                    }
                </script>
            </p>    
        </div>
        </div> 
        <!-- Example End -->
        <!-- Third Topic End -->


    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SECOND LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js statements (3).php"><input type="button" id="next" value="Next&#187;" /></a>
            <a href="introduction of js (1).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What is one way JavaScript can display output?",
            a: [{ text: "Using the `console.error()` function", isCorrect: false },
            { text: "Using the `prompt()` function", isCorrect: false },
            { text: "Using the `alert()` function", isCorrect: true },
            { text: "Using the `document.query()` function", isCorrect: false }
            ]

        },
        {
            q: "What JavaScript function is used to write output directly to the HTML document?",
            a: [{ text: "`document.read()`", isCorrect: false, isSelected: false },
            { text: "`document.display()`", isCorrect: false },
            { text: "`document.show()`", isCorrect: false },
            { text: "`document.write()`", isCorrect: true }
            ]

        },
        {
            q: "What property is used to set the content of an HTML element in JavaScript?",
            a: [{ text: "`htmlContent`", isCorrect: false },
            { text: "`outerHTML`", isCorrect: false },
            { text: "`innerHTML`", isCorrect: true },
            { text: "`elementContent`", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>