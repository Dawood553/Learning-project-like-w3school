<?php
include('js_header.php');
?>
<title>JS Statements</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">JS Statements</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>JavaScript Statements</h3>
            <p style="text-align: justify; margin-right: 20px;">
                JavaScript programs consists of Statements with appropriate syntax. A single
                JavaScript Statements may span a single or multiple lines. JavaScript Statements
                should be ended or be separaed by semicolons (<b>;</b>). Below is an example of a 
                single-line Statement. This Statement writes the text <b>"Hello World"</b> to the
                peragraph element with the <b>elem</b> id.
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>id = </i> <strong>"elem"</strong>></i> First Peragraph Element <i>&lt;/p></i>
<i>&lt;script></i> 
{
<strong>document</strong>.getElementById(<strong>"elem"</strong>).innerHTML = <strong>"Hello World"</strong>;
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <p id="elem">First Peragraph Element</p>
                <script>
                    document.getElementById("elem").innerHTML = "Hello World";
                </script>
            </p>    
        </div>
        </div> 
<!-- example end  -->
<!--FIRST TOPIC END-->

<!--SECOND TOPIC START-->
<p style="text-align: justify; margin-right: 20px;">
    Below is a program that consists of two single-line Statements.
    You can have as many Statements as you need when Writing programs.
</p>
 <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>id = </i> <strong>"firstElem"</strong>></i> First Peragraph Element <i>&lt;/p></i>
<i>&lt;p <i>id = </i> <strong>"secondElem"</strong>></i> Second Peragraph Element <i>&lt;/p></i>

<i>&lt;script></i> 
{
<strong>document</strong>.getElementById(<strong>"firstElem"</strong>).innerHTML = <strong>"Hello World"</strong>;
<strong>document</strong>.getElementById(<strong>"secondElem"</strong>).innerHTML = <strong>"Hello Everyone"</strong>;
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
<div class="output">
<p>
    <p id="firstElem">First Peragraph Element</p>
    <p id="secondElem">First Peragraph Element</p>

    <script>
        document.getElementById("firstElem").innerHTML = "Hello World";
        document.getElementById("secondElem").innerHTML = "Hello Everyone";

    </script>
</p>    
</div>
</div> 
<!-- example end  -->
<!--SECOND TOPIC END-->


<!--THIRD TOPIC START-->
<h3>Grouping JavaScript Statements</h3>
<p style="text-align: justify; margin-right: 20px;">
    JavaScript Statements can be grouped inside curly brackets <b>{...}</b>.
    These are called code blocks. Code blocks are used to make statements execute together.
    They are commonly used in functions.
</p>
<!-- Example start -->
<pre id="precode">
    <i>&lt;!DOCTYPE html></i>
    <i>&lt;html></i>
    <i>&lt;head></i>
        <i>&lt;title></i> Try <i>&lt;/title></i>
    <i>&lt;/head></i>
    <i>&lt;body></i>
        <i>&lt;p <strong>id=</strong><strong id="pink">"demo"</strong><i>></i></i>I am a Peragraph <i>&lt;/p></i>
        <i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"myFunc()" <i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong></strong></i><i>></i><strong id="white">Change HTML Content</strong></strong></i><i>&lt;/button></i>
        <i>&lt;script></i>
          <i>function</i> <strong>myFunc()</strong>{
            document.getElementById(<strong>"demo"</strong>).innerHTML=<i>"Hello Everyone!";</i>
        }
        <i>&lt;/script></i>
    <i>&lt;/body></i>
    <i>&lt;/html></i>
                    </pre>
                    <h4 style="margin-left: 2%;">Out Put</h4>
            <div id="out">
                <div class="output">
                <p>
                    <p id="demo">I am a Peragraph</p>
                    <button type="button" onclick="muFunc()" class="justbutton" style="background-color: rgb(48, 76, 159); color: white;">Change HTML Content</button>
                    <script>
                        function muFunc(){
                            document.getElementById("demo").innerHTML="Hello Everyone!";
                        }
                    </script>
                    </p>             
            </div>
            </div> 
            <!-- example end -->
            <!-- Third Topic End -->


            <!--Fourth TOPIC START-->
<h3>JavaScript Keywords</h3>
<p style="text-align: justify; margin-right: 20px;">
    JavaScript statements usually start with a keyword. Each keyword in JavaScript has its own 
    special meaning. For example, to declare a variable, we have to use the <b>var</b> keyword.
</p>
<!-- Example start -->
<pre id="precode">
    <i>&lt;!DOCTYPE html></i>
    <i>&lt;html></i>
    <i>&lt;head></i>
        <i>&lt;title></i> Try <i>&lt;/title></i>
    <i>&lt;/head></i>
    <i>&lt;body></i>
        <i>&lt;p <strong>id=</strong><strong id="pink">"demo2"</strong><i>></i></i>I am a Peragraph <i>&lt;/p></i>
        <i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"myFunc2()" <i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong></strong></i><i>></i><strong id="white">Change HTML Content</strong></strong></i><i>&lt;/button></i>
        <i>&lt;script></i>
          <i>function</i> <strong>myFunc2()</strong>
          {
            <i>var</i> text = <strong>"Hello World"</strong>;
            document.getElementById(<strong>"demo2"</strong>).innerHTML=<i>text;</i>
        }
        <i>&lt;/script></i>
    <i>&lt;/body></i>
    <i>&lt;/html></i>
                    </pre>
                    <h4 style="margin-left: 2%;">Out Put</h4>
            <div id="out">
                <div class="output">
                <p>
                    <p id="demo2">I am a Peragraph</p>
                    <button type="button" onclick="muFunc2()" class="justbutton" style="background-color: rgb(48, 76, 159); color: white;">Change HTML Content</button>
                    <script>
                        function muFunc2(){
                            var text= "Hello World";
                            document.getElementById("demo2").innerHTML=text;
                        }
                    </script>
                    </p>             
            </div>
            </div> 
            <!-- example end -->
            <!-- Fourth Topic End -->



    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END THIRD LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js syntax (4).php"><input type="button" id="next" value="Next&#187;" /></a>
            <a href="js display output (2).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "Which of the following is used to declare a variable in JavaScript?",
            a: [{ text: "`for` and `while`", isCorrect: false },
            { text: "`if` and `else`", isCorrect: false },
            { text: "`let` and `const`", isCorrect: true },
            { text: "`var` and `function`", isCorrect: false }
            ]

        },
        {
            q: "Which statement is used to exit a loop or switch statement in JavaScript?",
            a: [{ text: "`throw`", isCorrect: false, isSelected: false },
            { text: "`return`", isCorrect: false },
            { text: "`continue`", isCorrect: false },
            { text: "`break`", isCorrect: true }
            ]

        },
        {
            q: "Which statement is used to define a reusable block of code in JavaScript?",
            a: [{ text: "`try`", isCorrect: false },
            { text: "`for`", isCorrect: false },
            { text: "`function`", isCorrect: true },
            { text: "`if`", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>