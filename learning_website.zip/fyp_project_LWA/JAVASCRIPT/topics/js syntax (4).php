<?php
include('js_header.php');
?>
<title>JS Syntax</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">JS Syntax</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>JavaScript Syntax</h3>
            <p style="text-align: justify; margin-right: 20px;">
                JavaScript follows a set of rules called syntax. JavaScript syntax should be 
                followed to create correctly-constructed programs.
            </p>
            <h3>Variable Declaration</h3>
            <p style="text-align: justify; margin-right: 20px;">
                In maths, we use variable to hold values. It works the same way in JavaScript, a 
                value can be assigned to a variable. This is called declaring variables. To declare
                a variable, use the <b>var</b> keyword to create it, and then an equal <b>=</b> sign to asssign
                a value.
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;script></i> 
<i>var</i> num = <strong id="pink">5</strong>;
<strong>document</strong>.write(num);
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <script>
                    var num=5;
                    document.write(num);
                </script>
            </p>    
        </div>
        </div> 
<!-- example end  -->
        <p>The <b>num</b> in the example above is called identifier. JavaScript
        identifiers are used to name variables.
        </p>
<!--FIRST TOPIC END-->

<!--SECOND TOPIC START-->
<h3>JavaScript is Case-Sensitive</h3>
            <p style="text-align: justify; margin-right: 20px;">
                JavaScript identifier are sensitively cased. In this example, the variable
                <b>num</b> and <b>Num</b> are different.
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;script></i> 
<i>var</i> num = <strong id="pink">5</strong>;
<i>var</i> Num = <strong id="pink">6</strong>;
<i>var</i> sum = <strong id="pink">num+Num</strong>;
<strong>document</strong>.write(sum);
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <script>
                    var num=5;
                    var Num=6;
                    var sum=num+Num;
                    document.write(sum);
                </script>
            </p>    
        </div>
        </div> 
<!-- example end  -->
<!--SECOND TOPIC END-->

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FOURTH LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js comments (5).php"><input type="button" id="next" value="Next&#187;" /></a>
            <a href="js statements (3).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
      <!-- Quiz Section -->
    
      <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "Which of the following is used to declare a variable in JavaScript?",
            a: [{ text: "`while` and `switch`", isCorrect: false },
            { text: "`function` and `if`", isCorrect: false },
            { text: "`let` and `const`", isCorrect: true },
            { text: "`var` and `for`", isCorrect: false }
            ]

        },
        {
            q: "What is the purpose of curly braces `{}` in JavaScript?",
            a: [{ text: "To define arrays", isCorrect: false, isSelected: false },
            { text: "To define functions", isCorrect: false },
            { text: "To define variables", isCorrect: false },
            { text: "To define code blocks", isCorrect: true }
            ]

        },
        {
            q: "What is the term for variable and function declarations being moved to the top of their scope?",
            a: [{ text: "Syntax", isCorrect: false },
            { text: "Semicolon", isCorrect: false },
            { text: "Hoisting", isCorrect: true },
            { text: "Scope", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>