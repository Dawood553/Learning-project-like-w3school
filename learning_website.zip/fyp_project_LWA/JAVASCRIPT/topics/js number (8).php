<?php
include('js_header.php');
?>
<title>JS Numbers</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Number Data Type</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Number Data Type</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The number data type is an integer or a floating point number (number with decimal).
        </p>
       

        <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo =</i> <strong>"demo"</strong>></i><i>&lt;/p></i>
<i>&lt;script></i> 
<i>const</i> x = <i id="pink">4;</i> //an integer
<i>const</i> y = <i id="pink">5.5;</i> //a floating point number
<strong>document</strong>.getElementById(<strong>"demo"</strong>).innerHTML = x + "&lt;br />" + y;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
           
                <p id="demo">
                <script> 
const x = 4; //an integer
const y = 5.5; //a floating point number
document.getElementById("demo").innerHTML = x + "<br />" + y;
</script>
    </p>
        </div>
        </div> 
<!-- example end  -->

<!-- Example start -->
<h3>Numbers: Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo =</i> <strong>"demo2"</strong>></i><i>&lt;/p></i>
<i>&lt;script></i> 
<i>const</i> x = <i id="pink">4;</i> //an integer
<i>const</i> y = <i id="pink">5.5;</i> //a floating point number
<i>const</i> sum = <i id="pink">x+y;</i> //adds the two numbers
<strong>document</strong>.getElementById(<strong>"demo2"</strong>).innerHTML = sum;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
           
                <p id="demo2">
               9.5
    </p>
        </div>
        </div> 
<!-- example end  -->


<h3>Combining Strings and Numbers</h3>
            <p style="text-align: justify; margin-right: 20px;">
Combining a string and a string returns a string. Combining a number and a number returns a number.
Combining a string and a number returns a string.

        </p>

        <!-- Example start -->
<h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo =</i> <strong>"demo"</strong>></i><i>&lt;/p></i>
<i>&lt;script></i> 
<i>const</i> text = <i id="pink">21+"Rachell";</i> returns "21Rachell"
<i>const</i> text1 = <i id="pink">"Rachell"+21;</i> returns "Rachell21"
<strong>document</strong>.getElementById(<strong>"demo"</strong>).innerHTML = text + "<br />" + text1;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
           
                <p>
                    21Rachell <br>
                    Rachell21
               
    </p>
        </div>
        </div> 
<!-- example end  -->




            

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END EIGHT LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js boolean (9).php"><input type="button" id="next" value="Next&#187;" /></a>
            <a href="js datatypes (7).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).php"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>