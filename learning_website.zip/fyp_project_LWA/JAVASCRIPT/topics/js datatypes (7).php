<?php
include('js_header.php');
?>
<title>JS DataTypes</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">JavaScript Data Types</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>JavaScript Data Types</h3>
            <p style="text-align: justify; margin-right: 20px;">
            In JavaScript or in any programming language, the concept of data types is important.
        </p>
        <h3>What are Data Types?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Data types are the different kinds of data that can be stored or used in a JavaScript program. String Data Type The string data type is a sequence of characters used to represent text. String can be written with either single or double quotes.
        </p>

        <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo =</i> <strong>"demo"</strong>></i><i>&lt;/p></i>
<i>&lt;script></i> 
<i>const</i> name = <i id="pink">"Jhon Doe";</i> //Double Quatation
<i>const</i> name1 = <i id="pink">'Jhon Doe';</i> //Single Quatation
<strong>document</strong>.getElementById(<strong>"demo"</strong>).innerHTML = name+ "&lt;br />" + name1;;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <p id="demo"></p>
                <script> 
const name = "Jhon Doe"; //Double Quatation
const name1 = 'Jhon Doe'; //Single Quatation
document.getElementById("demo").innerHTML = name+ "<br />" + name1;;
</script>
            </p>    
        </div>
        </div> 
<!-- example end  -->
<h3>Should you use single or double quotes?</h3>
            <p style="text-align: justify; margin-right: 20px;">
            You can use which one you like. But if the string contains single quotes, use double quotes. Or if it contains double quotes, use single quotes.
        </p>

        <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo1 =</i> <strong>"demo1"</strong>></i><i>&lt;/p></i>
<i>&lt;script></i> 
<i>const</i> sentence = <i id="pink">"Her name is 'Maria'";  </i> // use double quotes when the string contains single quotes
<i>const</i> sentence1 = <i id="pink">'Her name is "Maria"'; </i> // use single quotes when the string contains double quotes
<strong>document</strong>.getElementById(<strong>"demo1"</strong>).innerHTML = sentence + "&lt;br />" + sentence1;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
          <p>
          Her name is 'Maria' <br>
          Her name is "Maria"
          </p>
        </div>
        </div> 
<!-- example end  -->






            

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SEVENTH LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js number (8).php"><input type="button" id="next" value="Next&#187;" /></a>
            <a href="js variable (6).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).php"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    
    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>