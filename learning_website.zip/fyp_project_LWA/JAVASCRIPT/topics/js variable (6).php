<?php
include('js_header.php');
?>
<title>JS Variable</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">JavaScript Variables</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>JavaScript Variables</h3>
            <p style="text-align: justify; margin-right: 20px;">
            In programming, variables are used to hold values. In JavaScript, 
            variables are used to store data. The data stored could be a text, a number or others.
             To create (or declare) a variable, use the let keyword and a variable name. let name ; 
            To assign a value to our variable, use the = sign (also called assignment operator).
            </p>
            
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;body></i>
<i>&lt;script></i> 
<i>let</i> name;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>

<!-- example end  -->

 <!-- Example start -->
 <h3>Here Is Another Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;body></i>
<i>&lt;script></i> 
<i>let</i> name;
name =<i id="pink">"Jhon Doe";</i>
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>

<!-- example end  -->
        <p>
        As you can expect:
        <br>
• The text "John" is assigned to firstName <br>
• The text "Doe" is assigned to lastName <br>
• The number 30 is assigned to age <br>

        </p>
<!--FIRST TOPIC END-->

<!--SECOND TOPIC START-->
<h3>Undefined Variables</h3>
            <p style="text-align: justify; margin-right: 20px;">
            If you don't assign a value to your variable, it will be undefined. 
            </p>

             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;body></i>
<i>&lt;script></i> 
<i>let</i> name;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                Undefined 
            </p>    
        </div>
        </div> 

<!-- example end  -->
<h3>Changing Value</h3>
            <p style="text-align: justify; margin-right: 20px;">
            We can also change a variable's value by simply assigning a new value to it. 
            </p>

                 <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;body></i>
<i>&lt;script></i> 
<i>let</i> message = <i id="pink">"I Love HTML";</i>
message =<i id="pink">"I Love JS";</i>
<i>document.write</i>(message);
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
            <script> 
let message = "I Love HTML";
message ="I Love JS";
document.write(message);
</script>
            </p>    
        </div>
        </div> 

<!-- example end  -->
<h3>Constant Variables</h3>
            <p style="text-align: justify; margin-right: 20px;">
            Constant variables cannot be reassigned, this means its value is not changeable. To create a constant variable.
        </p>

            <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;body></i>
<i>&lt;script></i> 
<i>const</i> city = <i id="pink">"Mumbai";</i>
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
            </p>    
        </div>
        </div> 

<!-- example end  -->
<p style="text-align: justify; margin-right: 20px;">
If you try to change a constant  variable's value, you will get an error causing your script to not work.
</p>
 <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;body></i>
<i>&lt;script></i> 
<i>const</i> city = <i id="pink">"Mumbai";</i>
city =  <i id="pink">"Abuja"</i>
<i>document.write</i>(city);
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
            <script> 
const city = "Mumbai";
city =  "Abuja"
document.write(city);
</script>
<h4>Script Not Working</h4>
            </p>    
        </div>
        </div> 

<!-- example end  -->
<p style="text-align: justify; margin-right: 20px;">
Tip! Use const when you don't intend to change a variable's value, this increases the readability and maintainability of your code.
</p>
<h3>Naming Variables</h3>
<p style="text-align: justify; margin-right: 20px;">
JavaScript variables should be identified with unique names. These unique names are called identifiers.
ldentifiers can be as short as single letters like a, b, x, y or Z. They could also be descriptive like firstName or lastName.
</p>

<h3>Rules for Naming Variables</h3>
<p style="text-align: justify; margin-right: 20px;">
• A name should start with a letter, an underscore or a dollar sign <br>
• A name cannot start with a number <br>
•A name is case-sensitive <br>
•A name can only contain letters, digits, underscores and dollar signs

</p>

<h3>JavaScript reserved keywords</h3>
<p style="text-align: justify; margin-right: 20px;">
(Like var, function, if, else,etc.) cannot be used as variable names If you have a multi-worded variable name, it is recommended to use the camelCase way. Just like what we did with firstName and lastName.
</p>

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END SIXTH LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js datatypes (7).php"><input type="button" id="next" value="Next&#187;" /></a>
            <a href="js comments (5).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).php"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>