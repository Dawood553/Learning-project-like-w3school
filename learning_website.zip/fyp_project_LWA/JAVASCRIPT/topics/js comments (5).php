<?php
include('js_header.php');
?>
<title>JS Comments</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">JS Comments</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>JavaScript Comments</h3>
            <p style="text-align: justify; margin-right: 20px;">
                JavaScript comments are used to make programming easier to read and understand.
                Comments are not executed by the browser. Comments can be used to add notes, 
                suggestions and hints to a JavaScript code. There are two types of comments in 
                JavaScript, the single-line and the multi-line.
            </p>
            <h3>Single-Line Comments</h3>
            <p style="text-align: justify; margin-right: 20px;">
                To make a single-line comments, add two forward slash <b>//</b> to the beginning
                of the line. This make al text following it to be a comment. Here is an example
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo =</i> <strong>"demo"</strong>></i>Hello Everyone <i>&lt;/p></i>
<i>&lt;button <i>type = </i> <strong>"button"</strong> <i>onclick = </i> <strong>"myfun()"</strong>></i> Change Content <i>&lt;/button></i>
<i>&lt;script></i> 
<strong id="pink">//this function changes the content of the peragraph element.</strong>
<i>function</i> <strong id="pink">myfun()</strong>{
<i>var</i> text = <strong>"Hello World"</strong>;
<strong>document</strong>.getElementById(<strong>"demo"</strong>).innerHTML = text;
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <p id="demo">Hello Everyone</p>
                <script>
                    var text="Hello World";
                    document.getElementById("demo").innerHTML = text;
                </script>
            </p>    
        </div>
        </div> 
<!-- example end  -->
        <p>The <b>num</b> in the example above is called identifier. JavaScript
        identifiers are used to name variables.
        </p>
<!--FIRST TOPIC END-->

<!--SECOND TOPIC START-->
<h3>JavaScript is Case-Sensitive</h3>
            <p style="text-align: justify; margin-right: 20px;">
                JavaScript identifier are sensitively cased. In this example, the variable
                <b>num</b> and <b>Num</b> are different.
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;script></i> 
<i>var</i> num = <strong id="pink">5</strong>;
<i>var</i> Num = <strong id="pink">6</strong>;
<i>var</i> sum = <strong id="pink">num+Num</strong>;
<strong>document</strong>.write(sum);
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <script>
                    var num=5;
                    var Num=6;
                    var sum=num+Num;
                    document.write(sum);
                </script>
            </p>    
        </div>
        </div> 
<!-- example end  -->
<!--SECOND TOPIC END-->

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIFTH LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js variable (6).php"><input type="button" id="next" value="Next&#187;" /></a>
            <a href="js syntax (4).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).php"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What is the purpose of using comments in JavaScript?",
            a: [{ text: "To make the code run faster", isCorrect: false },
            { text: "To ignore certain parts of the code", isCorrect: false },
            { text: "To explain the code to other developers", isCorrect: true },
            { text: "To add extra functionality to the code", isCorrect: false }
            ]

        },
        {
            q: "Which of the following is an example of a single-line comment in JavaScript?",
            a: [{ text: ">>> This is a comment", isCorrect: false, isSelected: false },
            { text: "--- This is a comment ---", isCorrect: false },
            { text: "/* This is a comment */", isCorrect: false },
            { text: "// This is a comment", isCorrect: true }
            ]

        },
        {
            q: "What is the symbol used to start a multi-line comment in JavaScript?",
            a: [{ text: "//", isCorrect: false },
            { text: ">>>", isCorrect: false },
            { text: "/*", isCorrect: true },
            { text: "***", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>