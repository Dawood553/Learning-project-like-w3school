<?php
include('js_header.php');
?>
<title>Introduction of JS</title>

    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">JS Introduction</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>What is JavaScript?</h3>
            <p style="text-align: justify; margin-right: 20px;">
                JavaScript is a programming or a scripting language that allows the implementation of features on web pages.
            </p>
            <!-- Example start -->
<!-- example end -->
            <h3>Looking Back</h3>
            <p style="text-align: justify; margin-right: 20px;">
                To better understand JavaScript, we can look back at what we already know. 
                We know that Hpertext Markup language(HTML) elements are the building blocks of web pages. And, Cascading
                Style Sheet (CSS) is used for designing HTML elements. <b>JavaScript</b> on the other hand, is what implements the 
                features of web pages. We can simplify this explanation by taking a look at this example:
            </p>
             <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;style></i>
<i>button</i>
{
    <strong>font-family:</strong> <strong id="pink">sans-serif;</strong>
    <strong>border:</strong> <strong id="pink">none;</strong>
    <strong>padding:</strong> <strong id="pink">15px 30px;</strong>
    <strong>font-size:</strong> <strong id="pink">20px;</strong>
    <strong>outline:</strong> <strong id="pink">none;</strong>
    <strong>margin:</strong> <strong id="pink">10px;</strong>
    <strong>border-radius:</strong> <strong id="pink">10px;</strong>
}
<i>#btn</i>
{
    <strong>background-color:</strong> <strong id="pink">lightblue;</strong>
    <strong>color:</strong> <strong id="pink">white;</strong>
}
<i>&lt;/style></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;button <strong>id=</strong><strong id="pink">"btn"<i>></i><strong id="white">Show a dialoge box</strong></strong></i><i>&lt;/button></i>
<i>&lt;script></i>
document.getElementById(<strong>"btn"</strong>).onclick=<i>function()</i>{
    <i>alert</i>(<strong>"I am a dialoge box!"</strong>)
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <style>
                button
                {
                    font-family: sans-serif;
                    border: none;
                    padding: 15px 30px;
                    font-size: 20px;
                    outline: none;
                    margin: 10px;
                    border-radius: 10px;
                }
                #btn
                {
                    background-color: rgb(31, 99, 122);
                    color: white;
                }
                </style>
                <button id="btn">Show a dialoge box</button>
                <script>
                document.getElementById("btn").onclick=function(){
                    alert("I am a dialoge box!")
                }
                </script></p>    
        </div>
        </div> 
        <p style="text-align: justify; margin-right: 20px;">
            As you notice, this web page contains <b>HTML, CSS and JavaScript.</b>
       </p>
       <p style="text-align: justify; margin-right: 20px;">
        In the exmple, HTML is used to create the button. Then, CSS is used to design it. Finally, JavaScript is used to add 
        a simple function that shows a dialog box, when the button is clicked.
   </p>
<!--FIRST TOPIC END-->

<!--Second TOPIC START-->
<h3>What can JavaScript do?</h3>
            <p style="text-align: justify; margin-right: 20px;">
                 Well, a lot! Here are some: JavaScript can change the content of HTML elements.
            </p>
             <!-- Example start -->
             <pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
    <i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
    <i>&lt;p <strong>id=</strong><strong id="pink">"demo"</strong><i>></i></i>Hello World! <i>&lt;/p></i>
    <i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"myFunc()" <i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong></strong></i><i>></i><strong id="white">Change Value</strong></strong></i><i>&lt;/button></i>
    <i>&lt;script></i>
      <i>function</i> <strong>myFunc()</strong>{
        document.getElementById(<strong>"demo"</strong>).innerHTML=<i>"Hello Everyone!";</i>
    }
    <i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
                </pre>
                <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p>
                <p id="demo">Hello World!</p>
                <button type="button" onclick="muFunc()" style="background-color: rgb(48, 76, 159); color: white;">Change Value</button>
                <script>
                    function muFunc(){
                        document.getElementById("demo").innerHTML="Hello Everyone!";
                    }
                </script>
                </p>             
        </div>
        </div> 
             <!-- example end -->
            <p style="text-align: justify; margin-right: 20px;">
                 JavaScript can change the value of attributes. In this example, the value of the
                 <b>src</b> attribute is changed.
            </p>
<!--Second TOPIC END-->
<pre id="precode">
    <i>&lt;!DOCTYPE html></i>
    <i>&lt;html></i>
    <i>&lt;head></i>
        <i>&lt;title></i> Try <i>&lt;/title></i>
    <i>&lt;/head></i>
    <i>&lt;body></i>
        <i>&lt;img <strong>src=</strong><strong id="pink">"back.jpg"<i>id=</i><strong>"image"</strong></strong><i>/></i></i>
        <i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"myFunc()"</strong></i><i><i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong>></i><strong id="white">Change Image</strong></strong></i><i>&lt;/button></i>
        <i>&lt;script></i>
          <i>function</i> <strong>myFunc()</strong>{
            document.getElementById(<strong>"image"</strong>).src=<i>"hero-img.jpg";</i>
        }
        <i>&lt;/script></i>
    <i>&lt;/body></i>
    <i>&lt;/html></i>
                    </pre>
                    <h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
            <p><img src="why-us.png"id="image" width="20%" height="20%"/>
                <button type="button" onclick="myFunc()" style="background-color: rgb(48, 76, 159); color: white;">Change Image</button>
                <script>
                  function myFunc(){
                    document.getElementById("image").src="hero-img.png";
                }
                </script></p>    
        </div>
        </div> 
<!-- Third topic start -->
<p style="text-align: justify; margin-right: 20px;">
    JavaScript can change the styling of HTML elements.
</p>
<!--example-->
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;p <i>id = </i><strong>"demo"</strong><i> style = </i><strong>"color:gold;"</strong>></i>Hello World <i>&lt;/p></i>
<i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"myFunc()"</strong></i><i><i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong>></i><strong id="white">Change Style</strong></strong></i><i>&lt;/button></i>
<i>&lt;script></i>
<i>function</i> <strong>myFunc()</strong>
{
document.getElementById(<strong>"demo"</strong>).style.color=<i>"green";</i>
document.getElementById(<strong>"demo"</strong>).style.fontWeight=<i>"bold";</i>
document.getElementById(<strong>"demo"</strong>).style.fontsize=<i>"300px";</i>
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
       </pre>
       <h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
<div class="output">
<p>
    <p id = "demo1" style = "color:gold;">Hello World </p>
    <button type="button" onclick="myFunc2()" style = "background-color: rgb(48,76,159); color: white;">Change Style</button>
    <script>
    function myFunc2()
    {
    document.getElementById("demo1").style.color="green";
    document.getElementById("demo1").style.fontWeight="bold";
    document.getElementById("demo1").style.fontsize="300px";
    }
    </script>
</p>  
</div>
</div> 
<!-- third topic end -->


<!-- fourth topic start -->
<p style="text-align: justify; margin-right: 20px;">
    This example contains a features that can show or hide HMTL elements.
    This is the another example of changing HTML styles.
</p>
<!--example-->
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;/head></i>
<i>&lt;body></i>
<i>&lt;div <i>id =</i><strong>"show/hide"</strong><i> style = </i><storng id="pink">"width:200px; height:200px; background-color: yellow;"</storng>></i> Hello World <i>&lt;/div></i>
<i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"show()"</strong></i><i><i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong>></i><strong id="white">Show</strong></strong></i><i>&lt;/button></i>
<i>&lt;button <strong>type=</strong><strong id="pink">"button" <i>onclick=<strong id="pink">"hide()"</strong></i><i><i> style = </i><strong id="pink">"background-color: rgb(48,76,159); color: white;"</strong>></i><strong id="white">Hide</strong></strong></i><i>&lt;/button></i>
<i>&lt;script></i>
<i>function</i> <strong>show()</strong>
{
document.getElementById(<strong>"show/hide"</strong>).style.display=<i>"block";</i>
}
<i>function</i> <strong>hide()</strong>
{
    document.getElementById(<strong>"show/hide"</strong>).style.display=<i>"none";</i> 
}
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
       </pre>
       <h4 style="margin-left: 2%;">Out Put</h4>
<div id="out">
<div class="output">
<p>
    <div id ="show/hide" style = "width:200px; height:200px; background-color: yellow;"> Show and Hide </div>
<button type="button" onclick="show()" style = "background-color: rgb(48,76,159); color: white;">Show</button>
<button type="button" onclick="hide()" style = "background-color: rgb(48,76,159); color: white;">Hide</button>
<script>
function show()
{
document.getElementById("show/hide").style.display="block";
}
function hide()
{
    document.getElementById("show/hide").style.display="none"; 
}
</script>
</p>  
</div>
</div> 
 <!-- Example end -->


    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END FIRST LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js display output (2).php"><input type="button" id="next" value="Next&#187;" /></a>
            <!-- <a href="#"><input type="button" id="previous" value="Previous&laquo;" /></a> -->
            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).html"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    <!-- Quiz Section -->
    
    <div class="panel">

        <h1>Take Quiz</h1>

        <div class="question" id="ques"></div>

        <div class="options" id="opt"></div>

        <button onclick="checkAns()" id="btn">SUBMIT</button>

        <div id="score"></div>

    </div>
    <script>
        // Questions that will be asked
        const Questions = [{
            q: "What is JavaScript primarily used for?",
            a: [{ text: "Server-side scripting", isCorrect: false },
            { text: "Database management", isCorrect: false },
            { text: "Client-side scripting", isCorrect: true },
            { text: "Network security", isCorrect: false }
            ]

        },
        {
            q: "What is a key feature of JavaScript?",
            a: [{ text: "Static typing", isCorrect: false, isSelected: false },
            { text: "Dynamic typing", isCorrect: false },
            { text: "Object-oriented programming", isCorrect: false },
            { text: "All of the above", isCorrect: true }
            ]

        },
        {
            q: "What is JavaScript often used in conjunction with?",
            a: [{ text: "C++ and C#", isCorrect: false },
            { text: "Ruby and PHP", isCorrect: false },
            { text: "HTML and CSS", isCorrect: true },
            { text: "Java and Python", isCorrect: false }
            ]

        }

        ]

        let currQuestion = 0
        let score = 0

        function loadQues() {
            const question = document.getElementById("ques")
            const opt = document.getElementById("opt")

            question.textContent = Questions[currQuestion].q;
            opt.innerHTML = ""

            for (let i = 0; i < Questions[currQuestion].a.length; i++) {
                const choicesdiv = document.createElement("div");
                const choice = document.createElement("input");
                const choiceLabel = document.createElement("label");

                choice.type = "radio";
                choice.name = "answer";
                choice.value = i;

                choiceLabel.textContent = Questions[currQuestion].a[i].text;

                choicesdiv.appendChild(choice);
                choicesdiv.appendChild(choiceLabel);
                opt.appendChild(choicesdiv);
            }
        }

        loadQues();

        function loadScore() {
            const totalScore = document.getElementById("score")
            totalScore.textContent = `You scored ${score} out of ${Questions.length}`
        }


        function nextQuestion() {
            if (currQuestion < Questions.length - 1) {
                currQuestion++;
                loadQues();
            } else {
                document.getElementById("opt").remove()
                document.getElementById("ques").remove()
                document.getElementById("btn").remove()
                loadScore();
            }
        }

        function checkAns() {
            const selectedAns = parseInt(document.querySelector('input[name="answer"]:checked').value);

            if (Questions[currQuestion].a[selectedAns].isCorrect) {
                score++;
                console.log("Correct")
                nextQuestion();
            } else {
                nextQuestion();
            }
        }

    </script>
    <!-- Quiz Section Part End -->

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>