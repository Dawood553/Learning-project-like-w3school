<?php
include('js_header.php');
?>
<title>JS Object</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Object Data Type</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Object Data Type</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The object data type is a collection of related data. Objects contain properties written in key: value pairs. Each pair is separated by a comma (,). Objects are written inside curly braces.
        </p>
       


        <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo =</i> <strong>"demo"</strong>></i><i>&lt;/p></i>
<i>&lt;p></i> Accesing object's values will be taught later in the course  <i>&lt;/p></i>
<i>&lt;script></i> 
<i>const</i> banana = <i id="pink">{
      color: "yellow",
      size: "long",
      quantity: 3,
      isSweet: true,
    };
    </i>
<strong>document</strong>.getElementById(<strong>"demo"</strong>).innerHTML = "Banana &lt;br />" +
      "Color: " + banana.color + "&lt;br />" +
      "Size: " + banana.size + "&lt;br />" +
      "Quantity: " + banana.quantity + "&lt;br />" +
      "Does it taste sweet: " + banana.isSweet;

<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
           
                <p id="demo">
                <script> 
const banana = {
      color: "yellow",
      size: "long",
      quantity: 3,
      isSweet: true,
    };
    
document.getElementById("demo").innerHTML = "Banana <br />" +
      "Color: " + banana.color + "<br />" +
      "Size: " + banana.size + "<br />" +
      "Quantity: " + banana.quantity + "<br />" +
      "Does it taste sweet: " + banana.isSweet;

</script>
    </p>
        </div>
        </div> 
<!-- example end  -->
<p style="text-align: justify; margin-right: 20px;">
In the example above, the banana object has 4 properties: color, size, quantity and isSweet And as you may notice, we have accessed these properties using the name of the object followed by a dot (.) and by the name of each property. banana.color banana.size banana .quantity banana.isSweet In this lesson, we have only learned the most basic concepts of JavaScript Objects. There is a designated lesson for Objects, that will teach it in depth.
</p>





            

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END TENTH LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="#"><input type="button" id="next" value="End&#187;" /></a>
            <a href="js boolean (9).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).php"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    

    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>