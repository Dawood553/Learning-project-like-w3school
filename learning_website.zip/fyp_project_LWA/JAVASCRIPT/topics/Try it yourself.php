<!DOCTYPE HTML>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Try it yourself editor</title>
    <style type="text/css">
        body {
            background-color: rgb(107, 233, 220);
        }

        textarea,
        iframe {
            border: 2px solid #ddd;
            height: 500px;
            width: 100%;
        }

        #btn {
            color: red;
            cursor: pointer;
            font-size: 32px;
            border-radius: 10px;
        }

        #btn:hover {
            background-color: black;
            color: white;
            transition: 2s;
        }

        #sourceCode {
            font-size: 16px;
            font-weight: 600;
            background-color: transparent;
            border-radius: 10px;
            border: 2px solid white;
        }

        #targetCode {
            border-radius: 10px;
            border: 2px solid white;
        }

        button a {
            color: red;
            cursor: pointer;
            font-size: 20px;

        }

        button {
            border-radius: 10px;
        }

        button:hover {
            background-color: red;
            transition: 1s;
        }

        button a:hover {
            color: black;
            transition: 1s;
        }
    </style>
</head>

<body>
    <h1 style="color: red;">CODE AREA</h1>
    <button><a href="http://localhost/fyp_project_LWA/JAVASCRIPT/topics/introduction%20of%20js%20(1).php" style="text-decoration: none;">Home</a></button>
    <table width="100%" border="0" cellspacing="5" cellpadding="5">
        <tr>
            <td width="50%" scope="col">&nbsp;</td>
            <td width="50%" align="left" scope="col">
                <input onclick="runCode();" type="button" value="Run Code" id="btn">
            </td>
        </tr>
        <tr>
            <td>
                <form>
                    <strong style="color: red; font-size: 20px;">Code</strong>
                    <textarea name="sourceCode" id="sourceCode">
<!DOCTYPE html>
<html>
<head>

<title>Hello</title>

</head>
<body>

<h1>Try It yourself</h1>
<h3>Just write the HTML, CSS and javascript code and click on the Run Button !</h3>


</body>
</html>
                        </textarea>
                </form>
            </td>
            <td><strong style="color: red;font-size: 20px;">Output</strong><iframe name="targetCode"
                    id="targetCode"></iframe></td>
        </tr>
    </table>
    <script type="text/javascript">
        function runCode() {
            var content = document.getElementById('sourceCode').value;
            var iframe = document.getElementById('targetCode');
            iframe = (iframe.contentWindow) ? iframe.contentWindow : (iframe.contentDocument.document) ? iframe.contentDocument.document : iframe.contentDocument;
            iframe.document.open();
            iframe.document.write(content);
            iframe.document.close();
            return false;
        }
        runCode();
    </script>
</body>

</html>