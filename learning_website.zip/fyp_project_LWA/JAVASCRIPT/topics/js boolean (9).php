<?php
include('js_header.php');
?>
<title>JS  Boolean</title>
    <div class="container"> 
        <br>
        <div class="notes">


            <!--FIRST TOPIC START-->
            <h2 style="text-align: center;border-bottom: 1px solid white;font-size: 32px;" id="intro">Boolean Data Type</h2>
             <!-- for languages -->

 <div id="google_element" class="mx-1"></div>

<!-- for languages end -->
            <h3>Boolean Data Type</h3>
            <p style="text-align: justify; margin-right: 20px;">
            The Boolean data type is a logical data type that can only have true or false as values.
        </p>
       

        <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo =</i> <strong>"demo"</strong>></i><i>&lt;/p></i>
<i>&lt;script></i> 
<i>const</i> isCodingFun = <i id="pink">true;</i> //an integer
<i>const</i> isMathFun = <i id="pink">true;</i> //a floating point number
<strong>document</strong>.getElementById(<strong>"demo"</strong>).innerHTML = "Is coding fun? " + isCodingFun + "<br />" +
      "Is Math fun? " + isMathFun;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
           
                <p>
Is coding fun?true
<br>
Is maths fun?true
    </p>
        </div>
        </div> 
<!-- example end  -->
<p style="text-align: justify; margin-right: 20px;">
Booleans are mainly used for conditional testing, not the one that we did in our previous example.
You wilU learn about conditional testing later. Booleans are the output of comparison operators.
The == Comparison operator tests if two values are equal or the same. If they are, it returns true, otherwise false.
        </p>

        <!-- Example start -->
 <h3>Example</h3>
<pre id="precode">
<i>&lt;!DOCTYPE html></i>
<i>&lt;html></i>
<i>&lt;head></i>
<i>&lt;title></i> Try <i>&lt;/title></i>
<i>&lt;p <i>demo =</i> <strong>"demo"</strong>></i><i>&lt;/p></i>
<i>&lt;p></i> Try changing the value of one of the Booleans to output false.  <i>&lt;/p></i>
<i>&lt;script></i> 
<i>const</i> x = <i id="pink">3;</i>
<i>const</i> y = <i id="pink">3;</i>
<i>const</i> areTheyEqua = <i id="pink">(x == y);;</i>
<strong>document</strong>.getElementById(<strong>"demo"</strong>).innerHTML = areTheyEqual;
<i>&lt;/script></i>
<i>&lt;/body></i>
<i>&lt;/html></i>
</pre>
<h4 style="margin-left: 2%;">Out Put</h4>
        <div id="out">
            <div class="output">
           
                <p>
True
    </p>
        </div>
        </div> 
<!-- example end  -->






            

    <!--MAIN DIV CONTAINER ALL CODE GOES INSIDE THIS-->
        </div>
        <br>
        <br>
        <h4 style="color: white;text-align:center;" id="end">END NINTH LECTURE</h4>
        <br>
        <div class="next-previous">
            <a href="js object (10).php"><input type="button" id="next" value="Next&#187;" /></a>
            <a href="js number (8).php"><input type="button" id="previous" value="Previous&laquo;" /></a>

            <!-- <a href="#"><button id="next">Next&#187;</button></a>
            <a href="html comments(5).php"><button id="previous">&laquo;Previous</button></a> -->
            <br>
            <!-- <p style="text-align: center;"> <a href="Introduction of JS (1).pdf">Pdf Download </a></p> -->

            <br>
            <br>
            <br>
            <br>
    </div>
    </div>
    
    <!-- for languages -->
  <script src="http://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>
    <script>
        function loadGoogleTranslate(){
            new google.translate.TranslateElement("google_element");
        }
    </script>
    <!-- for languages end -->
</body>
</html>