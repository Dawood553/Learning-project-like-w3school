<?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\navbar.php');
?>
  <title>Let's Learn Programming JS</title>


 

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="200">
          <h1>Welcome to JavaScript Learning</h1>
          <h2>We are always here to serve you 24/7</h2>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="topics/introduction of js (1).php" class="btn-get-started scrollto">Start Learning</a>
            
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img" data-aos="zoom-in" data-aos-delay="200">
          <img src="\fyp_project_LWA\assets\img\logo.png" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= Clients Section ======= -->
    <!-- End Cliens Section -->

    <!-- ======= About Us Section ======= -->
   <section id="about" class="about">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>JavaScript</h2>
        </div>

        <div class="row content">
          <div class="col-lg-6">
            <p>
            Here is a detailed explanation of JavaScript, including its history, features, and uses:
            </p>
            
            <ul>
            <li><i class=""></i><h3>History of JavaScript</h3></li>
              <li><i class="ri-check-double-line"></i> Created by Brendan Eich in 1995 while working at Netscape Communications</li>
              <li><i class="ri-check-double-line"></i> Initially called "Mocha," then renamed to "JavaScript"</li>
              <li><i class="ri-check-double-line"></i> First released in 1995 as part of Netscape Navigator 2.0</li>
              <li><i class="ri-check-double-line"></i> Became an ECMA standard in 1997 (ECMAScript)</li>
              <li><i class="ri-check-double-line"></i> Now widely used in web development, mobile app development, and server-side programming</li>
              
            </ul>

          </div>
          <div class="col-lg-6 pt-4 pt-lg-0">
          <ul>
              <li><i class=""></i><h3>Features of JavaScript</h3></li>
              <li><i class="ri-check-double-line"></i> <b>Client-side scripting:</b> Runs on the client-side (web browser), reducing server load and improving responsiveness</li>
              <li><i class="ri-check-double-line"></i> <b>Dynamic: </b> Can manipulate web pages dynamically, without requiring a full page reload</li>
              <li><i class="ri-check-double-line"></i> <b>Object-oriented: </b> Supports object-oriented programming (OOP) concepts like inheritance, polymorphism, and encapsulation</li>
              <li><i class="ri-check-double-line"></i> <b>Prototype-based: </b> Uses prototypes instead of classes for inheritance</li>
              <li><i class="ri-check-double-line"></i> <b>Async-friendly: </b> Supports asynchronous programming using callbacks, promises, and async/await</li>
            </ul>
            
<!-- Modal Start -->
<button class="btn-learn-more" data-toggle="modal" data-target="#mymodal">
Read More
</button>
<div class="modal fade modal-lg" id="mymodal" data-backdrop="static">
<div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
<div class="modal-content">
    <div class="modal-header">
        <h2 class="modal-title">
            JavaScript
        </h2>
        <button class="close btn btn-white text-danger" data-dismiss="modal">
          X
        </button>
    </div>
    <div class="modal-body">
        <div class="card">
          <!-- <img src="\fyp_project_LWA\assets\img\js.jpg" class="card-img-top img-fluid" alt=""> -->
          <video src="\fyp_project_LWA\assets\img\videos\js.mp4" class="card-img-top img-fluid" controls muted autoplay loop style="width:100%; height:100%;"></video>

          <div class="card-body">
            <h1 class="card-title">
            Uses of JavaScript
            </h1>
            <p class="card-text">
            <h3>Web development:</h3>
            Used for client-side scripting, creating interactive web pages, and web applications
          </p>

            <p class="card-text">
            <h3>Mobile app development: </h3>
            Used in hybrid mobile app development frameworks like React Native, Angular Mobile, and Ionic
          </p>

            <p class="card-text">
            <h3>Server-side programming: </h3>
            Used in server-side frameworks like Node.js, Express, and Koa
          </p>

            <p class="card text">
                <h3>Desktop applications:</h3>
                Used in desktop applications like Electron and NW.js
              </p>

              <h1 class="card-title">
              JavaScript Libraries and Frameworks
              </h1>

              <p class="card text">
                <h3>React</h3>
                
                A popular JavaScript library for building user interfaces and components
              </p>

              <p class="card text">
                <h3>Angular</h3>
                A JavaScript framework for building complex web applications
              </p>

              <p class="card text">
                <h3>Vue.js:</h3>
                A progressive and flexible JavaScript framework for building web applications
              </p>

              <p class="card text">
                <h3>jQuery:</h3>
                A popular JavaScript library for simplifying DOM manipulation and event handling
              </p>
            <p class="card text">
                <h3>Lodash: </h3>
                A utility library for simplifying common programming tasks
              </p>
              <h1 class="card-title">
              JavaScript Best Practices
              </h1>
              <p class="card text">
                <h3>Use strict mode: </h3>
                Enable strict mode to avoid common errors and improve code quality
              </p>

              <h1 class="card-title">HTML Versions</h1>
              <p class="card text">
                <h3>Use modular code: </h3>
                Break code into smaller, reusable modules
              </p>

              <p class="card text">
                <h3>Use version control: </h3>
                Use Git or other version control systems to manage code changes
              </p>

              <p class="card text">
                <h3>Test code: </h3>
                Write unit tests and integration tests to ensure code quality
              </p>

              <p class="card text">
                <h3>Follow coding standards: </h3>
                Follow established coding standards and conventions
              </p>

              <p class="card text">
                <h3>Conclusion: </h3>
                I hope this provides a detailed overview of JavaScript! Let me know if you have any specific questions or need further clarification.
              </p>

              

          </div>
        </div>
    
    <div class="modal-footer">
        <button class="btn btn-danger" class="close" data-dismiss="modal">
            close
        </button>
    </div>
</div>

</div>


            <!-- Modal End -->
          </div>
        </div>

      </div>
    </section>
    <!-- End About Us Section -->

    <!-- ======= Why Us Section ======= -->
    
    <!-- End Why Us Section -->

    <!-- ======= Skills Section ======= -->
    <!-- End Skills Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Services</h2>
        <p>"Unlock the power of dynamic web development with our comprehensive JavaScript topics! Master the art of 
          coding with our in-depth lectures on JavaScript fundamentals, including Introduction Of JavaScript, JavaScript DataTypes, JavaScript Variables, JavaScript Comments
           , and much more. Our topics are designed to help you understand the basics and beyond, so you can create 
           interactive web pages and applications with ease. 
          Whether you're a beginner or looking to refresh your skills, our JavaScript topics have got you covered!"</p>
      </div>

        <div class="row">
          <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <h4><a href="topics/introduction of js (1).php">Introduction Of JS</a></h4>
              <p>JavaScript is a programming or a scripting language that allows the implementation of features on web pages.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="topics/js datatypes (7).php">JavaScript Data Types</a></h4>
              <p>Data types are the different kinds of data that can be stored or used in a JavaScript program. String Data Type The string data type is a sequence of characters 
                used to represent text. String can be written with either single or double quotes.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="topics/js variable (6).php">JavaScript Variables</a></h4>
              <p>In programming, variables are used to hold values. In JavaScript, variables are used to store data. The data stored could be a text, a number or others.</p>
            </div>
          </div>

          <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-layer"></i></div>
              <h4><a href="topics/js comments (5).php">JavaScript Comments</a></h4>
              <p>JavaScript comments are used to make programming easier to read and understand. Comments are not executed by the browser.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->
    <?php
include('\xampp\htdocs\fyp_project_LWA\assets\part\footer.php');
?>