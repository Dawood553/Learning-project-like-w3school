<?php
include('admin_header.php');
?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="http://localhost/fyp_project_LWA/admins/admin.php">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div>
    <!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            <!-- Complaint Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card shadow">

                

                <div class="card-body">
                  <h5 class="card-title">Total <span>| <a href="complaint-form.php">Complaint</a></span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-archive"></i>
                    </div>
                    <div class="ps-3">
                      <!-- php -->
                      <?php
                      $dash_complaint_query="SELECT * FROM `complaints`;";
                      $dash_complaint_query_run=mysqli_query($con,$dash_complaint_query);

                      if($complaint_total=mysqli_num_rows($dash_complaint_query_run))
                      {
                        echo '<h6>'.$complaint_total.'<h6>';
                      }
                      else
                      {
                        echo "<h6>NO data</h6>";
                      }
                      ?>
                      <!-- <h6>145</h6> -->
                      
                      
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <!-- End Complaint Card -->

            <!-- Contact Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card shadow">


                <div class="card-body">
                  <h5 class="card-title">Total <span>| <a href="contact-form.php">Contact</a></span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-telephone"></i>
                    </div>
                    <div class="ps-3">
                      <!-- php -->
                      <?php
                      $dash_contact_query="SELECT * FROM `contact`;";
                      $dash_contact_query_run=mysqli_query($con,$dash_contact_query);

                      if($contact_total=mysqli_num_rows($dash_contact_query_run))
                      {
                        echo '<h6>'.$contact_total.'<h6>';
                      }
                      else
                      {
                        echo "<h6>NO data</h6>";
                      }
                      ?>
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <!-- End Contact Card -->

            <!-- Feedback Card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card shadow">


                <div class="card-body">
                  <h5 class="card-title">Total <span>| <a href="feedback-form.php">Feedbacks</a></span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-box"></i>
                    </div>
                    <div class="ps-3">
                     <!-- php -->
                     <?php
                      $dash_feedback_query="SELECT * FROM `feedback`;";
                      $dash_feedback_query_run=mysqli_query($con,$dash_complaint_query);
                      if($total_feedback=mysqli_num_rows($dash_feedback_query_run))
                      {
                        echo '<h6>'.$total_feedback.'</h6>';
                      }
                      else
                      {
                        echo "<h6> No Data </h6>";
                      }


                      ?>
                    </div>
                  </div>
                </div>

              </div>
            </div>
            <!-- End Feedback Card -->


  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>D&Y</span></strong>. All Rights Reserved
    </div>
    <div class="credits"> Designed by <a href="#">D&Y</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="\fyp_project_LWA\Admins\superadmin\assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
  

  <!-- Template Main JS File -->
  <script src="\fyp_project_LWA\Admins\superadmin\assets\js\main.js"></script>

</body>

</html>