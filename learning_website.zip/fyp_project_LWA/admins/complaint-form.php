
<?php
include('admin_header.php');

?>
<title>Complaint Form</title>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Complaints</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Complaints</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <table class="table table-bordered border-primary">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Full name</th>
          <th scope="col">Email</th>
          <th scope="col">Language</th>
          <th scope="col">Topic</th>
          <th scope="col">Detail</th>
          <th scope="col">Status</th>
          <th scope="col">Response</th>
        </tr>
      </thead>
      <tbody>

        <!-- php start -->


        <?php
        $select=mysqli_query($con,"SELECT * FROM `complaints`");
        while($data=mysqli_fetch_array($select)){
          ?>
          <tr>
            <td><?=$data['id'];?></td>
            <td><?=$data['full_name'];?></td>
            <td><?=$data['email'];?></td>
            <td><?=$data['language'];?></td>
            <td><?=$data['topic'];?></td>
            <td><?=$data['detail'];?></td>
            <td>
        <?php
        if($data['status']==1)
        {
            echo '<p><a href="complaint_status2.php?id='.$data['id'].'&status=0" class="btn btn-success">Done</a></p>';        
        }
        else
        {
            echo '<p><a href="complaint_status2.php?id='.$data['id'].'&status=1" class="btn btn-danger">Pending</a></p>';        
               
        }
        ?>
    </td>
            <td>
              <a href="superadmin/email.php" class="btn btn-outline-primary btn-sm">Sent Email</a>
            </td>
          </tr>
        <?php
        }
        ?>



        <!-- php end -->
      </tbody>
    </table>
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>D&Y</span></strong>. All Rights Reserved
    </div>
    <div class="credits">Designed by <a href="#">D&Y</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  
  <script src="\fyp_project_LWA\Admins\superadmin\assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
  

  <!-- Template Main JS File -->
  <script src="\fyp_project_LWA\Admins\superadmin\assets\js\main.js"></script>


</body>

</html>