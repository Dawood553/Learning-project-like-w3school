<?php
include('\xampp\htdocs\fyp_project_LWA\config\connection.php');
$id=$_GET['id'];
$status=$_GET['status'];
$query=mysqli_query($con,"UPDATE `admin_register` SET `status`=$status WHERE `id`=$id;");

    header('location:total_admins.php');


?>