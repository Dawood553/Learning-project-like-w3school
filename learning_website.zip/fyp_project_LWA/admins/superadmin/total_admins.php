
<?php
include('super-admin_header.php');
?>
  <title>Total Admins</title>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Total Admins</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Total Admins</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <table class="table table-bordered border-primary">
      <thead>
      <tr>
          <th><abbr title="Admin ID" style="text-decoration:none;">#</abbr></th>
          <th scope="col">Full name</th>
          <th scope="col">Email</th>
          <th scope="col">Password</th>
          <th><abbr title="Confirm Password" style="text-decoration:none;">C_Pass</abbr></th>
          <th scope="col">Phone No</th>
          <th scope="col">Date</th>
          <th scope="col">status</th>
          <th scope="col">Action</th>
          <th scope="col">Response</th>
        </tr>
      </thead>
      <tbody>
        <!-- php start -->
        <?php
        $select=mysqli_query($con,"SELECT * FROM `admin_register`");
        while($data=mysqli_fetch_array($select)){
          ?>
          <tr>
            <td><?=$data['id'];?></td>
            <td><?=$data['full_name'];?></td>
            <td><?=$data['email'];?></td>
            <td><?=$data['password'];?></td>
            <td><?=$data['confirm_password'];?></td>
            <td><?=$data['phone_no'];?></td>
            <td><?=$data['date'];?></td>
            <!-- for status -->

            <td>
        <?php
        if($data['status']==1)
        {
            echo '<p><a href="active.php?id='.$data['id'].'&status=0" class="btn btn-success btn-sm">Block</a></p>';        
        }
        else
        {
            echo '<p><a href="active.php?id='.$data['id'].'&status=1" class="btn btn-danger btn-sm">UnBlock</a></p>';        
               
        }
        ?>
    </td>
    <td>
              <a href="delete_admins.php?id=<?=$data['id'];?>" class="btn btn-danger btn-sm" onclick="return myConfirm()">Remove</a>

              <script>
function myConfirm()
{
var result=confirm("Are You Sure To Delete");
if(result)
{
return true;
}
else{
return false;
}
}
</script>
            </td>
    <td>
              <a href="email.php" class="btn btn-outline-primary btn-sm btn-sm">Sent Email</a>
            </td>
            

            <!-- for status end -->

        
          </tr>
        <?php
        }
        ?>



        <!-- php end -->
      </tbody>
    </table>
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>D&Y</span></strong>. All Rights Reserved
    </div>
    <div class="credits">Designed by <a href="#">D&Y</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>