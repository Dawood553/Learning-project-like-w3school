<?php
include('\xampp\htdocs\fyp_project_LWA\config\connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <!-- <title>Admin Contact Form</title> -->
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.png" rel="icon"> -->
  <link rel="icon" href="assets/img/logo.png">

  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
<style>
  .card:hover{
            transform: scale(1.05);
        transition:1s;
        cursor: pointer;
  }
</style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="logo.png" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">Super-Admin</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->
    <a href="" style="margin-left:auto; color:black;">
  <?php
session_start();
if(isset($_SESSION['uname2'])){
    // echo "Welcome ".$_SESSION['uname'];
    ?>
    <div class="alert alert-success p-2 mt-2">Welcome <?php echo $_SESSION['uname2'];?></div>

    <?php
    
}
else{
    echo "<script>location.href='http://localhost/fyp_project_LWA/LOGIN/login2.php'</script>";
}
?>
  </a>
   <!-- End Notification Dropdown Items -->

        <!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

    <li class="nav-item">
        <a class="nav-link " href="http://localhost/fyp_project_LWA/admins/superadmin/super-admin.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

      <!-- End Components Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-journal-text"></i><span>Forms</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="http://localhost/fyp_project_LWA/admins/superadmin/admin-contact-form.php">
              <i class="bi bi-circle"></i><span>Contact Form</span>
            </a>
          </li>
          <li>
            <a href="http://localhost/fyp_project_LWA/admins/superadmin/admin-complaint-form.php">
              <i class="bi bi-circle"></i><span>Complaint Form</span>
            </a>
          </li>
          <li>
            <a href="http://localhost/fyp_project_LWA/admins/superadmin/admin-feedback-form.php">
              <i class="bi bi-circle"></i><span>Feedback Form</span>
            </a>
          </li>
          <li>
            <a href="http://localhost/fyp_project_LWA/admins/superadmin/admins-contacts.php">
              <i class="bi bi-circle"></i><span>Admin Contact</span>
            </a>
          </li>
          <li>
            <a href="http://localhost/fyp_project_LWA/admins/superadmin/total_admins.php">
              <i class="bi bi-circle"></i><span>Total Admins</span>
            </a>
          </li>
        </ul>
      </li>
      <!-- End Forms Nav -->

      <li class="nav-heading">Pages</li>

      

      <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="pages-faq.html">
          <i class="bi bi-question-circle"></i>
          <span>F.A.Q</span>
        </a>
      </li>End F.A.Q Page Nav -->

      
      <!-- register admins -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="http://localhost/fyp_project_LWA/admins/superadmin/admin_registration.php">
          <i class="bi bi-card-list"></i>
          <span>Register Admins</span>
        </a>
      </li>
      <!-- End Register Page Nav -->

      <!-- Delete Admins -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="http://localhost/fyp_project_LWA/admins/superadmin/delete-admins.php">
          <i class="bi bi-card-list"></i>
          <span>Delete Admins</span>
        </a>
      </li>
      <!-- Delete Admins -->
      <!-- End Contact Page Nav -->
      <!-- End Register Page Nav -->

      <li class="nav-item">
        <a class="nav-link collapsed" href="http://localhost\fyp_project_LWA\LOGIN\logout.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Log Out</span>
        </a>
      </li><!-- End Login Page Nav --><!-- End Error 404 Page Nav --><!-- End Blank Page Nav -->

    </ul>

  </aside>
  <!-- End Sidebar-->