<?php
include('\xampp\htdocs\fyp_project_LWA\config\connection.php');
?>
<?php
session_start();
if(isset($_SESSION['uname2'])){
    // echo "Welcome ".$_SESSION['uname'];
    ?>
    <div class="alert alert-success p-2 mt-2">Welcome <?php echo $_SESSION['uname2'];?></div>

    <?php
    
}
else{
    echo "<script>location.href='http://localhost/fyp_project_LWA/LOGIN/login2.php'</script>";
}
?>
  
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Delete Admins</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body>

  <main>
    <a href="http://localhost/fyp_project_LWA/admins/superadmin/total_admins.php"><input type="submit" value="&laquo;" class="btn btn-primary"></a>
    <div class="container">

      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 d-flex flex-column align-items-center justify-content-center">

              <div class="d-flex justify-content-center py-4">

                <a href="assets/img/logo.png" class="logo d-flex align-items-center w-auto">
                  <img src="assets/img/logo.png" alt="">
                  <span class="d-none d-lg-block">Super-Admin</span>
                </a>
              </div><!-- End Logo -->

              <div class="card mb-3">

                <div class="card-body">

                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">Delete Admin Account</h5>
                    <p class="text-center small">Enter admins details to delete account</p>
                  </div>
                  <form action="" method="post">
                    <div class="col-12">
                      <label class="form-label">Admin Email</label>
                      <input type="email" pattern="[a-zA-z0-9]+@+gmail.com" title="Abc123@gmail.com" name="email" class="form-control" required>
                    </div>

                    <div class="col-12">
                      <label class="form-label">Admin Password</label>
                      <input type="password" name="password" class="form-control" required>
                    </div>

                    <div class="col-12">
                      <div class="form-check">
                       <label><input type="checkbox" class="form-check-label" required> I agree and accept the <a href="#">terms and conditions</a>
                        
                      </div>
                    </div>
                    <div class="col-12">
                      <button class="btn btn-primary w-100" name="delete" type="submit">Delete Admin</button>
                    </div>
                    <div class="col-12"> </div>
                  </form>

                </div>
              </div>

              <div class="credits">Designed by <a href="#">D&Y</a>
              </div>

            </div>
          </div>
        </div>

      </section>

    </div>
  </main><!-- End #main -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>

<?php
if(isset($_POST['delete'])){
  $admin_email=$_POST['email'];
  $admin_password=$_POST['password'];
  $delete=mysqli_query($con,"DELETE FROM `admin_register` WHERE `email`='$admin_email' AND `password`='$admin_password' ;");
  if($delete)
  {
    echo "<center><br><br>Admin Deleted Successfully</center>";
  }
  else
  {
    echo "<center><br><br>Failed Please Try Again</center>"; 
  }
}
?>