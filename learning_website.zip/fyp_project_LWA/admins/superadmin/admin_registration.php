<?php
include('\xampp\htdocs\fyp_project_LWA\config\connection.php');
?>

<?php
session_start();
if(isset($_SESSION['uname2'])){
    // echo "Welcome ".$_SESSION['uname'];
    ?>
    <div class="alert alert-success p-2 mt-2">Welcome <?php echo $_SESSION['uname2'];?></div>

    <?php
    
}
else{
    echo "<script>location.href='http://localhost/fyp_project_LWA/LOGIN/login2.php'</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Register Forms</title>
    <link rel="icon" href="#">
    <link rel="stylesheet" href="bootstrap.min.css">
    <link rel="stylesheet" href="\fyp_project_LWA\config\registration_admin_style2.css">

    <style>
    #php2{
            color:white;
            border:1px solid white; 
            border-radius:5px;
            background-color:red;
            height: 50px;
            font-size:32px;
    }
    #php{
            color:white;
            font-weight:250;
            border:2px solid white; 
            border-radius:10px;
            padding:5px 5px 5px 5px;
            background-color:black;
            height: 50px;
            width:100%;
            font-size:32px;
        }
  </style>
</head>
<body>
    <div class="form-bg">
        <div class="container">
            <div class="row">
                    <div class="form-container">
                        <h3 class="title">Register Admin</h3>
                        <h3 class="link"><a href="http://localhost/fyp_project_LWA/admins/superadmin/total_admins.php" class="btn btn-danger btn-sm text-white"style="font-size:25px;">&laquo;</a></h3>
                        <form class="form-horizontal" action="#" method="POST" onsubmit="return validatePassword()">
                            <div class="form-group">
                                <label>User Name</label>
                                <input type="text" pattern="[A-Za-z ]+" title="Only letters and spaces are allowed" name="name" autofocus class="form-control" placeholder="User Name" required>
                            </div>
                            <div class="form-group">
                                <label>Email ID</label>
                                <input type="email" pattern="[a-zA-z0-9]+@+gmail.com" title="Abc123@gmail.com" name="email" autofocus class="form-control" placeholder="Email Address" pattern="[a-zA-Z0-9]+@+gmail.com" title="Abc123@gmail.com" required>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" id="pass" name="password" autofocus class="form-control" placeholder="Password" minlength="8" required>
                            </div>
                            <div class="form-group">
                                <label>Confirm Password</label>
                                <input type="password" id="cpass" name="confirm_password" class="form-control" placeholder="Confirm Password" minlength="8" required>
                            </div>

                            <script>
            function valid(){
                var pass= document.getElementById('pass').value;
                var cpass= document.getElementById('cpass').value;
                if(pass==cpass)
            {
                return true;
            }
            else{
                alert("Password must be match");
                return false;
            }
            }
        </script>




                            <h4 class="sub-title">Personal Information</h4>
                            <div class="form-group">
                                <label>Phone No.</label>
                                <input type="number" oninput="validateNumber(this)" name="phone_no" class="form-control" placeholder="Phone Number" required>
                            </div>

                            <script>
                                function validateNumber(input)
                                {
                                    const number=/[0-9]+/;
                                    if(!number.test(input.value))
                                {
                                    input.value=input.value.replace(/[0-9]/);
                                }
                                }
                            </script>
                            
                            <div class="form-group">
                                <label>Date&Time</label>
                                <input type="date" name="datetime" class="form-control" required>
                            </div>
                            <div class="check-terms">
                                <input type="checkbox" class="checkbox" required>
                                <span class="check-label">I agree to the terms</span>
                            </div>
                            <button class="btn signup" name="submit" onclick="return valid()">Create Account</button>
                            
                            
                            <!-- php start -->


     <?php
if(isset($_POST['submit'])){
    $fullname=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $confirm_password=$_POST['confirm_password'];
    $phone=$_POST['phone_no'];
    $datetime=$_POST['datetime'];
    $send=mysqli_query($con,"INSERT INTO `admin_register`(`full_name`, `email`, `password`, `confirm_password`, `phone_no`, `date`) VALUES ('$fullname','$email','$password','$confirm_password','$phone','$datetime');");
    if($send)
    {
        echo " <center><b><br> <i id='php'>Admin Successfully Registered</i></b></center> ";
       
    }
    else
    {
        echo "<center><b><br><i id='php2'>Failed Please Try Again</i></b></center>";
        
    }
}
?>




                        <!-- php end -->


                        </form>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
     
</body>
</html>