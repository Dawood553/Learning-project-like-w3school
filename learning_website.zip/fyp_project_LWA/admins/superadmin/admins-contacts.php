<?php
include('super-admin_header.php');
?>
  <title>Admin Contacts</title>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Admin Contacts</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Admins Contacts</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <table class="table table-bordered border-primary">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Admin Name</th>
          <th scope="col">Admin Email</th>
          <th scope="col">Subject</th>
          <th scope="col">Message</th>
          <th scope="col">Response</th>
        </tr>
      </thead>
      <tbody>
        

        <!-- php start -->


        <?php
        $select=mysqli_query($con,"SELECT * FROM `admins_contact`");
        while($data=mysqli_fetch_array($select)){
          ?>
          <tr>
            <td><?=$data['id'];?></td>
            <td><?=$data['full_name'];?></td>
            <td><?=$data['email'];?></td>
            <td><?=$data['subject'];?></td>
            <td><?=$data['message'];?></td>
            <td>
              <a href="email.php" class="btn btn-outline-primary btn-sm">Sent Email</a>
            </td>
          </tr>
        <?php
        }
        ?>



        <!-- php end -->

      </tbody>
    </table>
  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>D&Y</span></strong>. All Rights Reserved
    </div>
    <div class="credits"> Designed by <a href="#">D&Y</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>