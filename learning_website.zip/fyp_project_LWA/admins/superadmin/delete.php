<?php
include('\xampp\htdocs\fyp_project_LWA\config\connection.php');
$id=$_GET['id'];
$query=mysqli_query($con,"DELETE FROM `admin_register` WHERE `id`=$id;");
header('location:total_admins.php');
?>