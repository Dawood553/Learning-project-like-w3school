<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-lighter">
<div class="container mt-3 bg-white p-3 shadow-lg" style="border:1px solid black; border-radius:10px;">
    <h3 class="text-center text-info">Give Answer To The Users Through Gmail</h3>
    <hr style="height:3px;" class="bg-info">
       <form action="" method="post" class="mt-4">
       <div class="row">

       <div class="col-md-12">
                <div class="form-group">
                    <label for="">From:</label>
                    <input type="email" value="abc123@gmail.com" class="form-control" placeholder="i.e Admin" disabled>
                </div>
            </div>

       <div class="col-md-12">
                <div class="form-group">
                    <label for="">Name:</label>
                    <input type="text" value="Admin" pattern="[A-Za-z ]+" title="Only letters and spaces are allowed"  class="form-control" name="name" placeholder="i.e Admin" required>
                </div>
            </div>

        <div class="col-md-12 mt-3">
                <div class="form-group">
                    <label for="">To:</label>
                    <input type="email" pattern="[a-zA-z0-9]+@+gmail.com" title="Abc123@gmail.com"  class="form-control" name="receiver_email" placeholder="i.e abc@gmail.com" required>
                </div>
            </div>
            <div class="col-md-12 mt-3">
                <div class="form-group">
                    <label for="">Subject:</label>
                    <input type="text" value="Thanks to send me your problem" class="form-control" name="subject" placeholder="i.e About Question" required>
                </div>
            </div>


            <div class="col-md-12 mt-3">
                <div class="form-group">
                    <label for="">Message:</label>
                   <textarea name="msg" class="form-control" placeholder="i.e Hi My Name Is..." required>I will solve your problem as soon as possible thank you</textarea>
                </div>
                <input type="submit" value="Sent Mail" class="btn btn-success mt-3 mb-3" name="send">
            </div>

    

        </div>
       </form>
    </div>
</body>
</html>

<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

if(isset($_POST['send'])){

    $name=$_POST['name'];
    $receiver_email=$_POST['receiver_email'];
    $subject=$_POST['subject'];
    $msg=$_POST['msg'];
    $myemail="abc123@gmail.com";
    
    require 'PHPMailer/Exception.php';
    require 'PHPMailer/PHPMailer.php';
    require 'PHPMailer/SMTP.php';

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = 'smtp.gmail.com';                     // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'abc123@gmail.com';                     // SMTP username
    $mail->Password   = '';//paste your app password key here                              // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption, `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = 25;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('abc123@gmail.com', 'Super-Admin');
    $mail->addAddress($receiver_email, 'Khan');

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    // $mail->Subject = "Let's Learn Programming";
    $mail->Subject = $subject;
    $mail->Body    = "Sender Name - $name <br> Sender Email - $myemail  <br> Message - $msg";

    $mail->send();
    
    ?>
    <div class="row m-auto mt-3">
        <div class="col">
        <div class="alert alert-success" style="font-size:20px;">
            <?php
                echo 'Mail has been sent';
            ?>
            <!-- <button class="close btn btn-danger active" data-dismiss="alert" style="float:right;">X</button> -->
        </div>
        </div>
    </div>
    <?php
} catch (Exception $e) {
    
    ?>
    <div class="row m-auto mt-3">
        <div class="col">
        <div class="alert alert-danger" style="font-size:20px;">
            <?php
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            ?>
            <!-- <button class="close btn btn-danger active" data-dismiss="alert" style="float:right;">X</button> -->
        </div>
        </div>
    </div>
    <?php
}
}

?>