<?php
include('\xampp\htdocs\fyp_project_LWA\config\connection.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <!-- <link href="superadmin\assets\img\logo.png" rel="icon"> -->
  <link href="\fyp_project_LWA\Admins\superadmin\assets\img\apple-touch-icon.png" rel="apple-touch-icon">
  <link rel="icon" href="superadmin/assets/img/logo.png">


  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="\fyp_project_LWA\Admins\superadmin\assets\vendor\bootstrap\css\bootstrap.min.css" rel="stylesheet">
  <link href="\fyp_project_LWA\Admins\superadmin\assets\vendor\bootstrap-icons\bootstrap-icons.css" rel="stylesheet">
  

  <!-- Template Main CSS File -->
  <link href="\fyp_project_LWA\Admins\superadmin\assets\css\style.css" rel="stylesheet">
  <style>
  .card:hover{
        transform: scale(1.05);
        transition:1s;
        cursor: pointer;
  }
</style>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="superadmin/assets/img/logo.png" class="logo d-flex align-items-center">
        <img src="superadmin/assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">Admin</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div>
    <!-- End Logo -->
    <a href="" style="margin-left:auto; color:black;">
  <?php
session_start();
if(isset($_SESSION['uname'])){
    ?>
    <div class="alert alert-success p-2 mt-2">Welcome <?php echo $_SESSION['uname'];?></div>

    <?php
}
else{
    echo "<script>location.href='http://localhost/fyp_project_LWA/LOGIN/login2.php'</script>";
}
?>
  </a>
</a>

      </ul>
    </nav>

  </header>
  <!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

    <li class="nav-item">
        <a class="nav-link " href="http://localhost/fyp_project_LWA/admins/admin.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-journal-text"></i><span>Forms</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="http://localhost/fyp_project_LWA/admins/contact-form.php">
              <i class="bi bi-circle"></i><span>Contact Form</span>
            </a>
          </li>
          <li>
            <a href="http://localhost/fyp_project_LWA/admins/complaint-form.php">
              <i class="bi bi-circle"></i><span>Complaint Form</span>
            </a>
          </li>
          <li>
            <a href="http://localhost/fyp_project_LWA/admins/feedback-form.php">
              <i class="bi bi-circle"></i><span>Feedback Form</span>
            </a>
          </li>
        </ul>
      </li>
      <!-- End Forms Nav -->

      <li class="nav-heading">Pages</li>


      <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="pages-faq.html">
          <i class="bi bi-question-circle"></i>
          <span>F.A.Q</span>
        </a>
      </li> -->

      <li class="nav-item">
        <a class="nav-link " href="http://localhost/fyp_project_LWA/admins/pages-contact.php">
          <i class="bi bi-envelope"></i>
          <span>Contact To Super Admin</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link collapsed" href="http://localhost\fyp_project_LWA\LOGIN\logout.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Log Out</span>
        </a>
      </li>

    </ul>

  </aside>
  <!-- End Sidebar-->