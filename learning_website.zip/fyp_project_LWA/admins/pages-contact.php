<?php
include('admin_header.php');
?>

  <main id="main" class="main">

    <div class="pagetitle">

    <!-- php start-->
<?php
if(isset($_POST['submit'])){
    $fullname=$_POST['name'];
    $email=$_POST['email'];
    $subject=$_POST['subject'];
    $message=$_POST['message'];
    $send=mysqli_query($con,"INSERT INTO `admins_contact`(`full_name`, `email`, `subject`, `message`) VALUES ('$fullname','$email','$subject','$message');");
    if($send)
    {
        echo '<div class="col-12">
        <div class="alert alert-danger bg-info text-white mt-1">
            <p>Contact SuccessFully Submitted Super-Admin will Contact You Within 24 hours</p>
        </div>';
    }
    else
    {
        echo '<div class="col-12">
        <div class="alert alert-danger bg-danger text-white mt-1">
            <p>Contact Failed Please Try Again</p>
        </div>';
    }
}
?>
              <!-- php end -->



      <h1>Contact To Super Admin</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Contact</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section contact">

      <div class="row gy-4">

        <div class="col-xl-6">

          <div class="row">
            <div class="col-lg-6">
              <div class="info-box card">
                <i class="bi bi-geo-alt"></i>
                <h3>Address</h3>
                <p>Bazar Ahamd Khan Bannu,<br>Pakistan</p>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="info-box card">
                <i class="bi bi-telephone"></i>
                <h3>Call Us</h3>
                <p>+923325700407<br>+923347718080</p>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="info-box card">
                <i class="bi bi-envelope"></i>
                <h3>Email Us</h3>
                <p>dawooddk1542@gmail.com<br>yasir@gmail.com</p>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="info-box card">
                <i class="bi bi-clock"></i>
                <h3>Open Hours</h3>
                <p>7/24 <br>Hour's</p>
              </div>
            </div>
          </div>

        </div>

        <!-- form  -->
        <div class="col-xl-6">
          <div class="card p-4">
            <form action="#" method="post" class="php-email-form">
              <div class="row gy-4">

                <div class="col-md-6">
                  <input type="text" name="name" pattern="[A-Za-z ]+" title="Only letters and spaces are allowed" class="form-control" placeholder="Admin Name" required>
                </div>

                <div class="col-md-6 ">
                  <input type="email" class="form-control" name="email" pattern="[a-zA-z0-9]+@+gmail.com" title="Abc123@gmail.com" placeholder="Admin Email" required>
                </div>

                <div class="col-md-12">
                  <input type="text" class="form-control" name="subject" placeholder="Subject" required>
                </div>

                <div class="col-md-12">
                  <textarea class="form-control" name="message" rows="6" placeholder="Message" required></textarea>
                </div>

                <div class="col-md-12 text-center">
                  <button type="submit" name="submit">Send Message</button>
                </div>

              </div>
              
            </form>
          </div>

        </div>

      </div>
      <!-- form end -->
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>D&Y</span></strong>. All Rights Reserved
    </div>
    <div class="credits"> Designed by <a href="#">D&Y</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="\fyp_project_LWA\Admins\superadmin\assets\vendor\bootstrap\js\bootstrap.bundle.min.js"></script>
  

  <!-- Template Main JS File -->
  <script src="\fyp_project_LWA\Admins\superadmin\assets\js\main.js"></script>

</body>

</html>